import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { SUBJECTS } from '../data/subjects';
import { QUESTIONS } from '../data/questions';
import { SubjectId } from '../types';
import { 
  Zap, 
  Atom, 
  Calculator, 
  Compass, 
  Clock, 
  BookOpen, 
  FileText, 
  Trophy, 
  CheckCircle2, 
  ArrowRight, 
  Sparkles,
  HelpCircle,
  Lightbulb,
  GraduationCap
} from 'lucide-react';

export const HomeView: React.FC = () => {
  const { setActiveTab, setSelectedSubject, stats, triggerHaptic, recordQuestionAttempt, openPYQPaper } = useApp();

  // Daily Question State
  const [dailyQ] = useState(() => QUESTIONS[0]);
  const [dailySelected, setDailySelected] = useState<number | null>(null);
  const [showDailyExplanation, setShowDailyExplanation] = useState(false);

  const handleSubjectSelect = (subId: SubjectId) => {
    triggerHaptic(15);
    setSelectedSubject(subId);
    setActiveTab('practice');
  };

  const handleDailyAnswer = (idx: number) => {
    if (dailySelected !== null) return;
    triggerHaptic(20);
    setDailySelected(idx);
    setShowDailyExplanation(true);
    recordQuestionAttempt(dailyQ.id, idx === dailyQ.correctIndex);
  };

  const accuracyPercent = stats.totalAnswered > 0 
    ? Math.round((stats.totalCorrect / stats.totalAnswered) * 100) 
    : 85;

  return (
    <div className="flex-1 flex flex-col p-4 pb-20 space-y-5 animate-fade-in">
      {/* Educator Welcome Card */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-indigo-950 via-slate-900 to-slate-950 border border-indigo-500/30 p-4 shadow-xl">
        <div className="absolute top-0 right-0 -mr-6 -mt-6 w-32 h-32 rounded-full bg-indigo-500/10 blur-2xl pointer-events-none" />
        <div className="flex items-start justify-between gap-3 relative z-10">
          <div>
            <div className="flex items-center gap-1.5 text-xs font-semibold text-indigo-400 mb-1">
              <GraduationCap className="w-4 h-4" />
              <span>Telangana State Engineering Entrance</span>
            </div>
            <h1 className="text-xl font-bold tracking-tight text-white">
              TG EAPCET (MPC) Prep
            </h1>
            <p className="text-xs text-slate-300 mt-1 leading-relaxed">
              Curated by <span className="text-amber-400 font-semibold">Bogaraju Rajesh</span>. Complete preparation suite with official CBT mock tests, chapter MCQs, formulas & PYQs.
            </p>
          </div>
          <div className="shrink-0 w-11 h-11 rounded-2xl bg-indigo-600/30 border border-indigo-500/40 flex items-center justify-center text-indigo-300">
            <Sparkles className="w-6 h-6" />
          </div>
        </div>

        {/* Quick Exam Metrics Banner */}
        <div className="grid grid-cols-3 gap-2 mt-4 pt-3 border-t border-slate-800 text-center">
          <div className="bg-slate-900/60 rounded-xl p-2 border border-slate-800/80">
            <span className="text-[10px] text-slate-400 font-medium block">Questions Solved</span>
            <span className="text-sm font-bold text-white tabular-nums">{stats.totalAnswered}</span>
          </div>
          <div className="bg-slate-900/60 rounded-xl p-2 border border-slate-800/80">
            <span className="text-[10px] text-slate-400 font-medium block">Avg Accuracy</span>
            <span className="text-sm font-bold text-emerald-400 tabular-nums">{accuracyPercent}%</span>
          </div>
          <div className="bg-slate-900/60 rounded-xl p-2 border border-slate-800/80">
            <span className="text-[10px] text-slate-400 font-medium block">CBT Tests</span>
            <span className="text-sm font-bold text-indigo-400 tabular-nums">{stats.totalTests}</span>
          </div>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* PROMINENT SECTION: TG EAPCET PREVIOUS YEAR QUESTIONS (PYQs) */}
      {/* ========================================================================= */}
      <div className="rounded-2xl bg-gradient-to-br from-indigo-950/70 via-slate-900 to-slate-950 border-2 border-indigo-500/40 p-4 shadow-xl space-y-3 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-36 h-36 bg-indigo-500/10 rounded-full blur-2xl pointer-events-none" />

        <div className="flex items-start justify-between gap-2 relative z-10">
          <div>
            <div className="flex items-center gap-1.5 text-xs font-bold text-amber-400 mb-0.5">
              <Sparkles className="w-3.5 h-3.5" />
              <span>OFFICIAL PAPERS (MPC ONLY)</span>
            </div>
            <h2 className="text-base font-bold text-white tracking-tight">
              TG EAPCET PREVIOUS YEAR QUESTIONS (PYQs)
            </h2>
            <p className="text-xs text-slate-300 mt-0.5 leading-relaxed">
              Real 2026 & 2025 question papers for all available morning and afternoon shifts.
            </p>
          </div>

          <button
            onClick={() => {
              triggerHaptic(15);
              openPYQPaper('pyq_2026_shift1', 'practice');
            }}
            className="shrink-0 px-2.5 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-[11px] shadow-sm flex items-center gap-1 active:scale-95 transition-all"
          >
            <span>All PYQs</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* 2026 & 2025 Shift Quick Cards Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 pt-1">
          {/* 2026 TG EAPCET Papers Card */}
          <div className="p-3 rounded-xl bg-slate-950/80 border border-indigo-500/30 space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-sky-400 flex items-center gap-1">
                <span className="w-2 h-2 rounded-full bg-sky-400 animate-pulse" />
                2026 TG EAPCET Papers
              </span>
              <span className="text-[10px] text-slate-400 font-mono">All Shifts</span>
            </div>

            <div className="space-y-1.5">
              {/* Shift 1 */}
              <div className="p-2 rounded-lg bg-slate-900 border border-slate-800 flex items-center justify-between text-xs">
                <div>
                  <div className="font-bold text-white text-[11px]">Shift 1 (Forenoon)</div>
                  <div className="text-[10px] text-slate-400">09:00 AM - 12:00 PM · MPC</div>
                </div>
                <div className="flex items-center gap-1">
                  <button
                    onClick={() => openPYQPaper('pyq_2026_shift1', 'practice')}
                    className="px-2 py-1 rounded-md bg-slate-800 hover:bg-slate-700 text-slate-200 text-[10px] font-semibold transition-all active:scale-95"
                    title="Practice with step solutions"
                  >
                    Practice
                  </button>
                  <button
                    onClick={() => openPYQPaper('pyq_2026_shift1', 'cbt')}
                    className="px-2 py-1 rounded-md bg-indigo-600 hover:bg-indigo-500 text-white text-[10px] font-bold shadow-sm transition-all active:scale-95 flex items-center gap-0.5"
                    title="180-min full CBT exam"
                  >
                    <Clock className="w-2.5 h-2.5" />
                    <span>180m CBT</span>
                  </button>
                </div>
              </div>

              {/* Shift 2 */}
              <div className="p-2 rounded-lg bg-slate-900 border border-slate-800 flex items-center justify-between text-xs">
                <div>
                  <div className="font-bold text-white text-[11px]">Shift 2 (Afternoon)</div>
                  <div className="text-[10px] text-slate-400">03:00 PM - 06:00 PM · MPC</div>
                </div>
                <div className="flex items-center gap-1">
                  <button
                    onClick={() => openPYQPaper('pyq_2026_shift2', 'practice')}
                    className="px-2 py-1 rounded-md bg-slate-800 hover:bg-slate-700 text-slate-200 text-[10px] font-semibold transition-all active:scale-95"
                  >
                    Practice
                  </button>
                  <button
                    onClick={() => openPYQPaper('pyq_2026_shift2', 'cbt')}
                    className="px-2 py-1 rounded-md bg-indigo-600 hover:bg-indigo-500 text-white text-[10px] font-bold shadow-sm transition-all active:scale-95 flex items-center gap-0.5"
                  >
                    <Clock className="w-2.5 h-2.5" />
                    <span>180m CBT</span>
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* 2025 TG EAPCET Papers Card */}
          <div className="p-3 rounded-xl bg-slate-950/80 border border-slate-800 space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-amber-400 flex items-center gap-1">
                <span className="w-2 h-2 rounded-full bg-amber-400" />
                2025 TG EAPCET Papers
              </span>
              <span className="text-[10px] text-slate-400 font-mono">All Shifts</span>
            </div>

            <div className="space-y-1.5">
              {/* Shift 1 */}
              <div className="p-2 rounded-lg bg-slate-900 border border-slate-800 flex items-center justify-between text-xs">
                <div>
                  <div className="font-bold text-white text-[11px]">Shift 1 (Forenoon)</div>
                  <div className="text-[10px] text-slate-400">09:00 AM - 12:00 PM · MPC</div>
                </div>
                <div className="flex items-center gap-1">
                  <button
                    onClick={() => openPYQPaper('pyq_2025_shift1', 'practice')}
                    className="px-2 py-1 rounded-md bg-slate-800 hover:bg-slate-700 text-slate-200 text-[10px] font-semibold transition-all active:scale-95"
                  >
                    Practice
                  </button>
                  <button
                    onClick={() => openPYQPaper('pyq_2025_shift1', 'cbt')}
                    className="px-2 py-1 rounded-md bg-indigo-600 hover:bg-indigo-500 text-white text-[10px] font-bold shadow-sm transition-all active:scale-95 flex items-center gap-0.5"
                  >
                    <Clock className="w-2.5 h-2.5" />
                    <span>180m CBT</span>
                  </button>
                </div>
              </div>

              {/* Shift 2 */}
              <div className="p-2 rounded-lg bg-slate-900 border border-slate-800 flex items-center justify-between text-xs">
                <div>
                  <div className="font-bold text-white text-[11px]">Shift 2 (Afternoon)</div>
                  <div className="text-[10px] text-slate-400">03:00 PM - 06:00 PM · MPC</div>
                </div>
                <div className="flex items-center gap-1">
                  <button
                    onClick={() => openPYQPaper('pyq_2025_shift2', 'practice')}
                    className="px-2 py-1 rounded-md bg-slate-800 hover:bg-slate-700 text-slate-200 text-[10px] font-semibold transition-all active:scale-95"
                  >
                    Practice
                  </button>
                  <button
                    onClick={() => openPYQPaper('pyq_2025_shift2', 'cbt')}
                    className="px-2 py-1 rounded-md bg-indigo-600 hover:bg-indigo-500 text-white text-[10px] font-bold shadow-sm transition-all active:scale-95 flex items-center gap-0.5"
                  >
                    <Clock className="w-2.5 h-2.5" />
                    <span>180m CBT</span>
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Feature Highlights Pills */}
        <div className="flex items-center justify-between text-[10px] text-slate-400 pt-1 border-t border-slate-800/80">
          <span>✓ Separate Maths, Physics & Chemistry</span>
          <span>✓ 180-Min Official Timer</span>
          <span>✓ Bogaraju Rajesh Shortcuts</span>
        </div>
      </div>

      {/* Main Subjects Section - TG EAPCET MPC */}
      <div>
        <div className="flex items-center justify-between mb-2.5">
          <h2 className="text-sm font-bold text-slate-200 uppercase tracking-wider">
            Syllabus Subjects (160 Marks)
          </h2>
          <span className="text-[11px] text-indigo-400 font-medium">MPC Stream Only</span>
        </div>

        <div className="grid grid-cols-2 gap-2.5">
          {/* Maths A */}
          <div 
            onClick={() => handleSubjectSelect('maths_a')}
            className="group cursor-pointer rounded-2xl bg-slate-900/70 border border-sky-500/20 hover:border-sky-500/50 p-3.5 transition-all duration-150 active:scale-[0.98] shadow-sm relative overflow-hidden"
          >
            <div className="w-8 h-8 rounded-xl bg-sky-500/10 text-sky-400 flex items-center justify-center mb-2 group-hover:scale-105 transition-transform">
              <Calculator className="w-4 h-4" />
            </div>
            <h3 className="text-sm font-bold text-white group-hover:text-sky-300 transition-colors">
              Mathematics A
            </h3>
            <p className="text-[11px] text-slate-400 mt-0.5">
              1st & 2nd Year · 40M
            </p>
            <div className="mt-2.5 text-[10px] text-sky-400/90 font-medium flex items-center gap-1">
              <span>Matrices, Trig, Prob</span>
              <ArrowRight className="w-3 h-3 group-hover:translate-x-0.5 transition-transform" />
            </div>
          </div>

          {/* Maths B */}
          <div 
            onClick={() => handleSubjectSelect('maths_b')}
            className="group cursor-pointer rounded-2xl bg-slate-900/70 border border-indigo-500/20 hover:border-indigo-500/50 p-3.5 transition-all duration-150 active:scale-[0.98] shadow-sm relative overflow-hidden"
          >
            <div className="w-8 h-8 rounded-xl bg-indigo-500/10 text-indigo-400 flex items-center justify-center mb-2 group-hover:scale-105 transition-transform">
              <Compass className="w-4 h-4" />
            </div>
            <h3 className="text-sm font-bold text-white group-hover:text-indigo-300 transition-colors">
              Mathematics B
            </h3>
            <p className="text-[11px] text-slate-400 mt-0.5">
              1st & 2nd Year · 40M
            </p>
            <div className="mt-2.5 text-[10px] text-indigo-400/90 font-medium flex items-center gap-1">
              <span>Calculus, Circles, 3D</span>
              <ArrowRight className="w-3 h-3 group-hover:translate-x-0.5 transition-transform" />
            </div>
          </div>

          {/* Physics */}
          <div 
            onClick={() => handleSubjectSelect('physics')}
            className="group cursor-pointer rounded-2xl bg-slate-900/70 border border-amber-500/20 hover:border-amber-500/50 p-3.5 transition-all duration-150 active:scale-[0.98] shadow-sm relative overflow-hidden"
          >
            <div className="w-8 h-8 rounded-xl bg-amber-500/10 text-amber-400 flex items-center justify-center mb-2 group-hover:scale-105 transition-transform">
              <Zap className="w-4 h-4" />
            </div>
            <h3 className="text-sm font-bold text-white group-hover:text-amber-300 transition-colors">
              Physics
            </h3>
            <p className="text-[11px] text-slate-400 mt-0.5">
              1st & 2nd Year · 40M
            </p>
            <div className="mt-2.5 text-[10px] text-amber-400/90 font-medium flex items-center gap-1">
              <span>Mechanics, Electricity, Waves</span>
              <ArrowRight className="w-3 h-3 group-hover:translate-x-0.5 transition-transform" />
            </div>
          </div>

          {/* Chemistry */}
          <div 
            onClick={() => handleSubjectSelect('chemistry')}
            className="group cursor-pointer rounded-2xl bg-slate-900/70 border border-emerald-500/20 hover:border-emerald-500/50 p-3.5 transition-all duration-150 active:scale-[0.98] shadow-sm relative overflow-hidden"
          >
            <div className="w-8 h-8 rounded-xl bg-emerald-500/10 text-emerald-400 flex items-center justify-center mb-2 group-hover:scale-105 transition-transform">
              <Atom className="w-4 h-4" />
            </div>
            <h3 className="text-sm font-bold text-white group-hover:text-emerald-300 transition-colors">
              Chemistry
            </h3>
            <p className="text-[11px] text-slate-400 mt-0.5">
              1st & 2nd Year · 40M
            </p>
            <div className="mt-2.5 text-[10px] text-emerald-400/90 font-medium flex items-center gap-1">
              <span>Organic, Inorganic, Physical</span>
              <ArrowRight className="w-3 h-3 group-hover:translate-x-0.5 transition-transform" />
            </div>
          </div>
        </div>
      </div>

      {/* Primary Action Button: Start Full CBT Mock */}
      <div 
        onClick={() => { triggerHaptic(20); setActiveTab('mock'); }}
        className="w-full cursor-pointer rounded-2xl bg-gradient-to-r from-indigo-600 via-indigo-700 to-sky-600 p-4 text-white shadow-lg shadow-indigo-600/25 active:scale-[0.98] transition-all flex items-center justify-between"
      >
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-white/10 flex items-center justify-center backdrop-blur-sm">
            <Clock className="w-5 h-5 text-white" />
          </div>
          <div>
            <span className="text-xs font-semibold text-indigo-200 uppercase tracking-wide block">Real Exam Experience</span>
            <h3 className="text-sm font-bold">Launch TG EAPCET CBT Mock</h3>
            <span className="text-[11px] text-indigo-100">160 Questions · 180 Minutes · No Negative Marking</span>
          </div>
        </div>
        <div className="w-8 h-8 rounded-full bg-white/20 flex items-center justify-center shrink-0">
          <ArrowRight className="w-4 h-4" />
        </div>
      </div>

      {/* Quick Access Menu Cards */}
      <div className="grid grid-cols-3 gap-2">
        <button
          onClick={() => { triggerHaptic(15); setActiveTab('practice'); }}
          className="flex flex-col items-center justify-center p-3 rounded-2xl bg-slate-900 border border-slate-800 hover:border-slate-700 active:scale-95 transition-all text-center"
        >
          <div className="w-9 h-9 rounded-xl bg-blue-500/10 text-blue-400 flex items-center justify-center mb-1.5">
            <BookOpen className="w-4 h-4" />
          </div>
          <span className="text-xs font-bold text-white">Chapter MCQs</span>
          <span className="text-[10px] text-slate-400">With shortcuts</span>
        </button>

        <button
          onClick={() => { triggerHaptic(15); setActiveTab('formulas'); }}
          className="flex flex-col items-center justify-center p-3 rounded-2xl bg-slate-900 border border-slate-800 hover:border-slate-700 active:scale-95 transition-all text-center"
        >
          <div className="w-9 h-9 rounded-xl bg-emerald-500/10 text-emerald-400 flex items-center justify-center mb-1.5">
            <FileText className="w-4 h-4" />
          </div>
          <span className="text-xs font-bold text-white">Formula Sheets</span>
          <span className="text-[10px] text-slate-400">High-yield cheat</span>
        </button>

        <button
          onClick={() => { triggerHaptic(15); setActiveTab('explanations'); }}
          className="flex flex-col items-center justify-center p-3 rounded-2xl bg-slate-900 border border-slate-800 hover:border-slate-700 active:scale-95 transition-all text-center"
        >
          <div className="w-9 h-9 rounded-xl bg-purple-500/10 text-purple-400 flex items-center justify-center mb-1.5">
            <HelpCircle className="w-4 h-4" />
          </div>
          <span className="text-xs font-bold text-white">Explanations</span>
          <span className="text-[10px] text-slate-400">Weightage & tips</span>
        </button>
      </div>

      {/* Daily Speed Question with Bogaraju Rajesh's 10-Second Shortcut */}
      <div className="rounded-2xl bg-slate-900/90 border border-slate-800 p-4">
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-1.5">
            <Lightbulb className="w-4 h-4 text-amber-400" />
            <span className="text-xs font-bold text-slate-200">Daily EAPCET Speed Question</span>
          </div>
          <span className="text-[10px] font-semibold text-indigo-400 bg-indigo-500/10 px-2 py-0.5 rounded border border-indigo-500/20">
            {dailyQ.pyqYear} PYQ
          </span>
        </div>

        <div className="text-xs text-slate-400 mb-1">
          {dailyQ.chapterTitle} ({dailyQ.year} Year)
        </div>

        <p className="text-xs font-semibold text-slate-100 font-math leading-relaxed mb-3">
          {dailyQ.question}
        </p>

        <div className="grid grid-cols-2 gap-2 mb-3">
          {dailyQ.options.map((opt, idx) => {
            let btnStyle = 'bg-slate-950 border-slate-800 text-slate-300 hover:border-slate-700';
            if (dailySelected !== null) {
              if (idx === dailyQ.correctIndex) {
                btnStyle = 'bg-emerald-950/60 border-emerald-500/80 text-emerald-200';
              } else if (idx === dailySelected) {
                btnStyle = 'bg-rose-950/60 border-rose-500/80 text-rose-200';
              }
            }

            return (
              <button
                key={idx}
                disabled={dailySelected !== null}
                onClick={() => handleDailyAnswer(idx)}
                className={`py-2 px-3 rounded-xl border text-xs font-medium text-left transition-all active:scale-[0.98] ${btnStyle}`}
              >
                <span className="font-bold mr-1.5 text-slate-500">
                  {String.fromCharCode(65 + idx)}.
                </span>
                <span className="font-math">{opt}</span>
              </button>
            );
          })}
        </div>

        {showDailyExplanation && (
          <div className="mt-3 pt-3 border-t border-slate-800/80 space-y-2 animate-fade-in">
            <div className="p-2.5 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-200 text-xs">
              <span className="font-bold flex items-center gap-1 text-amber-300 mb-1">
                <Sparkles className="w-3.5 h-3.5" /> Bogaraju Rajesh's Shortcut Trick:
              </span>
              <p className="text-[11px] font-math leading-relaxed">{dailyQ.shortcutTrick}</p>
            </div>
            <div className="p-2.5 rounded-xl bg-slate-950 text-slate-300 text-xs leading-relaxed font-math whitespace-pre-line border border-slate-800">
              <span className="font-bold text-slate-200 block mb-1">Step-by-Step Proof:</span>
              {dailyQ.explanation}
            </div>
          </div>
        )}
      </div>

      {/* Download Project Source Code ZIP Section */}
      <div className="rounded-2xl bg-gradient-to-r from-emerald-950/60 via-slate-900 to-indigo-950/60 border border-emerald-500/40 p-4 shadow-lg space-y-2.5">
        <div className="flex items-start justify-between gap-2">
          <div>
            <span className="text-[10px] font-bold text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20 uppercase tracking-wider">
              Project Archive Available
            </span>
            <h3 className="text-sm font-bold text-white mt-1">
              Download EduSpark Complete Project Source (ZIP)
            </h3>
            <p className="text-xs text-slate-300 mt-0.5 leading-relaxed">
              Fully packaged source code with all components, PYQ papers, CBT simulator, formulas, and Android Redmi 15 5G configurations.
            </p>
          </div>
          <div className="w-10 h-10 rounded-xl bg-emerald-600/20 border border-emerald-500/30 text-emerald-300 flex items-center justify-center shrink-0">
            <svg className="w-5 h-5 text-emerald-400" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>
              <polyline points="7 10 12 15 17 10"/>
              <line x1="12" y1="15" x2="12" y2="3"/>
            </svg>
          </div>
        </div>

        <button
          onClick={async () => {
            const { downloadProjectZip } = await import('../utils/downloadZip');
            downloadProjectZip();
          }}
          className="w-full py-2.5 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-lg shadow-emerald-600/20 active:scale-95 transition-all"
        >
          <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>
            <polyline points="7 10 12 15 17 10"/>
            <line x1="12" y1="15" x2="12" y2="3"/>
          </svg>
          <span>Download eduspark-tg-eapcet-source.zip</span>
        </button>
      </div>

      {/* TG EAPCET Exam Pattern Guide */}
      <div className="rounded-2xl bg-slate-900/60 border border-slate-800/70 p-4">
        <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider mb-2">
          Official TG EAPCET Pattern Breakdown
        </h4>
        <div className="space-y-1.5 text-xs text-slate-400">
          <div className="flex justify-between py-1 border-b border-slate-800/60">
            <span>Mathematics A & B (80 Questions)</span>
            <span className="font-bold text-slate-200">80 Marks</span>
          </div>
          <div className="flex justify-between py-1 border-b border-slate-800/60">
            <span>Physics (40 Questions)</span>
            <span className="font-bold text-slate-200">40 Marks</span>
          </div>
          <div className="flex justify-between py-1 border-b border-slate-800/60">
            <span>Chemistry (40 Questions)</span>
            <span className="font-bold text-slate-200">40 Marks</span>
          </div>
          <div className="flex justify-between py-1 pt-1.5 text-emerald-400 font-semibold">
            <span>Marking Scheme</span>
            <span>+1 for correct · 0 for wrong (No Negative)</span>
          </div>
        </div>
      </div>
    </div>
  );
};
