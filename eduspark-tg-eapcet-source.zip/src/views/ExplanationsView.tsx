import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { CHAPTER_EXPLANATIONS } from '../data/explanations';
import { CHAPTERS } from '../data/chapters';
import { SUBJECTS } from '../data/subjects';
import { SubjectId, AcademicYear } from '../types';
import { 
  BookCheck, 
  Sparkles, 
  AlertTriangle, 
  TrendingUp, 
  CheckCircle2, 
  ArrowRight,
  ChevronDown
} from 'lucide-react';

export const ExplanationsView: React.FC = () => {
  const { setSelectedSubject, setSelectedYear, setActiveTab, triggerHaptic } = useApp();

  const explanationKeys = Object.keys(CHAPTER_EXPLANATIONS);
  const [selectedKey, setSelectedKey] = useState<string>(explanationKeys[0]);

  const currentExplanation = CHAPTER_EXPLANATIONS[selectedKey];
  const currentChapter = CHAPTERS.find(c => c.id === currentExplanation?.chapterId);

  const handleStartChapterPractice = () => {
    if (!currentChapter) return;
    triggerHaptic(15);
    setSelectedSubject(currentChapter.subjectId);
    setSelectedYear(currentChapter.year);
    setActiveTab('practice');
  };

  return (
    <div className="flex-1 flex flex-col p-4 pb-20 space-y-4 animate-fade-in">
      {/* Explanations Header */}
      <div>
        <h1 className="text-lg font-bold text-white tracking-tight">
          Chapter-wise Explanations
        </h1>
        <p className="text-xs text-slate-400">
          Core conceptual mastery & exam analysis · By Bogaraju Rajesh
        </p>
      </div>

      {/* Chapter Selector Carousel / Pills */}
      <div className="space-y-1.5">
        <label className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
          Select Topic for Deep Review
        </label>
        <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar pb-1 text-xs">
          {explanationKeys.map((key) => {
            const exp = CHAPTER_EXPLANATIONS[key];
            const isSelected = selectedKey === key;
            const sub = SUBJECTS[exp.subjectId];

            return (
              <button
                key={key}
                onClick={() => { triggerHaptic(10); setSelectedKey(key); }}
                className={`px-3 py-1.5 rounded-xl font-semibold whitespace-nowrap transition-all border text-left flex items-center gap-1.5 ${
                  isSelected
                    ? 'bg-indigo-600 text-white border-indigo-500 shadow-md shadow-indigo-600/25'
                    : 'bg-slate-900 text-slate-400 border-slate-800 hover:text-slate-200'
                }`}
              >
                <span>{exp.chapterTitle.split('(')[0]}</span>
                <span className={`text-[9px] px-1 py-0.2 rounded font-bold ${
                  isSelected ? 'bg-white/20 text-white' : sub.accentBg
                }`}>
                  {sub.name.split(' ')[0]}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Main Explanation Document Card */}
      {currentExplanation && (
        <div className="rounded-2xl bg-slate-900 border border-slate-800 p-4 shadow-xl space-y-4">
          {/* Chapter Banner */}
          <div className="pb-3 border-b border-slate-800">
            <div className="flex items-center justify-between text-xs mb-1">
              <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                SUBJECTS[currentExplanation.subjectId].accentBg
              }`}>
                {SUBJECTS[currentExplanation.subjectId].fullName}
              </span>
              <span className="text-amber-400 font-semibold text-[11px] bg-amber-500/10 px-2 py-0.5 rounded border border-amber-500/30">
                Weightage: {currentExplanation.weightageRank}
              </span>
            </div>
            <h2 className="text-base font-bold text-white tracking-tight">
              {currentExplanation.chapterTitle}
            </h2>
            {currentChapter && (
              <p className="text-xs text-slate-400 mt-1">
                {currentChapter.description}
              </p>
            )}
          </div>

          {/* Key Concepts Breakdown */}
          <div className="space-y-3">
            <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
              <BookCheck className="w-4 h-4 text-indigo-400" />
              <span>Core Concepts & Theoretical Framework</span>
            </h3>

            {currentExplanation.keyConcepts.map((kc, idx) => (
              <div key={idx} className="p-3 rounded-xl bg-slate-950 border border-slate-800/80 space-y-1.5">
                <h4 className="text-xs font-bold text-slate-200">
                  {idx + 1}. {kc.heading}
                </h4>
                <ul className="space-y-1 pl-1 text-[11px] text-slate-300 font-math">
                  {kc.points.map((pt, pIdx) => (
                    <li key={pIdx} className="flex items-start gap-2 leading-relaxed">
                      <span className="text-indigo-400 font-bold shrink-0">·</span>
                      <span>{pt}</span>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>

          {/* Quick Formulas Cheat Box */}
          <div className="p-3.5 rounded-xl bg-indigo-950/20 border border-indigo-500/30 space-y-2">
            <span className="text-xs font-bold text-indigo-300 flex items-center gap-1.5">
              <Sparkles className="w-4 h-4 text-amber-400" />
              <span>Bogaraju Rajesh's 10-Second Speed Formulas</span>
            </span>
            <div className="space-y-1 text-xs text-indigo-200 font-math leading-relaxed pl-1">
              {currentExplanation.quickFormulas.map((qf, idx) => (
                <div key={idx} className="flex items-baseline gap-2">
                  <span className="text-amber-400 font-bold text-[10px]">✓</span>
                  <span>{qf}</span>
                </div>
              ))}
            </div>
          </div>

          {/* EAPCET Exam Trends Analysis */}
          <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 space-y-1">
            <span className="text-xs font-bold text-emerald-400 flex items-center gap-1.5">
              <TrendingUp className="w-4 h-4" />
              <span>TG EAPCET 5-Year Trend Analysis</span>
            </span>
            <p className="text-xs text-slate-300 leading-relaxed font-math">
              {currentExplanation.eapcetTrends}
            </p>
          </div>

          {/* Common Mistakes and Traps to Avoid */}
          <div className="p-3.5 rounded-xl bg-rose-950/20 border border-rose-500/30 space-y-2">
            <span className="text-xs font-bold text-rose-300 flex items-center gap-1.5">
              <AlertTriangle className="w-4 h-4 text-rose-400" />
              <span>Common Student Traps in TG EAPCET</span>
            </span>
            <ul className="space-y-1.5 text-xs text-rose-200/90 pl-1">
              {currentExplanation.commonPitfalls.map((pitfall, idx) => (
                <li key={idx} className="flex items-start gap-2 leading-relaxed">
                  <span className="text-rose-400 font-bold shrink-0">⚠</span>
                  <span>{pitfall}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* Chapter Practice CTA */}
          <button
            onClick={handleStartChapterPractice}
            className="w-full py-3 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-lg shadow-indigo-600/20 active:scale-95 transition-all"
          >
            <span>Practice Chapter MCQs Now</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      )}
    </div>
  );
};
