import React, { useState, useMemo } from 'react';
import { useApp } from '../context/AppContext';
import { QUESTIONS } from '../data/questions';
import { CHAPTERS } from '../data/chapters';
import { SUBJECTS } from '../data/subjects';
import { SubjectId, AcademicYear, Question } from '../types';
import { 
  Bookmark, 
  BookmarkCheck, 
  Sparkles, 
  ChevronLeft, 
  ChevronRight, 
  Shuffle, 
  CheckCircle2, 
  XCircle, 
  Lightbulb, 
  Clock, 
  Filter,
  Play
} from 'lucide-react';
import confetti from 'canvas-confetti';

export const PracticeView: React.FC = () => {
  const { 
    selectedSubject, 
    setSelectedSubject, 
    selectedYear, 
    setSelectedYear,
    toggleBookmark, 
    isBookmarked,
    recordQuestionAttempt,
    triggerHaptic,
    setActiveTab
  } = useApp();

  const [activeMode, setActiveMode] = useState<'mcqs' | 'pyqs' | 'custom_quiz'>('mcqs');
  const [selectedPyqYear, setSelectedPyqYear] = useState<number | 'all'>('all');
  const [selectedChapterId, setSelectedChapterId] = useState<string | 'all'>('all');

  // MCQ practice state
  const [currentIndex, setCurrentIndex] = useState(0);
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [showExplanation, setShowExplanation] = useState(false);

  // Filtered chapters for dropdown
  const availableChapters = useMemo(() => {
    return CHAPTERS.filter(c => {
      const matchSub = selectedSubject === 'all' || c.subjectId === selectedSubject;
      const matchYr = selectedYear === 'all' || c.year === selectedYear;
      return matchSub && matchYr;
    });
  }, [selectedSubject, selectedYear]);

  // Filtered Questions
  const filteredQuestions = useMemo(() => {
    return QUESTIONS.filter(q => {
      const matchSub = selectedSubject === 'all' || q.subjectId === selectedSubject;
      const matchYr = selectedYear === 'all' || q.year === selectedYear;
      const matchChapter = selectedChapterId === 'all' || q.chapterId === selectedChapterId;
      const matchPyq = activeMode !== 'pyqs' 
        ? true 
        : (q.isPYQ && (selectedPyqYear === 'all' || q.pyqYear === selectedPyqYear));
      
      return matchSub && matchYr && matchChapter && matchPyq;
    });
  }, [selectedSubject, selectedYear, selectedChapterId, activeMode, selectedPyqYear]);

  const currentQ: Question | undefined = filteredQuestions[currentIndex] || filteredQuestions[0];

  const handleOptionSelect = (idx: number) => {
    if (selectedOption !== null || !currentQ) return;
    triggerHaptic(20);
    setSelectedOption(idx);
    setShowExplanation(true);

    const isCorrect = idx === currentQ.correctIndex;
    recordQuestionAttempt(currentQ.id, isCorrect);

    if (isCorrect) {
      confetti({
        particleCount: 25,
        spread: 60,
        origin: { y: 0.8 },
        colors: ['#6366f1', '#10b981', '#38bdf8']
      });
    }
  };

  const handleNext = () => {
    triggerHaptic(10);
    setSelectedOption(null);
    setShowExplanation(false);
    if (currentIndex < filteredQuestions.length - 1) {
      setCurrentIndex(prev => prev + 1);
    } else {
      setCurrentIndex(0); // cycle back
    }
  };

  const handlePrev = () => {
    triggerHaptic(10);
    setSelectedOption(null);
    setShowExplanation(false);
    if (currentIndex > 0) {
      setCurrentIndex(prev => prev - 1);
    }
  };

  const handleShuffle = () => {
    triggerHaptic(15);
    setSelectedOption(null);
    setShowExplanation(false);
    if (filteredQuestions.length > 1) {
      const randomIdx = Math.floor(Math.random() * filteredQuestions.length);
      setCurrentIndex(randomIdx);
    }
  };

  return (
    <div className="flex-1 flex flex-col p-4 pb-20 space-y-4 animate-fade-in">
      {/* Practice Header & Mode Tabs */}
      <div className="flex flex-col gap-2">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-lg font-bold text-white tracking-tight">
              TG EAPCET Practice Hub
            </h1>
            <p className="text-xs text-slate-400">
              Curated by Bogaraju Rajesh · MPC Syllabus
            </p>
          </div>

          <div className="text-xs text-slate-400 font-medium">
            <span className="text-indigo-400 font-bold tabular-nums">
              {filteredQuestions.length}
            </span> Questions
          </div>
        </div>

        {/* Mode Selector Segmented Tabs */}
        <div className="grid grid-cols-3 gap-1 p-1 bg-slate-900 border border-slate-800 rounded-xl text-xs font-semibold">
          <button
            onClick={() => { setActiveMode('mcqs'); setCurrentIndex(0); setSelectedOption(null); }}
            className={`py-1.5 px-2 rounded-lg transition-all ${
              activeMode === 'mcqs'
                ? 'bg-indigo-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Chapter MCQs
          </button>
          <button
            onClick={() => { setActiveMode('pyqs'); setCurrentIndex(0); setSelectedOption(null); }}
            className={`py-1.5 px-2 rounded-lg transition-all ${
              activeMode === 'pyqs'
                ? 'bg-indigo-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            PYQs (2021-24)
          </button>
          <button
            onClick={() => { triggerHaptic(15); setActiveTab('mock'); }}
            className="py-1.5 px-2 rounded-lg text-slate-400 hover:text-slate-200 transition-all flex items-center justify-center gap-1"
          >
            <Play className="w-3 h-3 text-emerald-400" />
            <span>Full Mock</span>
          </button>
        </div>
      </div>

      {/* Filter Row */}
      <div className="space-y-2 bg-slate-900/60 border border-slate-800/80 rounded-2xl p-3">
        {/* Subject Filter Pills */}
        <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar pb-1 text-xs">
          <button
            onClick={() => { setSelectedSubject('all'); setCurrentIndex(0); setSelectedOption(null); }}
            className={`px-3 py-1 rounded-lg font-medium whitespace-nowrap transition-all ${
              selectedSubject === 'all'
                ? 'bg-slate-200 text-slate-900 font-bold'
                : 'bg-slate-950 text-slate-400 border border-slate-800 hover:text-slate-200'
            }`}
          >
            All Subjects
          </button>
          <button
            onClick={() => { setSelectedSubject('maths_a'); setCurrentIndex(0); setSelectedOption(null); }}
            className={`px-3 py-1 rounded-lg font-medium whitespace-nowrap transition-all ${
              selectedSubject === 'maths_a'
                ? 'bg-sky-500 text-slate-950 font-bold'
                : 'bg-slate-950 text-slate-400 border border-slate-800 hover:text-slate-200'
            }`}
          >
            Maths A
          </button>
          <button
            onClick={() => { setSelectedSubject('maths_b'); setCurrentIndex(0); setSelectedOption(null); }}
            className={`px-3 py-1 rounded-lg font-medium whitespace-nowrap transition-all ${
              selectedSubject === 'maths_b'
                ? 'bg-indigo-500 text-white font-bold'
                : 'bg-slate-950 text-slate-400 border border-slate-800 hover:text-slate-200'
            }`}
          >
            Maths B
          </button>
          <button
            onClick={() => { setSelectedSubject('physics'); setCurrentIndex(0); setSelectedOption(null); }}
            className={`px-3 py-1 rounded-lg font-medium whitespace-nowrap transition-all ${
              selectedSubject === 'physics'
                ? 'bg-amber-500 text-slate-950 font-bold'
                : 'bg-slate-950 text-slate-400 border border-slate-800 hover:text-slate-200'
            }`}
          >
            Physics
          </button>
          <button
            onClick={() => { setSelectedSubject('chemistry'); setCurrentIndex(0); setSelectedOption(null); }}
            className={`px-3 py-1 rounded-lg font-medium whitespace-nowrap transition-all ${
              selectedSubject === 'chemistry'
                ? 'bg-emerald-500 text-slate-950 font-bold'
                : 'bg-slate-950 text-slate-400 border border-slate-800 hover:text-slate-200'
            }`}
          >
            Chemistry
          </button>
        </div>

        {/* Secondary filters: Year and Chapter */}
        <div className="grid grid-cols-2 gap-2 text-xs">
          {/* Year Selector */}
          <div className="flex bg-slate-950 border border-slate-800 rounded-xl p-0.5">
            <button
              onClick={() => { setSelectedYear('all'); setCurrentIndex(0); setSelectedOption(null); }}
              className={`flex-1 py-1 rounded-lg font-medium transition-all ${
                selectedYear === 'all' ? 'bg-slate-800 text-white font-bold' : 'text-slate-400'
              }`}
            >
              All Years
            </button>
            <button
              onClick={() => { setSelectedYear('1st'); setCurrentIndex(0); setSelectedOption(null); }}
              className={`flex-1 py-1 rounded-lg font-medium transition-all ${
                selectedYear === '1st' ? 'bg-slate-800 text-white font-bold' : 'text-slate-400'
              }`}
            >
              1st Year
            </button>
            <button
              onClick={() => { setSelectedYear('2nd'); setCurrentIndex(0); setSelectedOption(null); }}
              className={`flex-1 py-1 rounded-lg font-medium transition-all ${
                selectedYear === '2nd' ? 'bg-slate-800 text-white font-bold' : 'text-slate-400'
              }`}
            >
              2nd Year
            </button>
          </div>

          {/* Chapter Selector Dropdown */}
          <select
            value={selectedChapterId}
            onChange={(e) => { setSelectedChapterId(e.target.value); setCurrentIndex(0); setSelectedOption(null); }}
            className="w-full bg-slate-950 border border-slate-800 rounded-xl px-2.5 py-1 text-slate-200 text-xs focus:outline-none focus:border-indigo-500"
          >
            <option value="all">All Chapters ({availableChapters.length})</option>
            {availableChapters.map(c => (
              <option key={c.id} value={c.id}>
                {c.title} ({c.year})
              </option>
            ))}
          </select>
        </div>

        {/* PYQ Year Tabs if in PYQ mode */}
        {activeMode === 'pyqs' && (
          <div className="flex items-center gap-1.5 pt-1 text-xs border-t border-slate-800/60">
            <span className="text-[10px] text-slate-500 font-semibold uppercase mr-1">Exam Year:</span>
            {[2024, 2023, 2022, 2021].map(yr => (
              <button
                key={yr}
                onClick={() => { setSelectedPyqYear(yr); setCurrentIndex(0); setSelectedOption(null); }}
                className={`px-2.5 py-0.5 rounded-md font-semibold text-[11px] transition-all ${
                  selectedPyqYear === yr
                    ? 'bg-amber-400 text-slate-950 shadow-sm'
                    : 'bg-slate-950 border border-slate-800 text-slate-400 hover:text-slate-200'
                }`}
              >
                {yr}
              </button>
            ))}
            <button
              onClick={() => { setSelectedPyqYear('all'); setCurrentIndex(0); setSelectedOption(null); }}
              className={`px-2 py-0.5 rounded-md text-[11px] font-semibold ${
                selectedPyqYear === 'all' ? 'bg-slate-800 text-white' : 'text-slate-500'
              }`}
            >
              All
            </button>
          </div>
        )}
      </div>

      {/* Main MCQ Card */}
      {currentQ ? (
        <div className="rounded-2xl bg-slate-900 border border-slate-800 p-4 shadow-xl space-y-4">
          {/* Card Top Metadata */}
          <div className="flex items-center justify-between text-xs pb-2 border-b border-slate-800">
            <div className="flex items-center gap-2">
              <span className={`px-2 py-0.5 rounded font-bold text-[10px] ${
                SUBJECTS[currentQ.subjectId].accentBg
              }`}>
                {SUBJECTS[currentQ.subjectId].name}
              </span>
              <span className="text-[11px] text-slate-400">
                {currentQ.year} Year
              </span>
              {currentQ.isPYQ && (
                <span className="text-[10px] font-bold text-amber-400 bg-amber-500/10 px-1.5 py-0.2 rounded border border-amber-500/30">
                  TG EAPCET {currentQ.pyqYear}
                </span>
              )}
            </div>

            {/* Bookmark button */}
            <button
              onClick={() => toggleBookmark(currentQ.id)}
              className="p-1.5 rounded-lg bg-slate-950 border border-slate-800 text-slate-400 hover:text-amber-400 active:scale-95 transition-all"
              title={isBookmarked(currentQ.id) ? 'Remove Bookmark' : 'Bookmark Question'}
            >
              {isBookmarked(currentQ.id) ? (
                <BookmarkCheck className="w-4 h-4 text-amber-400 fill-amber-400" />
              ) : (
                <Bookmark className="w-4 h-4" />
              )}
            </button>
          </div>

          {/* Chapter Subtitle */}
          <div className="text-[11px] font-medium text-slate-400">
            {currentQ.chapterTitle}
          </div>

          {/* Question Text */}
          <div className="text-sm font-semibold text-slate-100 font-math leading-relaxed select-text">
            {currentQ.question}
          </div>

          {/* 4 Options */}
          <div className="space-y-2 pt-1">
            {currentQ.options.map((opt, idx) => {
              const isSelected = selectedOption === idx;
              const isCorrect = idx === currentQ.correctIndex;

              let optionStyle = 'bg-slate-950 border-slate-800 hover:border-slate-700 text-slate-200';
              if (selectedOption !== null) {
                if (isCorrect) {
                  optionStyle = 'bg-emerald-950/70 border-emerald-500 text-emerald-100 font-semibold ring-1 ring-emerald-500/50';
                } else if (isSelected) {
                  optionStyle = 'bg-rose-950/70 border-rose-500 text-rose-100 font-semibold ring-1 ring-rose-500/50';
                } else {
                  optionStyle = 'bg-slate-950/50 border-slate-900 text-slate-500 opacity-60';
                }
              }

              return (
                <button
                  key={idx}
                  disabled={selectedOption !== null}
                  onClick={() => handleOptionSelect(idx)}
                  className={`w-full min-h-[46px] p-3 rounded-xl border text-xs text-left transition-all flex items-start justify-between gap-3 active:scale-[0.99] ${optionStyle}`}
                >
                  <div className="flex items-start gap-2.5">
                    <span className="w-5 h-5 rounded-md bg-slate-800/80 text-slate-300 font-bold text-[11px] flex items-center justify-center shrink-0">
                      {String.fromCharCode(65 + idx)}
                    </span>
                    <span className="font-math leading-snug">{opt}</span>
                  </div>

                  {selectedOption !== null && isCorrect && (
                    <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                  )}
                  {selectedOption !== null && isSelected && !isCorrect && (
                    <XCircle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                  )}
                </button>
              );
            })}
          </div>

          {/* Shortcut and Step-by-Step Explanation Block */}
          {showExplanation && (
            <div className="space-y-3 pt-3 border-t border-slate-800 animate-fade-in">
              {currentQ.shortcutTrick && (
                <div className="p-3 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-200 text-xs">
                  <div className="font-bold flex items-center gap-1.5 text-amber-300 mb-1">
                    <Sparkles className="w-4 h-4 text-amber-400" />
                    <span>Bogaraju Rajesh's Speed Trick (TG EAPCET Standard):</span>
                  </div>
                  <p className="font-math leading-relaxed text-slate-200 pl-5">
                    {currentQ.shortcutTrick}
                  </p>
                </div>
              )}

              <div className="p-3 rounded-xl bg-slate-950 border border-slate-800/80 text-xs text-slate-300 leading-relaxed font-math whitespace-pre-line">
                <span className="font-bold text-slate-200 block mb-1">Step-by-Step Derivation:</span>
                {currentQ.explanation}
              </div>
            </div>
          )}

          {/* Navigation Controls */}
          <div className="flex items-center justify-between pt-2 border-t border-slate-800 text-xs">
            <button
              onClick={handlePrev}
              disabled={currentIndex === 0}
              className="flex items-center gap-1 px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-slate-300 disabled:opacity-40 disabled:cursor-not-allowed hover:bg-slate-800 transition-all"
            >
              <ChevronLeft className="w-4 h-4" />
              <span>Previous</span>
            </button>

            <div className="flex items-center gap-2">
              <button
                onClick={handleShuffle}
                className="p-2 rounded-xl bg-slate-950 border border-slate-800 text-slate-400 hover:text-slate-200 active:scale-95 transition-all"
                title="Shuffle questions"
              >
                <Shuffle className="w-4 h-4" />
              </button>
              <span className="text-slate-400 font-mono text-[11px] tabular-nums">
                {currentIndex + 1} / {filteredQuestions.length}
              </span>
            </div>

            <button
              onClick={handleNext}
              className="flex items-center gap-1 px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-semibold transition-all shadow-md shadow-indigo-600/20 active:scale-95"
            >
              <span>Next</span>
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      ) : (
        <div className="p-8 text-center bg-slate-900 rounded-2xl border border-slate-800 text-slate-400 text-xs">
          No questions match your current filter. Try selecting "All Subjects" or "All Years".
        </div>
      )}
    </div>
  );
};
