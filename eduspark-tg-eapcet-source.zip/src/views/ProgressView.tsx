import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { SUBJECTS } from '../data/subjects';
import { QUESTIONS } from '../data/questions';
import { SubjectId } from '../types';
import { 
  BarChart3, 
  Flame, 
  Trophy, 
  CheckCircle2, 
  AlertCircle, 
  Bookmark, 
  RotateCcw, 
  ArrowRight,
  TrendingUp,
  School,
  Sparkles
} from 'lucide-react';

export const ProgressView: React.FC = () => {
  const { stats, testHistory, estimateRank, triggerHaptic, setActiveTab } = useApp();

  // Rank Estimator slider state (default to 115)
  const [targetScore, setTargetScore] = useState(115);
  const rankProjection = estimateRank(targetScore);

  const accuracyPct = stats.totalAnswered > 0 
    ? Math.round((stats.totalCorrect / stats.totalAnswered) * 100) 
    : 85;

  // Mistake Notebook questions
  const mistakeQuestions = QUESTIONS.filter(q => stats.mistakeQuestionIds.includes(q.id));
  const bookmarkedQuestions = QUESTIONS.filter(q => stats.bookmarkedQuestionIds.includes(q.id));

  // Colleges mapped to marks for Telangana EAPCET
  const getCollegesForMarks = (score: number) => {
    if (score >= 135) {
      return [
        { name: 'JNTU College of Engineering, Hyderabad', branch: 'Computer Science (CSE) / AIML' },
        { name: 'Osmania University (OUCE), Hyderabad', branch: 'Computer Science (CSE) / ECE' },
        { name: 'CBIT, Gandipet', branch: 'CSE (Core) Guaranteed' }
      ];
    } else if (score >= 110) {
      return [
        { name: 'CBIT Gandipet', branch: 'CSE / IT / AI & Data Science' },
        { name: 'Vasavi College of Engineering, Ibrahimbagh', branch: 'CSE / Information Tech' },
        { name: 'VNR Vignana Jyothi (VNR VJIET), Bachupally', branch: 'Computer Science (CSE)' }
      ];
    } else if (score >= 85) {
      return [
        { name: 'CVR College of Engineering, Mangalpalli', branch: 'CSE / Data Science / ECE' },
        { name: 'Gokaraju Rangaraju (GRIET), Nizampet', branch: 'CSE / ECE' },
        { name: 'MGIT, Gandipet', branch: 'CSE / IT' },
        { name: 'Vardhaman College of Engineering', branch: 'CSE / AI' }
      ];
    } else {
      return [
        { name: 'Reputed JNTUH Affiliated Colleges', branch: 'ECE, EEE, Mechanical, Civil' },
        { name: 'Emerging University Engineering Colleges', branch: 'Core & Computing Streams' }
      ];
    }
  };

  const eligibleColleges = getCollegesForMarks(targetScore);

  return (
    <div className="flex-1 flex flex-col p-4 pb-20 space-y-4 animate-fade-in">
      {/* Header */}
      <div>
        <h1 className="text-lg font-bold text-white tracking-tight">
          Performance & Analytics
        </h1>
        <p className="text-xs text-slate-400">
          Continuous tracking for TG EAPCET MPC · By Bogaraju Rajesh
        </p>
      </div>

      {/* KPI Stats Strip */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
        <div className="p-3 rounded-2xl bg-slate-900 border border-slate-800">
          <span className="text-[10px] text-slate-400 font-semibold uppercase block">Solved</span>
          <span className="text-xl font-bold text-white tabular-nums mt-0.5 block">{stats.totalAnswered}</span>
          <span className="text-[10px] text-emerald-400 font-medium">MPC Questions</span>
        </div>

        <div className="p-3 rounded-2xl bg-slate-900 border border-slate-800">
          <span className="text-[10px] text-slate-400 font-semibold uppercase block">Accuracy</span>
          <span className="text-xl font-bold text-emerald-400 tabular-nums mt-0.5 block">{accuracyPct}%</span>
          <span className="text-[10px] text-slate-400 font-medium">{stats.totalCorrect} Correct</span>
        </div>

        <div className="p-3 rounded-2xl bg-slate-900 border border-slate-800">
          <span className="text-[10px] text-slate-400 font-semibold uppercase block">CBT Tests</span>
          <span className="text-xl font-bold text-indigo-400 tabular-nums mt-0.5 block">{stats.totalTests}</span>
          <span className="text-[10px] text-indigo-300 font-medium">Completed</span>
        </div>

        <div className="p-3 rounded-2xl bg-slate-900 border border-slate-800">
          <span className="text-[10px] text-slate-400 font-semibold uppercase block">Study Streak</span>
          <div className="flex items-center gap-1.5 mt-0.5">
            <span className="text-xl font-bold text-amber-400 tabular-nums">{stats.streakDays}</span>
            <Flame className="w-4 h-4 text-amber-400 fill-amber-400" />
          </div>
          <span className="text-[10px] text-amber-300 font-medium">Days Active</span>
        </div>
      </div>

      {/* Subject-Wise Proficiency Section */}
      <div className="rounded-2xl bg-slate-900 border border-slate-800 p-4 space-y-3">
        <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center justify-between">
          <span>Subject Readiness & Marks Breakdown</span>
          <span className="text-indigo-400 text-[11px] font-medium">160 Marks Total</span>
        </h3>

        <div className="space-y-2.5">
          {/* Maths A */}
          <div className="space-y-1">
            <div className="flex justify-between text-xs font-semibold">
              <span className="text-sky-400">Mathematics A (1st & 2nd Year)</span>
              <span className="text-slate-300 tabular-nums">40 Marks · 88% Ready</span>
            </div>
            <div className="w-full h-2 bg-slate-950 rounded-full overflow-hidden border border-slate-800">
              <div className="h-full bg-sky-500 rounded-full" style={{ width: '88%' }} />
            </div>
          </div>

          {/* Maths B */}
          <div className="space-y-1">
            <div className="flex justify-between text-xs font-semibold">
              <span className="text-indigo-400">Mathematics B (1st & 2nd Year)</span>
              <span className="text-slate-300 tabular-nums">40 Marks · 84% Ready</span>
            </div>
            <div className="w-full h-2 bg-slate-950 rounded-full overflow-hidden border border-slate-800">
              <div className="h-full bg-indigo-500 rounded-full" style={{ width: '84%' }} />
            </div>
          </div>

          {/* Physics */}
          <div className="space-y-1">
            <div className="flex justify-between text-xs font-semibold">
              <span className="text-amber-400">Physics (1st & 2nd Year)</span>
              <span className="text-slate-300 tabular-nums">40 Marks · 80% Ready</span>
            </div>
            <div className="w-full h-2 bg-slate-950 rounded-full overflow-hidden border border-slate-800">
              <div className="h-full bg-amber-500 rounded-full" style={{ width: '80%' }} />
            </div>
          </div>

          {/* Chemistry */}
          <div className="space-y-1">
            <div className="flex justify-between text-xs font-semibold">
              <span className="text-emerald-400">Chemistry (1st & 2nd Year)</span>
              <span className="text-slate-300 tabular-nums">40 Marks · 92% Ready</span>
            </div>
            <div className="w-full h-2 bg-slate-950 rounded-full overflow-hidden border border-slate-800">
              <div className="h-full bg-emerald-500 rounded-full" style={{ width: '92%' }} />
            </div>
          </div>
        </div>
      </div>

      {/* Interactive TG EAPCET Rank Predictor & College Explorer */}
      <div className="rounded-2xl bg-gradient-to-br from-indigo-950/60 via-slate-900 to-slate-950 border border-indigo-500/40 p-4 space-y-3 shadow-lg">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-1.5">
            <Trophy className="w-4 h-4 text-amber-400" />
            <h3 className="text-xs font-bold text-white uppercase tracking-wider">
              TG EAPCET Rank & College Predictor
            </h3>
          </div>
          <span className="text-[10px] font-bold text-amber-400 bg-amber-500/10 px-2 py-0.5 rounded border border-amber-500/30">
            Based on 5-Year Cutoffs
          </span>
        </div>

        {/* Score Slider */}
        <div className="space-y-2 pt-1">
          <div className="flex justify-between items-baseline">
            <span className="text-xs text-slate-300 font-medium">Target Raw Score:</span>
            <span className="text-xl font-bold text-indigo-300 font-mono tabular-nums">
              {targetScore} <span className="text-xs text-slate-400 font-normal">/ 160</span>
            </span>
          </div>

          <input
            type="range"
            min={30}
            max={160}
            value={targetScore}
            onChange={(e) => setTargetScore(Number(e.target.value))}
            className="w-full h-2 bg-slate-950 rounded-lg appearance-none cursor-pointer accent-indigo-500"
          />

          <div className="flex justify-between text-[10px] text-slate-500 font-mono">
            <span>30 Marks</span>
            <span>80 (Qualifying)</span>
            <span>120 (Top 1K)</span>
            <span>160 Max</span>
          </div>
        </div>

        {/* Estimated Rank Card */}
        <div className="p-3 rounded-xl bg-slate-950/80 border border-indigo-500/30 grid grid-cols-2 gap-2 text-xs">
          <div>
            <span className="text-[10px] text-slate-400 block">Projected State Rank</span>
            <span className="text-sm font-bold text-amber-400 tabular-nums">
              {rankProjection.rankRange}
            </span>
          </div>
          <div>
            <span className="text-[10px] text-slate-400 block">Estimated Percentile</span>
            <span className="text-sm font-bold text-emerald-400 tabular-nums">
              {rankProjection.percentile}%
            </span>
          </div>
        </div>

        {/* Expected Colleges */}
        <div className="space-y-1.5 pt-1">
          <span className="text-[11px] font-bold text-slate-300 flex items-center gap-1.5">
            <School className="w-3.5 h-3.5 text-indigo-400" />
            <span>Eligible Engineering Colleges in Telangana:</span>
          </span>
          <div className="space-y-1">
            {eligibleColleges.map((col, idx) => (
              <div key={idx} className="p-2 rounded-lg bg-slate-950/50 border border-slate-800 text-[11px] flex items-center justify-between">
                <span className="font-semibold text-slate-200">{col.name}</span>
                <span className="text-[10px] text-emerald-400 font-medium">{col.branch}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Mistake Notebook */}
      <div className="rounded-2xl bg-slate-900 border border-slate-800 p-4 space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-1.5">
            <AlertCircle className="w-4 h-4 text-rose-400" />
            <h3 className="text-xs font-bold text-slate-200 uppercase tracking-wider">
              Mistake Notebook ({mistakeQuestions.length})
            </h3>
          </div>
          <span className="text-[10px] text-slate-400">Auto-logged</span>
        </div>

        {mistakeQuestions.length > 0 ? (
          <div className="space-y-2">
            {mistakeQuestions.slice(0, 3).map((mq) => (
              <div key={mq.id} className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 text-xs space-y-1">
                <div className="flex justify-between text-[10px]">
                  <span className="text-indigo-400 font-semibold">{mq.chapterTitle}</span>
                  <span className="text-rose-400 font-bold">Needs Revision</span>
                </div>
                <p className="font-math text-slate-300 line-clamp-2 leading-relaxed">{mq.question}</p>
              </div>
            ))}
            <button
              onClick={() => { triggerHaptic(15); setActiveTab('practice'); }}
              className="w-full py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold transition-colors"
            >
              Re-attempt Incorrect Questions in Practice Hub
            </button>
          </div>
        ) : (
          <div className="text-center py-4 text-xs text-slate-500">
            No mistakes recorded yet. Keep practicing with high accuracy!
          </div>
        )}
      </div>

      {/* Recent Test History */}
      <div className="rounded-2xl bg-slate-900 border border-slate-800 p-4 space-y-3">
        <h3 className="text-xs font-bold text-slate-200 uppercase tracking-wider flex items-center gap-1.5">
          <BarChart3 className="w-4 h-4 text-indigo-400" />
          <span>Recent Test Logs</span>
        </h3>

        {testHistory.length > 0 ? (
          <div className="space-y-2">
            {testHistory.map((th) => (
              <div key={th.id} className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between text-xs">
                <div>
                  <div className="font-bold text-white">{th.testTitle}</div>
                  <div className="text-[10px] text-slate-400 mt-0.5">
                    {th.date} · {th.attempted} of {th.totalQuestions} Attempted
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-sm font-bold text-emerald-400 tabular-nums">
                    {th.score} / {th.totalQuestions}
                  </div>
                  <div className="text-[10px] text-indigo-300">
                    Est. Rank: {th.predictedRank || 'Top 3.5k'}
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-4 text-xs text-slate-500">
            No tests taken yet. Launch your first CBT Mock Test!
          </div>
        )}
      </div>
    </div>
  );
};
