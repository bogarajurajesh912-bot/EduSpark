import React, { useState, useMemo } from 'react';
import { useApp } from '../context/AppContext';
import { FORMULAS } from '../data/formulas';
import { SUBJECTS } from '../data/subjects';
import { SubjectId, AcademicYear } from '../types';
import { 
  Search, 
  Copy, 
  Check, 
  Bookmark, 
  BookmarkCheck, 
  Sparkles, 
  FileText,
  Filter
} from 'lucide-react';

export const FormulasView: React.FC = () => {
  const { 
    selectedSubject, 
    setSelectedSubject, 
    selectedYear, 
    setSelectedYear,
    toggleSaveFormula,
    isFormulaSaved,
    triggerHaptic
  } = useApp();

  const [searchQuery, setSearchQuery] = useState('');
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [savedOnly, setSavedOnly] = useState(false);

  const filteredFormulas = useMemo(() => {
    return FORMULAS.filter(f => {
      const matchSub = selectedSubject === 'all' || f.subjectId === selectedSubject;
      const matchYr = selectedYear === 'all' || f.year === selectedYear;
      const matchSaved = !savedOnly || isFormulaSaved(f.id);
      
      const q = searchQuery.toLowerCase().trim();
      const matchSearch = !q || (
        f.title.toLowerCase().includes(q) ||
        f.chapterTitle.toLowerCase().includes(q) ||
        f.formula.toLowerCase().includes(q) ||
        f.applicationNote.toLowerCase().includes(q)
      );

      return matchSub && matchYr && matchSaved && matchSearch;
    });
  }, [selectedSubject, selectedYear, savedOnly, searchQuery, isFormulaSaved]);

  const handleCopy = (formulaText: string, id: string) => {
    triggerHaptic(15);
    navigator.clipboard?.writeText(formulaText);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  return (
    <div className="flex-1 flex flex-col p-4 pb-20 space-y-4 animate-fade-in">
      {/* Formulas Header */}
      <div>
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-lg font-bold text-white tracking-tight">
              Formula Revision Sheets
            </h1>
            <p className="text-xs text-slate-400">
              High-yield TG EAPCET speed formulas & identities · By Bogaraju Rajesh
            </p>
          </div>
          <span className="text-xs font-semibold text-indigo-400">
            {filteredFormulas.length} Sheets
          </span>
        </div>
      </div>

      {/* Search Input Bar */}
      <div className="relative">
        <Search className="w-4 h-4 text-slate-500 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
        <input
          type="text"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder="Search formulas (e.g. projectile, radical axis, bond order)..."
          className="w-full bg-slate-900 border border-slate-800 rounded-xl pl-10 pr-4 py-2.5 text-xs text-slate-200 placeholder:text-slate-500 focus:outline-none focus:border-indigo-500 transition-colors"
        />
        {searchQuery && (
          <button
            onClick={() => setSearchQuery('')}
            className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-slate-400 hover:text-white"
          >
            Clear
          </button>
        )}
      </div>

      {/* Subject Filter Pills */}
      <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar text-xs pb-1">
        <button
          onClick={() => setSelectedSubject('all')}
          className={`px-3 py-1 rounded-lg font-medium whitespace-nowrap transition-all ${
            selectedSubject === 'all'
              ? 'bg-slate-200 text-slate-900 font-bold'
              : 'bg-slate-900 text-slate-400 border border-slate-800'
          }`}
        >
          All Subjects
        </button>
        <button
          onClick={() => setSelectedSubject('maths_a')}
          className={`px-3 py-1 rounded-lg font-medium whitespace-nowrap transition-all ${
            selectedSubject === 'maths_a'
              ? 'bg-sky-500 text-slate-950 font-bold'
              : 'bg-slate-900 text-slate-400 border border-slate-800'
          }`}
        >
          Maths A
        </button>
        <button
          onClick={() => setSelectedSubject('maths_b')}
          className={`px-3 py-1 rounded-lg font-medium whitespace-nowrap transition-all ${
            selectedSubject === 'maths_b'
              ? 'bg-indigo-500 text-white font-bold'
              : 'bg-slate-900 text-slate-400 border border-slate-800'
          }`}
        >
          Maths B
        </button>
        <button
          onClick={() => setSelectedSubject('physics')}
          className={`px-3 py-1 rounded-lg font-medium whitespace-nowrap transition-all ${
            selectedSubject === 'physics'
              ? 'bg-amber-500 text-slate-950 font-bold'
              : 'bg-slate-900 text-slate-400 border border-slate-800'
          }`}
        >
          Physics
        </button>
        <button
          onClick={() => setSelectedSubject('chemistry')}
          className={`px-3 py-1 rounded-lg font-medium whitespace-nowrap transition-all ${
            selectedSubject === 'chemistry'
              ? 'bg-emerald-500 text-slate-950 font-bold'
              : 'bg-slate-900 text-slate-400 border border-slate-800'
          }`}
        >
          Chemistry
        </button>
      </div>

      {/* Year & Saved Filter Bar */}
      <div className="flex items-center justify-between text-xs pt-0.5">
        <div className="flex items-center gap-1 bg-slate-900 border border-slate-800 rounded-lg p-0.5">
          <button
            onClick={() => setSelectedYear('all')}
            className={`px-2.5 py-1 rounded-md text-[11px] font-semibold transition-all ${
              selectedYear === 'all' ? 'bg-slate-800 text-white' : 'text-slate-400'
            }`}
          >
            All Years
          </button>
          <button
            onClick={() => setSelectedYear('1st')}
            className={`px-2.5 py-1 rounded-md text-[11px] font-semibold transition-all ${
              selectedYear === '1st' ? 'bg-slate-800 text-white' : 'text-slate-400'
            }`}
          >
            1st Year
          </button>
          <button
            onClick={() => setSelectedYear('2nd')}
            className={`px-2.5 py-1 rounded-md text-[11px] font-semibold transition-all ${
              selectedYear === '2nd' ? 'bg-slate-800 text-white' : 'text-slate-400'
            }`}
          >
            2nd Year
          </button>
        </div>

        <button
          onClick={() => setSavedOnly(!savedOnly)}
          className={`flex items-center gap-1 px-2.5 py-1 rounded-lg text-[11px] font-semibold transition-all border ${
            savedOnly
              ? 'bg-amber-500/20 text-amber-300 border-amber-500/40'
              : 'bg-slate-900 text-slate-400 border-slate-800'
          }`}
        >
          <Bookmark className="w-3.5 h-3.5" />
          <span>Saved Only</span>
        </button>
      </div>

      {/* Formula Cards List */}
      <div className="space-y-3">
        {filteredFormulas.map((item) => {
          const sub = SUBJECTS[item.subjectId];
          const isSaved = isFormulaSaved(item.id);
          const isCopied = copiedId === item.id;

          return (
            <div
              key={item.id}
              className="rounded-2xl bg-slate-900 border border-slate-800/90 p-4 shadow-sm hover:border-slate-700 transition-all space-y-3"
            >
              {/* Header */}
              <div className="flex items-start justify-between gap-2 pb-2 border-b border-slate-800/80">
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${sub.accentBg}`}>
                      {sub.name}
                    </span>
                    <span className="text-[11px] text-slate-400">{item.year} Year</span>
                    {item.importantForEapcet && (
                      <span className="text-[10px] font-bold text-amber-400 bg-amber-500/10 px-1.5 py-0.2 rounded border border-amber-500/30">
                        High Yield
                      </span>
                    )}
                  </div>
                  <h3 className="text-sm font-bold text-white tracking-tight">
                    {item.title}
                  </h3>
                  <div className="text-[11px] text-slate-400 font-medium">
                    {item.chapterTitle}
                  </div>
                </div>

                <div className="flex items-center gap-1">
                  <button
                    onClick={() => handleCopy(item.formula, item.id)}
                    className="p-1.5 rounded-lg bg-slate-950 border border-slate-800 text-slate-400 hover:text-white active:scale-95 transition-all"
                    title="Copy Formula"
                  >
                    {isCopied ? (
                      <Check className="w-4 h-4 text-emerald-400" />
                    ) : (
                      <Copy className="w-4 h-4" />
                    )}
                  </button>

                  <button
                    onClick={() => toggleSaveFormula(item.id)}
                    className="p-1.5 rounded-lg bg-slate-950 border border-slate-800 text-slate-400 hover:text-amber-400 active:scale-95 transition-all"
                    title={isSaved ? 'Remove from Saved' : 'Save to Quick Revision'}
                  >
                    {isSaved ? (
                      <BookmarkCheck className="w-4 h-4 text-amber-400 fill-amber-400" />
                    ) : (
                      <Bookmark className="w-4 h-4" />
                    )}
                  </button>
                </div>
              </div>

              {/* Formula Display Box */}
              <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 font-math text-xs leading-relaxed text-indigo-300 font-semibold whitespace-pre-line select-text">
                {item.formula}
              </div>

              {/* Variables Key */}
              <div className="text-[11px] text-slate-400 leading-snug">
                <span className="font-semibold text-slate-300">Variables: </span>
                {item.variables}
              </div>

              {/* TG EAPCET Exam Note */}
              <div className="p-2.5 rounded-xl bg-indigo-950/30 border border-indigo-500/20 text-[11px] text-indigo-200">
                <span className="font-bold flex items-center gap-1 text-indigo-300 mb-0.5">
                  <Sparkles className="w-3.5 h-3.5" /> EAPCET Application Tip:
                </span>
                <p className="leading-relaxed">{item.applicationNote}</p>
              </div>
            </div>
          );
        })}

        {filteredFormulas.length === 0 && (
          <div className="p-8 text-center bg-slate-900 rounded-2xl border border-slate-800 text-slate-400 text-xs">
            No formulas match your search or filter.
          </div>
        )}
      </div>
    </div>
  );
};
