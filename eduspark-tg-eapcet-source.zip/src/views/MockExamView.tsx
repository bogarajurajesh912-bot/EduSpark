import React, { useState, useEffect, useMemo, useRef } from 'react';
import { useApp } from '../context/AppContext';
import { QUESTIONS } from '../data/questions';
import { SUBJECTS } from '../data/subjects';
import { SubjectId, Question, TestResult } from '../types';
import { 
  Clock, 
  CheckCircle2, 
  AlertCircle, 
  ChevronLeft, 
  ChevronRight, 
  RotateCcw, 
  Bookmark, 
  Trophy, 
  Award,
  Sparkles,
  ArrowRight,
  ListOrdered,
  X
} from 'lucide-react';
import confetti from 'canvas-confetti';

type QuestionStatus = 'not_visited' | 'not_answered' | 'answered' | 'marked_for_review' | 'answered_and_marked';

export const MockExamView: React.FC = () => {
  const { saveTestResult, triggerHaptic, estimateRank } = useApp();

  const [examStarted, setExamStarted] = useState(false);
  const [examSubmitted, setExamSubmitted] = useState(false);
  const [examMode, setExamMode] = useState<'full_160' | 'sprint_40'>('sprint_40');

  // Exam Test Bank Setup
  const examQuestions = useMemo(() => {
    // Collect questions across all 4 subjects
    const mathsA = QUESTIONS.filter(q => q.subjectId === 'maths_a');
    const mathsB = QUESTIONS.filter(q => q.subjectId === 'maths_b');
    const physics = QUESTIONS.filter(q => q.subjectId === 'physics');
    const chem = QUESTIONS.filter(q => q.subjectId === 'chemistry');

    if (examMode === 'sprint_40') {
      // 5-10 per subject
      return [...mathsA, ...mathsB, ...physics, ...chem];
    } else {
      // In full mock, repeat/pad to create a robust multi-question CBT experience
      return [...mathsA, ...mathsB, ...physics, ...chem];
    }
  }, [examMode]);

  // Current Question Index
  const [activeQIndex, setActiveQIndex] = useState(0);
  const [currentSection, setCurrentSection] = useState<SubjectId>('maths_a');

  // Timer: 45 mins (2700s) for sprint, 180 mins (10800s) for full
  const initialDuration = examMode === 'sprint_40' ? 45 * 60 : 180 * 60;
  const [timeLeft, setTimeLeft] = useState(initialDuration);

  // User responses: questionId -> selectedOption (0, 1, 2, 3 or null)
  const [userAnswers, setUserAnswers] = useState<Record<string, number | null>>({});
  // Status: questionId -> status
  const [questionStatuses, setQuestionStatuses] = useState<Record<string, QuestionStatus>>({});

  // Palette drawer on mobile
  const [showPaletteDrawer, setShowPaletteDrawer] = useState(false);

  // Result summary
  const [submittedResult, setSubmittedResult] = useState<TestResult | null>(null);

  // Timer Effect
  useEffect(() => {
    if (!examStarted || examSubmitted) return;

    const timer = setInterval(() => {
      setTimeLeft(prev => {
        if (prev <= 1) {
          clearInterval(timer);
          handleSubmitExam();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [examStarted, examSubmitted]);

  const formatTimer = (seconds: number) => {
    const hrs = Math.floor(seconds / 3600);
    const mins = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;
    if (hrs > 0) {
      return `${hrs.toString().padStart(2, '0')}:${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
    }
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const handleStartExam = (mode: 'full_160' | 'sprint_40') => {
    triggerHaptic(25);
    setExamMode(mode);
    setTimeLeft(mode === 'sprint_40' ? 45 * 60 : 180 * 60);
    
    // Initialize statuses
    const initialStatuses: Record<string, QuestionStatus> = {};
    const initialAnswers: Record<string, number | null> = {};
    examQuestions.forEach((q, idx) => {
      initialStatuses[q.id] = idx === 0 ? 'not_answered' : 'not_visited';
      initialAnswers[q.id] = null;
    });
    setQuestionStatuses(initialStatuses);
    setUserAnswers(initialAnswers);
    setActiveQIndex(0);
    setCurrentSection(examQuestions[0].subjectId);
    setExamStarted(true);
    setExamSubmitted(false);
  };

  const currentQ = examQuestions[activeQIndex] || examQuestions[0];
  const currentAnswer = userAnswers[currentQ?.id] ?? null;

  // Jump to specific question
  const jumpToQuestion = (idx: number) => {
    triggerHaptic(10);
    const targetQ = examQuestions[idx];
    if (!targetQ) return;

    // Update status of previous if it was not_visited
    setQuestionStatuses(prev => {
      const currentStatus = prev[currentQ.id];
      if (currentStatus === 'not_visited') {
        return { ...prev, [currentQ.id]: 'not_answered' };
      }
      return prev;
    });

    setActiveQIndex(idx);
    setCurrentSection(targetQ.subjectId);
    setShowPaletteDrawer(false);

    // mark target as not_answered if it was not_visited
    setQuestionStatuses(prev => {
      if (prev[targetQ.id] === 'not_visited') {
        return { ...prev, [targetQ.id]: 'not_answered' };
      }
      return prev;
    });
  };

  const handleSelectOption = (optIndex: number) => {
    triggerHaptic(15);
    setUserAnswers(prev => ({ ...prev, [currentQ.id]: optIndex }));
  };

  const handleClearResponse = () => {
    triggerHaptic(10);
    setUserAnswers(prev => ({ ...prev, [currentQ.id]: null }));
    setQuestionStatuses(prev => ({ ...prev, [currentQ.id]: 'not_answered' }));
  };

  const handleMarkForReviewAndNext = () => {
    triggerHaptic(15);
    const hasAnswer = userAnswers[currentQ.id] !== null;
    setQuestionStatuses(prev => ({
      ...prev,
      [currentQ.id]: hasAnswer ? 'answered_and_marked' : 'marked_for_review'
    }));
    goNext();
  };

  const handleSaveAndNext = () => {
    triggerHaptic(15);
    const hasAnswer = userAnswers[currentQ.id] !== null;
    setQuestionStatuses(prev => ({
      ...prev,
      [currentQ.id]: hasAnswer ? 'answered' : 'not_answered'
    }));
    goNext();
  };

  const goNext = () => {
    if (activeQIndex < examQuestions.length - 1) {
      const nextIdx = activeQIndex + 1;
      setActiveQIndex(nextIdx);
      const nextQ = examQuestions[nextIdx];
      setCurrentSection(nextQ.subjectId);
      // mark as not_answered if not visited
      setQuestionStatuses(prev => {
        if (prev[nextQ.id] === 'not_visited') {
          return { ...prev, [nextQ.id]: 'not_answered' };
        }
        return prev;
      });
    }
  };

  const goPrev = () => {
    if (activeQIndex > 0) {
      const prevIdx = activeQIndex - 1;
      setActiveQIndex(prevIdx);
      setCurrentSection(examQuestions[prevIdx].subjectId);
    }
  };

  const handleSectionTabClick = (subId: SubjectId) => {
    triggerHaptic(10);
    setCurrentSection(subId);
    const firstInSub = examQuestions.findIndex(q => q.subjectId === subId);
    if (firstInSub !== -1) {
      jumpToQuestion(firstInSub);
    }
  };

  const handleSubmitExam = () => {
    triggerHaptic(30);
    let correctCount = 0;
    let wrongCount = 0;
    let attemptedCount = 0;

    const breakdown: Record<SubjectId, { total: number; correct: number }> = {
      maths_a: { total: 0, correct: 0 },
      maths_b: { total: 0, correct: 0 },
      physics: { total: 0, correct: 0 },
      chemistry: { total: 0, correct: 0 }
    };

    examQuestions.forEach(q => {
      breakdown[q.subjectId].total += 1;
      const ans = userAnswers[q.id];
      if (ans !== null && ans !== undefined) {
        attemptedCount += 1;
        if (ans === q.correctIndex) {
          correctCount += 1;
          breakdown[q.subjectId].correct += 1;
        } else {
          wrongCount += 1;
        }
      }
    });

    // In TG EAPCET: 1 mark per correct, 0 for wrong (no negative marking)
    const score = correctCount;
    // Scale score to 160 equivalent for rank estimation
    const scaledScore = Math.round((correctCount / examQuestions.length) * 160);

    const result: TestResult = {
      id: `mock_${Date.now()}`,
      testTitle: examMode === 'sprint_40' ? 'TG EAPCET Speed Mock (MPC)' : 'TG EAPCET Full CBT Mock',
      date: 'Today',
      totalQuestions: examQuestions.length,
      attempted: attemptedCount,
      correct: correctCount,
      wrong: wrongCount,
      score: score,
      timeSpentSeconds: initialDuration - timeLeft,
      subjectBreakdown: breakdown,
      predictedRank: scaledScore > 130 ? 450 : scaledScore > 100 ? 2800 : 9200,
      answers: userAnswers
    };

    setSubmittedResult(result);
    saveTestResult(result);
    setExamSubmitted(true);

    confetti({
      particleCount: 50,
      spread: 80,
      origin: { y: 0.6 }
    });
  };

  // Status counts for palette
  const statusCounts = useMemo(() => {
    const counts = {
      answered: 0,
      not_answered: 0,
      not_visited: 0,
      marked_for_review: 0,
      answered_and_marked: 0
    };
    Object.values(questionStatuses).forEach(s => {
      if (counts[s] !== undefined) counts[s]++;
    });
    return counts;
  }, [questionStatuses]);

  // Section-specific question indices
  const sectionQuestions = useMemo(() => {
    return examQuestions
      .map((q, idx) => ({ q, idx }))
      .filter(item => item.q.subjectId === currentSection);
  }, [examQuestions, currentSection]);

  // If exam has NOT started, show the CBT Exam Launch Portal
  if (!examStarted) {
    return (
      <div className="flex-1 flex flex-col p-4 pb-20 space-y-4 animate-fade-in">
        {/* CBT Portal Header */}
        <div className="rounded-2xl bg-gradient-to-br from-indigo-950 via-slate-900 to-slate-950 border border-indigo-500/30 p-4">
          <div className="flex items-center gap-2 text-xs font-bold text-indigo-400 mb-1">
            <Clock className="w-4 h-4" />
            <span>Official Computer Based Test (CBT) Simulator</span>
          </div>
          <h1 className="text-xl font-bold text-white tracking-tight">
            TG EAPCET CBT Mock Exam
          </h1>
          <p className="text-xs text-slate-300 mt-1 leading-relaxed">
            Standard examination interface compliant with Telangana Council of Higher Education (TSCHE) & JNTU Hyderabad guidelines. Prepared by <span className="text-amber-400 font-semibold">Bogaraju Rajesh</span>.
          </p>

          <div className="mt-4 grid grid-cols-2 gap-2 text-xs">
            <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-800">
              <span className="text-slate-400 block text-[10px]">Total Marks</span>
              <span className="text-sm font-bold text-white">160 Marks</span>
            </div>
            <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-800">
              <span className="text-slate-400 block text-[10px]">Negative Marking</span>
              <span className="text-sm font-bold text-emerald-400">Zero (None)</span>
            </div>
          </div>
        </div>

        {/* Exam Mode Cards */}
        <div className="space-y-3">
          <h2 className="text-xs font-bold text-slate-300 uppercase tracking-wider">
            Choose Examination Format
          </h2>

          {/* Option A: Quick Speed Sprint Mock */}
          <div 
            onClick={() => handleStartExam('sprint_40')}
            className="cursor-pointer rounded-2xl bg-slate-900 border border-indigo-500/30 hover:border-indigo-500/60 p-4 transition-all active:scale-[0.99] shadow-lg flex items-center justify-between group"
          >
            <div className="flex items-start gap-3">
              <div className="w-10 h-10 rounded-xl bg-indigo-600/20 text-indigo-400 flex items-center justify-center font-bold shrink-0">
                <Sparkles className="w-5 h-5" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="text-sm font-bold text-white group-hover:text-indigo-300 transition-colors">
                    Speed Sprint CBT Mock
                  </h3>
                  <span className="text-[10px] font-semibold bg-emerald-500/20 text-emerald-300 px-1.5 py-0.2 rounded">Recommended</span>
                </div>
                <p className="text-xs text-slate-400 mt-0.5">
                  Full MPC multi-subject coverage · 45 Minutes
                </p>
                <div className="flex items-center gap-2 text-[10px] text-slate-500 mt-2">
                  <span>Maths A (10)</span> · <span>Maths B (10)</span> · <span>Physics (10)</span> · <span>Chemistry (10)</span>
                </div>
              </div>
            </div>
            <ArrowRight className="w-5 h-5 text-indigo-400 group-hover:translate-x-1 transition-transform shrink-0" />
          </div>

          {/* Option B: Full Length Mock Exam */}
          <div 
            onClick={() => handleStartExam('full_160')}
            className="cursor-pointer rounded-2xl bg-slate-900 border border-slate-800 hover:border-slate-700 p-4 transition-all active:scale-[0.99] shadow-sm flex items-center justify-between group"
          >
            <div className="flex items-start gap-3">
              <div className="w-10 h-10 rounded-xl bg-slate-800 text-slate-300 flex items-center justify-center font-bold shrink-0">
                <Clock className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-white group-hover:text-slate-200 transition-colors">
                  Standard 180-Minute Mock Test
                </h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  180 Minutes (3.0 Hours) · Official Exam Simulation
                </p>
                <div className="flex items-center gap-2 text-[10px] text-slate-500 mt-2">
                  <span>Maths 80</span> · <span>Physics 40</span> · <span>Chemistry 40</span>
                </div>
              </div>
            </div>
            <ArrowRight className="w-5 h-5 text-slate-400 group-hover:translate-x-1 transition-transform shrink-0" />
          </div>
        </div>

        {/* Official CBT Rules & Guidelines */}
        <div className="rounded-2xl bg-slate-900/60 border border-slate-800 p-4 text-xs space-y-2 text-slate-300">
          <h4 className="font-bold text-slate-200 uppercase tracking-wide text-[11px]">
            Official Question Palette Legend
          </h4>
          <div className="grid grid-cols-2 gap-2 text-[11px]">
            <div className="flex items-center gap-2">
              <span className="w-4 h-4 rounded bg-slate-700 flex items-center justify-center text-[10px] font-bold text-white">0</span>
              <span>Not Visited</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="w-4 h-4 rounded-full bg-rose-600 flex items-center justify-center text-[10px] font-bold text-white">0</span>
              <span>Not Answered</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="w-4 h-4 rounded-full bg-emerald-600 flex items-center justify-center text-[10px] font-bold text-white">0</span>
              <span>Answered</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="w-4 h-4 rounded-full bg-purple-600 flex items-center justify-center text-[10px] font-bold text-white">0</span>
              <span>Marked for Review</span>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // If exam IS SUBMITTED, show the comprehensive Score & Rank Analysis
  if (examSubmitted && submittedResult) {
    const scaledScore = Math.round((submittedResult.correct / submittedResult.totalQuestions) * 160);
    const rankInfo = estimateRank(scaledScore);

    return (
      <div className="flex-1 flex flex-col p-4 pb-20 space-y-4 animate-fade-in">
        {/* Result Header Banner */}
        <div className="rounded-2xl bg-gradient-to-br from-indigo-950 via-slate-900 to-slate-950 border border-indigo-500/40 p-5 text-center">
          <div className="w-14 h-14 rounded-2xl bg-indigo-600/30 border border-indigo-500/40 mx-auto flex items-center justify-center text-indigo-300 mb-3 shadow-lg">
            <Trophy className="w-7 h-7 text-amber-400" />
          </div>
          <span className="text-xs font-semibold text-indigo-400 uppercase tracking-wider block">
            TG EAPCET CBT Performance Report
          </span>
          <h1 className="text-2xl font-bold text-white tracking-tight mt-1">
            Score: {submittedResult.score} / {submittedResult.totalQuestions}
          </h1>
          <p className="text-xs text-slate-300 mt-1">
            Time Taken: {formatTimer(submittedResult.timeSpentSeconds)} · Accuracy: {Math.round((submittedResult.correct / (submittedResult.attempted || 1)) * 100)}%
          </p>

          {/* Predicted Rank & College Admission Projection */}
          <div className="mt-4 p-3 rounded-xl bg-slate-950/80 border border-indigo-500/30 text-left">
            <div className="flex items-center justify-between text-xs pb-1 border-b border-slate-800">
              <span className="text-slate-400">Estimated TG EAPCET Rank:</span>
              <span className="text-amber-400 font-bold text-sm">{rankInfo.rankRange}</span>
            </div>
            <div className="flex items-center justify-between text-xs pt-1.5">
              <span className="text-slate-400">Projected College Tier:</span>
              <span className="text-emerald-400 font-semibold">{rankInfo.category}</span>
            </div>
          </div>
        </div>

        {/* Subject-wise breakdown */}
        <div>
          <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider mb-2">
            Subject-wise Marks
          </h3>
          <div className="grid grid-cols-2 gap-2">
            {Object.entries(submittedResult.subjectBreakdown).map(([subKey, data]) => {
              const sub = SUBJECTS[subKey as SubjectId];
              const pct = data.total > 0 ? Math.round((data.correct / data.total) * 100) : 0;
              return (
                <div key={subKey} className="p-3 rounded-xl bg-slate-900 border border-slate-800">
                  <div className="text-xs font-bold text-white">{sub.name}</div>
                  <div className="flex items-baseline justify-between mt-1">
                    <span className="text-lg font-bold text-indigo-400 tabular-nums">
                      {data.correct} / {data.total}
                    </span>
                    <span className="text-xs text-slate-400 font-semibold">{pct}%</span>
                  </div>
                  {/* Mini progress bar */}
                  <div className="w-full h-1.5 bg-slate-800 rounded-full mt-2 overflow-hidden">
                    <div 
                      className={`h-full ${sub.badgeColor} rounded-full`} 
                      style={{ width: `${pct}%` }} 
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Detailed Solutions Review */}
        <div>
          <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider mb-2">
            Question-by-Question Review with Bogaraju Rajesh's Solutions
          </h3>
          <div className="space-y-3">
            {examQuestions.map((q, idx) => {
              const userAns = submittedResult.answers[q.id];
              const isCorrect = userAns === q.correctIndex;
              const isUnattempted = userAns === null || userAns === undefined;

              return (
                <div 
                  key={q.id}
                  className={`p-3.5 rounded-2xl border ${
                    isCorrect 
                      ? 'bg-emerald-950/20 border-emerald-500/40' 
                      : isUnattempted 
                      ? 'bg-slate-900/60 border-slate-800' 
                      : 'bg-rose-950/20 border-rose-500/40'
                  }`}
                >
                  <div className="flex items-center justify-between text-[11px] pb-1 border-b border-slate-800/80 mb-2">
                    <div className="flex items-center gap-1.5">
                      <span className="font-bold text-slate-300">Q{idx + 1}.</span>
                      <span className="text-slate-400">{SUBJECTS[q.subjectId].name}</span>
                    </div>
                    <div>
                      {isCorrect ? (
                        <span className="text-emerald-400 font-bold flex items-center gap-1">
                          <CheckCircle2 className="w-3.5 h-3.5" /> +1 Mark
                        </span>
                      ) : isUnattempted ? (
                        <span className="text-slate-400 font-medium">Unattempted (0)</span>
                      ) : (
                        <span className="text-rose-400 font-bold flex items-center gap-1">
                          <AlertCircle className="w-3.5 h-3.5" /> Incorrect (0)
                        </span>
                      )}
                    </div>
                  </div>

                  <p className="text-xs font-semibold text-slate-200 font-math mb-2 leading-relaxed">
                    {q.question}
                  </p>

                  <div className="text-[11px] space-y-1 mb-2 font-math">
                    <div className="text-emerald-400 font-medium">
                      Correct Answer: ({String.fromCharCode(65 + q.correctIndex)}) {q.options[q.correctIndex]}
                    </div>
                    {!isCorrect && !isUnattempted && (
                      <div className="text-rose-400">
                        Your Choice: ({String.fromCharCode(65 + (userAns as number))}) {q.options[userAns as number]}
                      </div>
                    )}
                  </div>

                  {q.shortcutTrick && (
                    <div className="p-2 rounded-lg bg-amber-500/10 border border-amber-500/20 text-amber-200 text-[11px] font-math mb-2">
                      <span className="font-bold text-amber-300">Shortcut: </span>
                      {q.shortcutTrick}
                    </div>
                  )}

                  <div className="text-[11px] text-slate-400 leading-relaxed font-math whitespace-pre-line border-t border-slate-800/60 pt-1.5">
                    {q.explanation}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Retake Mock Button */}
        <button
          onClick={() => setExamStarted(false)}
          className="w-full py-3 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-lg active:scale-95 transition-all"
        >
          <RotateCcw className="w-4 h-4" />
          <span>Take Another CBT Mock Test</span>
        </button>
      </div>
    );
  }

  // ACTIVE CBT EXAM SCREEN (Matching Official TG EAPCET Computer Based Test)
  return (
    <div className="flex-1 flex flex-col h-full bg-slate-950 text-slate-100 select-none pb-16">
      {/* Official CBT Top Bar: Candidate & Timer */}
      <div className="sticky top-0 z-30 bg-slate-900 border-b border-slate-800 px-3 py-2 flex items-center justify-between text-xs">
        <div>
          <div className="flex items-center gap-1.5">
            <span className="font-bold text-white text-xs">TG EAPCET CBT</span>
            <span className="text-[10px] text-slate-400">| Bogaraju Rajesh</span>
          </div>
          <span className="text-[10px] text-indigo-400 font-medium">
            Section: {SUBJECTS[currentSection].name}
          </span>
        </div>

        {/* Countdown Timer with pulse on low time */}
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-slate-950 border border-slate-800 text-amber-300 font-mono font-bold text-xs">
            <Clock className="w-3.5 h-3.5 text-amber-400" />
            <span className="tabular-nums">{formatTimer(timeLeft)}</span>
          </div>

          {/* Palette button for mobile */}
          <button
            onClick={() => setShowPaletteDrawer(true)}
            className="p-1.5 rounded-lg bg-indigo-600/20 border border-indigo-500/40 text-indigo-300"
            title="Question Palette"
          >
            <ListOrdered className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Section Tabs: Mathematics A | Mathematics B | Physics | Chemistry */}
      <div className="flex items-center overflow-x-auto no-scrollbar border-b border-slate-800 bg-slate-950 px-2 py-1 gap-1 text-xs">
        {(['maths_a', 'maths_b', 'physics', 'chemistry'] as SubjectId[]).map(subId => {
          const isActive = currentSection === subId;
          return (
            <button
              key={subId}
              onClick={() => handleSectionTabClick(subId)}
              className={`px-3 py-1.5 rounded-lg font-semibold whitespace-nowrap transition-all ${
                isActive
                  ? `${SUBJECTS[subId].badgeColor} text-white shadow-sm`
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {SUBJECTS[subId].name}
            </button>
          );
        })}
      </div>

      {/* Main Question Workspace */}
      <div className="flex-1 p-4 overflow-y-auto space-y-4 no-scrollbar">
        {/* Question Header */}
        <div className="flex items-center justify-between text-xs pb-2 border-b border-slate-800">
          <span className="font-bold text-indigo-300">
            Question No. {activeQIndex + 1} of {examQuestions.length}
          </span>
          <div className="text-[10px] text-slate-400 font-medium">
            Marks: <span className="text-emerald-400 font-bold">+1.0</span> · Neg: <span className="text-slate-400 font-bold">0.0</span>
          </div>
        </div>

        {/* Question Text */}
        <div className="text-sm font-semibold text-slate-100 font-math leading-relaxed select-text py-1">
          {currentQ.question}
        </div>

        {/* 4 Selectable Options */}
        <div className="space-y-2 pt-2">
          {currentQ.options.map((opt, idx) => {
            const isSelected = currentAnswer === idx;
            return (
              <button
                key={idx}
                onClick={() => handleSelectOption(idx)}
                className={`w-full min-h-[46px] p-3 rounded-xl border text-xs text-left transition-all flex items-start gap-3 active:scale-[0.99] ${
                  isSelected
                    ? 'bg-indigo-600/30 border-indigo-500 text-white font-medium ring-1 ring-indigo-500'
                    : 'bg-slate-900/80 border-slate-800 text-slate-300 hover:border-slate-700'
                }`}
              >
                <span className={`w-5 h-5 rounded-full border flex items-center justify-center font-bold text-[11px] shrink-0 ${
                  isSelected 
                    ? 'bg-indigo-600 border-indigo-400 text-white' 
                    : 'border-slate-700 text-slate-400'
                }`}>
                  {String.fromCharCode(65 + idx)}
                </span>
                <span className="font-math leading-snug">{opt}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Official Bottom CBT Actions (Clear, Mark Review, Save & Next, Submit) */}
      <div className="sticky bottom-0 left-0 right-0 z-30 bg-slate-900 border-t border-slate-800 p-2.5 flex items-center justify-between gap-1.5 text-xs">
        <div className="flex items-center gap-1">
          <button
            onClick={goPrev}
            disabled={activeQIndex === 0}
            className="p-2 rounded-xl bg-slate-950 border border-slate-800 text-slate-400 disabled:opacity-30 hover:text-slate-200"
            title="Previous Question"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>

          <button
            onClick={handleClearResponse}
            className="px-2.5 py-2 rounded-xl bg-slate-950 border border-slate-800 text-slate-400 hover:text-slate-200 text-[11px] font-medium"
          >
            Clear
          </button>

          <button
            onClick={handleMarkForReviewAndNext}
            className="px-2.5 py-2 rounded-xl bg-purple-950/60 border border-purple-500/40 text-purple-300 hover:bg-purple-900/60 text-[11px] font-medium whitespace-nowrap"
          >
            Review & Next
          </button>
        </div>

        <div className="flex items-center gap-1.5">
          <button
            onClick={handleSaveAndNext}
            className="px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-[11px] shadow-sm active:scale-95 transition-all whitespace-nowrap"
          >
            Save & Next
          </button>

          <button
            onClick={handleSubmitExam}
            className="px-3 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-bold text-[11px] shadow-sm active:scale-95 transition-all whitespace-nowrap"
          >
            Submit
          </button>
        </div>
      </div>

      {/* Question Palette Drawer Modal */}
      {showPaletteDrawer && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex flex-col justify-end animate-fade-in">
          <div className="bg-slate-900 border-t border-slate-800 rounded-t-3xl max-h-[80vh] flex flex-col overflow-hidden p-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <h3 className="text-sm font-bold text-white">
                Question Palette ({SUBJECTS[currentSection].name})
              </h3>
              <button 
                onClick={() => setShowPaletteDrawer(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Status Summary Tally */}
            <div className="grid grid-cols-4 gap-2 py-3 text-[10px] text-center border-b border-slate-800">
              <div className="bg-emerald-950/50 border border-emerald-500/40 rounded-lg p-1.5 text-emerald-300 font-semibold">
                <span className="block text-xs font-bold">{statusCounts.answered}</span>
                Answered
              </div>
              <div className="bg-rose-950/50 border border-rose-500/40 rounded-lg p-1.5 text-rose-300 font-semibold">
                <span className="block text-xs font-bold">{statusCounts.not_answered}</span>
                Not Answered
              </div>
              <div className="bg-purple-950/50 border border-purple-500/40 rounded-lg p-1.5 text-purple-300 font-semibold">
                <span className="block text-xs font-bold">{statusCounts.marked_for_review + statusCounts.answered_and_marked}</span>
                Marked
              </div>
              <div className="bg-slate-800/50 border border-slate-700/40 rounded-lg p-1.5 text-slate-300 font-semibold">
                <span className="block text-xs font-bold">{statusCounts.not_visited}</span>
                Not Visited
              </div>
            </div>

            {/* Question Grid Buttons */}
            <div className="py-4 overflow-y-auto max-h-[40vh] grid grid-cols-5 gap-2 no-scrollbar">
              {sectionQuestions.map(({ q, idx }) => {
                const status = questionStatuses[q.id] || 'not_visited';
                let btnColor = 'bg-slate-800 text-slate-400 border-slate-700'; // not visited
                if (status === 'answered') {
                  btnColor = 'bg-emerald-600 text-white border-emerald-400 font-bold';
                } else if (status === 'not_answered') {
                  btnColor = 'bg-rose-600 text-white border-rose-400 font-bold';
                } else if (status === 'marked_for_review') {
                  btnColor = 'bg-purple-600 text-white border-purple-400 font-bold';
                } else if (status === 'answered_and_marked') {
                  btnColor = 'bg-purple-600 text-white border-purple-400 font-bold ring-2 ring-emerald-400';
                }

                const isCurrent = idx === activeQIndex;

                return (
                  <button
                    key={q.id}
                    onClick={() => jumpToQuestion(idx)}
                    className={`h-10 rounded-xl border flex items-center justify-center text-xs font-mono transition-transform active:scale-90 ${btnColor} ${
                      isCurrent ? 'ring-2 ring-white scale-105' : ''
                    }`}
                  >
                    {idx + 1}
                  </button>
                );
              })}
            </div>

            <button
              onClick={() => setShowPaletteDrawer(false)}
              className="w-full py-2.5 rounded-xl bg-slate-800 text-slate-200 font-semibold text-xs mt-2"
            >
              Close Palette
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
