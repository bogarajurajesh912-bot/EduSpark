import React, { useState, useMemo, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import { PYQ_PAPERS } from '../data/pyqPapers';
import { SUBJECTS } from '../data/subjects';
import { SubjectId, Question, TestResult, PYQPaper } from '../types';
import { 
  Clock, 
  Sparkles, 
  CheckCircle2, 
  XCircle, 
  Bookmark, 
  BookmarkCheck, 
  ChevronLeft, 
  ChevronRight, 
  RotateCcw, 
  Trophy, 
  FileText, 
  BookOpen, 
  GraduationCap, 
  Calendar,
  AlertCircle,
  Play,
  ListOrdered,
  X
} from 'lucide-react';
import confetti from 'canvas-confetti';

type QuestionStatus = 'not_visited' | 'not_answered' | 'answered' | 'marked_for_review' | 'answered_and_marked';

export const PYQView: React.FC = () => {
  const { 
    selectedPYQPaperId, 
    setSelectedPYQPaperId, 
    selectedPYQMode, 
    setSelectedPYQMode,
    toggleBookmark, 
    isBookmarked,
    recordQuestionAttempt,
    saveTestResult,
    triggerHaptic,
    estimateRank
  } = useApp();

  // Selected year filter (2026 vs 2025)
  const [selectedYear, setSelectedYear] = useState<2026 | 2025>(() => {
    const initialPaper = PYQ_PAPERS.find(p => p.id === selectedPYQPaperId);
    return initialPaper ? initialPaper.year : 2026;
  });

  // Current active paper
  const activePaper: PYQPaper = useMemo(() => {
    const found = PYQ_PAPERS.find(p => p.id === selectedPYQPaperId);
    if (found && found.year === selectedYear) return found;
    // fallback to first paper of that year
    const yearPapers = PYQ_PAPERS.filter(p => p.year === selectedYear);
    return yearPapers[0] || PYQ_PAPERS[0];
  }, [selectedPYQPaperId, selectedYear]);

  // Subject Tab within the paper: 'all' | 'maths' | 'physics' | 'chemistry'
  const [subjectFilter, setSubjectFilter] = useState<'all' | 'maths' | 'physics' | 'chemistry'>('all');

  // PRACTICE MODE STATE
  const [practiceIndex, setPracticeIndex] = useState(0);
  const [practiceAnswer, setPracticeAnswer] = useState<number | null>(null);
  const [showPracticeExplanation, setShowPracticeExplanation] = useState(false);

  // CBT MODE STATE
  const [cbtStarted, setCbtStarted] = useState(false);
  const [cbtSubmitted, setCbtSubmitted] = useState(false);
  const [cbtActiveIndex, setCbtActiveIndex] = useState(0);
  const [cbtSection, setCbtSection] = useState<'maths' | 'physics' | 'chemistry'>('maths');
  const [cbtTimeLeft, setCbtTimeLeft] = useState(180 * 60); // 180 Minutes (3 Hours)
  const [cbtAnswers, setCbtAnswers] = useState<Record<string, number | null>>({});
  const [cbtStatuses, setCbtStatuses] = useState<Record<string, QuestionStatus>>({});
  const [showPaletteDrawer, setShowPaletteDrawer] = useState(false);
  const [cbtResult, setCbtResult] = useState<TestResult | null>(null);

  // Synchronize when active paper changes
  useEffect(() => {
    setPracticeIndex(0);
    setPracticeAnswer(null);
    setShowPracticeExplanation(false);
    setCbtStarted(false);
    setCbtSubmitted(false);
    setCbtResult(null);
  }, [activePaper.id]);

  // Filtered questions for Practice Mode
  const practiceQuestions: Question[] = useMemo(() => {
    if (subjectFilter === 'maths') {
      return activePaper.mathsQuestions;
    }
    if (subjectFilter === 'physics') {
      return activePaper.physicsQuestions;
    }
    if (subjectFilter === 'chemistry') {
      return activePaper.chemistryQuestions;
    }
    return activePaper.allQuestions;
  }, [activePaper, subjectFilter]);

  const currentPracticeQ = practiceQuestions[practiceIndex] || practiceQuestions[0];

  // 180-minute Timer Effect for CBT Mode
  useEffect(() => {
    if (!cbtStarted || cbtSubmitted) return;

    const interval = setInterval(() => {
      setCbtTimeLeft(prev => {
        if (prev <= 1) {
          clearInterval(interval);
          handleCbtSubmit();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [cbtStarted, cbtSubmitted]);

  const formatTimer = (seconds: number) => {
    const hrs = Math.floor(seconds / 3600);
    const mins = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;
    return `${hrs.toString().padStart(2, '0')}:${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  // Practice Handlers
  const handlePracticeSelectOption = (idx: number) => {
    if (practiceAnswer !== null || !currentPracticeQ) return;
    triggerHaptic(20);
    setPracticeAnswer(idx);
    setShowPracticeExplanation(true);
    const isCorrect = idx === currentPracticeQ.correctIndex;
    recordQuestionAttempt(currentPracticeQ.id, isCorrect);

    if (isCorrect) {
      confetti({
        particleCount: 20,
        spread: 60,
        origin: { y: 0.8 },
        colors: ['#6366f1', '#10b981', '#f59e0b']
      });
    }
  };

  const handlePracticeNext = () => {
    triggerHaptic(10);
    setPracticeAnswer(null);
    setShowPracticeExplanation(false);
    if (practiceIndex < practiceQuestions.length - 1) {
      setPracticeIndex(prev => prev + 1);
    } else {
      setPracticeIndex(0);
    }
  };

  const handlePracticePrev = () => {
    triggerHaptic(10);
    setPracticeAnswer(null);
    setShowPracticeExplanation(false);
    if (practiceIndex > 0) {
      setPracticeIndex(prev => prev - 1);
    }
  };

  // CBT Mode Handlers
  const handleStartCbtExam = () => {
    triggerHaptic(25);
    setCbtTimeLeft(180 * 60); // 180 Minutes (Full TG EAPCET Standard)
    const initialStatuses: Record<string, QuestionStatus> = {};
    const initialAnswers: Record<string, number | null> = {};
    activePaper.allQuestions.forEach((q, idx) => {
      initialStatuses[q.id] = idx === 0 ? 'not_answered' : 'not_visited';
      initialAnswers[q.id] = null;
    });
    setCbtStatuses(initialStatuses);
    setCbtAnswers(initialAnswers);
    setCbtActiveIndex(0);
    setCbtSection('maths');
    setCbtStarted(true);
    setCbtSubmitted(false);
    setCbtResult(null);
  };

  const currentCbtQ = activePaper.allQuestions[cbtActiveIndex] || activePaper.allQuestions[0];
  const currentCbtAnswer = cbtAnswers[currentCbtQ?.id] ?? null;

  const handleCbtSelectOption = (optIdx: number) => {
    triggerHaptic(15);
    setCbtAnswers(prev => ({ ...prev, [currentCbtQ.id]: optIdx }));
  };

  const handleCbtClear = () => {
    triggerHaptic(10);
    setCbtAnswers(prev => ({ ...prev, [currentCbtQ.id]: null }));
    setCbtStatuses(prev => ({ ...prev, [currentCbtQ.id]: 'not_answered' }));
  };

  const handleCbtMarkForReview = () => {
    triggerHaptic(15);
    const hasAns = cbtAnswers[currentCbtQ.id] !== null;
    setCbtStatuses(prev => ({
      ...prev,
      [currentCbtQ.id]: hasAns ? 'answered_and_marked' : 'marked_for_review'
    }));
    cbtGoNext();
  };

  const handleCbtSaveAndNext = () => {
    triggerHaptic(15);
    const hasAns = cbtAnswers[currentCbtQ.id] !== null;
    setCbtStatuses(prev => ({
      ...prev,
      [currentCbtQ.id]: hasAns ? 'answered' : 'not_answered'
    }));
    cbtGoNext();
  };

  const cbtGoNext = () => {
    if (cbtActiveIndex < activePaper.allQuestions.length - 1) {
      const nextIdx = cbtActiveIndex + 1;
      setCbtActiveIndex(nextIdx);
      const nextQ = activePaper.allQuestions[nextIdx];
      updateCbtSectionByQuestion(nextQ);
      setCbtStatuses(prev => {
        if (prev[nextQ.id] === 'not_visited') {
          return { ...prev, [nextQ.id]: 'not_answered' };
        }
        return prev;
      });
    }
  };

  const cbtGoPrev = () => {
    if (cbtActiveIndex > 0) {
      const prevIdx = cbtActiveIndex - 1;
      setCbtActiveIndex(prevIdx);
      updateCbtSectionByQuestion(activePaper.allQuestions[prevIdx]);
    }
  };

  const updateCbtSectionByQuestion = (q: Question) => {
    if (q.subjectId === 'maths_a' || q.subjectId === 'maths_b') {
      setCbtSection('maths');
    } else if (q.subjectId === 'physics') {
      setCbtSection('physics');
    } else {
      setCbtSection('chemistry');
    }
  };

  const jumpToCbtQuestion = (idx: number) => {
    triggerHaptic(10);
    const targetQ = activePaper.allQuestions[idx];
    if (!targetQ) return;
    setCbtActiveIndex(idx);
    updateCbtSectionByQuestion(targetQ);
    setShowPaletteDrawer(false);
    setCbtStatuses(prev => {
      if (prev[targetQ.id] === 'not_visited') {
        return { ...prev, [targetQ.id]: 'not_answered' };
      }
      return prev;
    });
  };

  const handleCbtSubmit = () => {
    triggerHaptic(30);
    let correct = 0;
    let wrong = 0;
    let attempted = 0;

    const breakdown: Record<SubjectId, { total: number; correct: number }> = {
      maths_a: { total: 0, correct: 0 },
      maths_b: { total: 0, correct: 0 },
      physics: { total: 0, correct: 0 },
      chemistry: { total: 0, correct: 0 }
    };

    activePaper.allQuestions.forEach(q => {
      breakdown[q.subjectId].total += 1;
      const ans = cbtAnswers[q.id];
      if (ans !== null && ans !== undefined) {
        attempted += 1;
        if (ans === q.correctIndex) {
          correct += 1;
          breakdown[q.subjectId].correct += 1;
        } else {
          wrong += 1;
        }
      }
    });

    const scaledScore = Math.round((correct / (activePaper.allQuestions.length || 1)) * 160);
    const rankInfo = estimateRank(scaledScore);

    const result: TestResult = {
      id: `pyq_test_${Date.now()}`,
      testTitle: `${activePaper.examTitle} (180-Min CBT)`,
      date: 'Today',
      totalQuestions: activePaper.allQuestions.length,
      attempted,
      correct,
      wrong,
      score: correct,
      timeSpentSeconds: 180 * 60 - cbtTimeLeft,
      subjectBreakdown: breakdown,
      predictedRank: scaledScore > 130 ? 320 : scaledScore > 100 ? 1850 : 8500,
      answers: cbtAnswers
    };

    setCbtResult(result);
    saveTestResult(result);
    setCbtSubmitted(true);

    confetti({
      particleCount: 50,
      spread: 80,
      origin: { y: 0.6 }
    });
  };

  // Status tally for Question Palette
  const cbtStatusCounts = useMemo(() => {
    const counts = {
      answered: 0,
      not_answered: 0,
      not_visited: 0,
      marked_for_review: 0,
      answered_and_marked: 0
    };
    Object.values(cbtStatuses).forEach(s => {
      if (counts[s] !== undefined) counts[s]++;
    });
    return counts;
  }, [cbtStatuses]);

  // Section filtered questions in CBT
  const cbtSectionQuestions = useMemo(() => {
    return activePaper.allQuestions
      .map((q, idx) => ({ q, idx }))
      .filter(item => {
        if (cbtSection === 'maths') return item.q.subjectId === 'maths_a' || item.q.subjectId === 'maths_b';
        if (cbtSection === 'physics') return item.q.subjectId === 'physics';
        return item.q.subjectId === 'chemistry';
      });
  }, [activePaper, cbtSection]);

  // If in CBT mode and submitted, show the comprehensive analysis
  if (selectedPYQMode === 'cbt' && cbtSubmitted && cbtResult) {
    const scaledScore = Math.round((cbtResult.correct / cbtResult.totalQuestions) * 160);
    const rankInfo = estimateRank(scaledScore);

    return (
      <div className="flex-1 flex flex-col p-4 pb-20 space-y-4 animate-fade-in">
        {/* Score Card Header */}
        <div className="rounded-2xl bg-gradient-to-br from-indigo-950 via-slate-900 to-slate-950 border border-indigo-500/40 p-5 text-center">
          <div className="w-14 h-14 rounded-2xl bg-indigo-600/30 border border-indigo-500/40 mx-auto flex items-center justify-center text-indigo-300 mb-3 shadow-lg">
            <Trophy className="w-7 h-7 text-amber-400" />
          </div>
          <span className="text-[11px] font-bold text-indigo-400 uppercase tracking-wider block">
            {activePaper.examTitle} Result
          </span>
          <h1 className="text-2xl font-bold text-white tracking-tight mt-1">
            Score: {cbtResult.correct} / {cbtResult.totalQuestions}
          </h1>
          <p className="text-xs text-slate-300 mt-1">
            Time Taken: {formatTimer(cbtResult.timeSpentSeconds)} · Accuracy: {Math.round((cbtResult.correct / (cbtResult.attempted || 1)) * 100)}%
          </p>

          {/* Predicted Rank & College Eligibility */}
          <div className="mt-4 p-3 rounded-xl bg-slate-950/80 border border-indigo-500/30 text-left space-y-1.5">
            <div className="flex items-center justify-between text-xs pb-1 border-b border-slate-800">
              <span className="text-slate-400">Estimated TG EAPCET State Rank:</span>
              <span className="text-amber-400 font-bold text-sm">{rankInfo.rankRange}</span>
            </div>
            <div className="flex items-center justify-between text-xs">
              <span className="text-slate-400">College Admission Prospect:</span>
              <span className="text-emerald-400 font-semibold">{rankInfo.category}</span>
            </div>
          </div>
        </div>

        {/* Subject-Wise Performance */}
        <div className="space-y-2">
          <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider">
            Subject-Wise Score Breakdown
          </h3>
          <div className="grid grid-cols-3 gap-2">
            <div className="p-3 rounded-xl bg-slate-900 border border-sky-500/30 text-center">
              <span className="text-[10px] text-sky-400 font-bold block">Mathematics</span>
              <span className="text-base font-bold text-white tabular-nums">
                {cbtResult.subjectBreakdown.maths_a.correct + cbtResult.subjectBreakdown.maths_b.correct} / {cbtResult.subjectBreakdown.maths_a.total + cbtResult.subjectBreakdown.maths_b.total}
              </span>
            </div>
            <div className="p-3 rounded-xl bg-slate-900 border border-amber-500/30 text-center">
              <span className="text-[10px] text-amber-400 font-bold block">Physics</span>
              <span className="text-base font-bold text-white tabular-nums">
                {cbtResult.subjectBreakdown.physics.correct} / {cbtResult.subjectBreakdown.physics.total}
              </span>
            </div>
            <div className="p-3 rounded-xl bg-slate-900 border border-emerald-500/30 text-center">
              <span className="text-[10px] text-emerald-400 font-bold block">Chemistry</span>
              <span className="text-base font-bold text-white tabular-nums">
                {cbtResult.subjectBreakdown.chemistry.correct} / {cbtResult.subjectBreakdown.chemistry.total}
              </span>
            </div>
          </div>
        </div>

        {/* Question by Question Review */}
        <div className="space-y-3">
          <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider">
            Detailed Solutions & Answer Key
          </h3>
          {activePaper.allQuestions.map((q, idx) => {
            const userAns = cbtAnswers[q.id];
            const isCorrect = userAns === q.correctIndex;
            const isUnattempted = userAns === null || userAns === undefined;

            return (
              <div 
                key={q.id}
                className={`p-3.5 rounded-2xl border ${
                  isCorrect 
                    ? 'bg-emerald-950/20 border-emerald-500/40' 
                    : isUnattempted 
                    ? 'bg-slate-900/60 border-slate-800' 
                    : 'bg-rose-950/20 border-rose-500/40'
                }`}
              >
                <div className="flex items-center justify-between text-[11px] pb-1 border-b border-slate-800/80 mb-2">
                  <div className="flex items-center gap-1.5">
                    <span className="font-bold text-slate-300">Q{idx + 1}.</span>
                    <span className="text-slate-400">{SUBJECTS[q.subjectId].name}</span>
                  </div>
                  <div>
                    {isCorrect ? (
                      <span className="text-emerald-400 font-bold flex items-center gap-1">
                        <CheckCircle2 className="w-3.5 h-3.5" /> +1 Mark
                      </span>
                    ) : isUnattempted ? (
                      <span className="text-slate-400 font-medium">Unattempted (0)</span>
                    ) : (
                      <span className="text-rose-400 font-bold flex items-center gap-1">
                        <AlertCircle className="w-3.5 h-3.5" /> 0 Marks
                      </span>
                    )}
                  </div>
                </div>

                <p className="text-xs font-semibold text-slate-200 font-math mb-2 leading-relaxed">
                  {q.question}
                </p>

                <div className="text-[11px] space-y-1 mb-2 font-math">
                  <div className="text-emerald-400 font-medium">
                    Correct Answer: ({String.fromCharCode(65 + q.correctIndex)}) {q.options[q.correctIndex]}
                  </div>
                  {!isCorrect && !isUnattempted && (
                    <div className="text-rose-400">
                      Your Choice: ({String.fromCharCode(65 + (userAns as number))}) {q.options[userAns as number]}
                    </div>
                  )}
                </div>

                {q.shortcutTrick && (
                  <div className="p-2 rounded-lg bg-amber-500/10 border border-amber-500/20 text-amber-200 text-[11px] font-math mb-2">
                    <span className="font-bold text-amber-300">Bogaraju Rajesh's Shortcut: </span>
                    {q.shortcutTrick}
                  </div>
                )}

                <div className="text-[11px] text-slate-400 leading-relaxed font-math whitespace-pre-line border-t border-slate-800/60 pt-1.5">
                  {q.explanation}
                </div>
              </div>
            );
          })}
        </div>

        {/* Retake Paper Button */}
        <button
          onClick={() => {
            setCbtStarted(false);
            setCbtSubmitted(false);
          }}
          className="w-full py-3 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-lg active:scale-95 transition-all"
        >
          <RotateCcw className="w-4 h-4" />
          <span>Retake This Paper in CBT Mode</span>
        </button>
      </div>
    );
  }

  // If in CBT mode and EXAM IS ACTIVE
  if (selectedPYQMode === 'cbt' && cbtStarted) {
    return (
      <div className="flex-1 flex flex-col h-full bg-slate-950 text-slate-100 select-none pb-16">
        {/* CBT Top Bar: Candidate & 180-min Timer */}
        <div className="sticky top-0 z-30 bg-slate-900 border-b border-slate-800 px-3 py-2 flex items-center justify-between text-xs">
          <div>
            <div className="flex items-center gap-1.5">
              <span className="font-bold text-white text-xs">{activePaper.shiftCode} CBT</span>
              <span className="text-[10px] text-slate-400">| TG EAPCET {activePaper.year}</span>
            </div>
            <span className="text-[10px] text-indigo-400 font-medium">
              Section: {cbtSection === 'maths' ? 'Mathematics (80M)' : cbtSection === 'physics' ? 'Physics (40M)' : 'Chemistry (40M)'}
            </span>
          </div>

          <div className="flex items-center gap-2">
            <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-slate-950 border border-slate-800 text-amber-300 font-mono font-bold text-xs">
              <Clock className="w-3.5 h-3.5 text-amber-400" />
              <span className="tabular-nums">{formatTimer(cbtTimeLeft)}</span>
            </div>

            <button
              onClick={() => setShowPaletteDrawer(true)}
              className="p-1.5 rounded-lg bg-indigo-600/20 border border-indigo-500/40 text-indigo-300"
              title="Question Palette"
            >
              <ListOrdered className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Section Tabs: Mathematics | Physics | Chemistry */}
        <div className="flex items-center overflow-x-auto no-scrollbar border-b border-slate-800 bg-slate-950 px-2 py-1 gap-1 text-xs">
          <button
            onClick={() => {
              triggerHaptic(10);
              setCbtSection('maths');
              const firstMathsIdx = activePaper.allQuestions.findIndex(q => q.subjectId === 'maths_a' || q.subjectId === 'maths_b');
              if (firstMathsIdx !== -1) jumpToCbtQuestion(firstMathsIdx);
            }}
            className={`px-3 py-1.5 rounded-lg font-semibold whitespace-nowrap transition-all ${
              cbtSection === 'maths' ? 'bg-sky-500 text-slate-950 font-bold shadow-sm' : 'text-slate-400'
            }`}
          >
            Mathematics
          </button>
          <button
            onClick={() => {
              triggerHaptic(10);
              setCbtSection('physics');
              const firstPhyIdx = activePaper.allQuestions.findIndex(q => q.subjectId === 'physics');
              if (firstPhyIdx !== -1) jumpToCbtQuestion(firstPhyIdx);
            }}
            className={`px-3 py-1.5 rounded-lg font-semibold whitespace-nowrap transition-all ${
              cbtSection === 'physics' ? 'bg-amber-500 text-slate-950 font-bold shadow-sm' : 'text-slate-400'
            }`}
          >
            Physics
          </button>
          <button
            onClick={() => {
              triggerHaptic(10);
              setCbtSection('chemistry');
              const firstChemIdx = activePaper.allQuestions.findIndex(q => q.subjectId === 'chemistry');
              if (firstChemIdx !== -1) jumpToCbtQuestion(firstChemIdx);
            }}
            className={`px-3 py-1.5 rounded-lg font-semibold whitespace-nowrap transition-all ${
              cbtSection === 'chemistry' ? 'bg-emerald-500 text-slate-950 font-bold shadow-sm' : 'text-slate-400'
            }`}
          >
            Chemistry
          </button>
        </div>

        {/* Question Workspace */}
        <div className="flex-1 p-4 overflow-y-auto space-y-4 no-scrollbar">
          <div className="flex items-center justify-between text-xs pb-2 border-b border-slate-800">
            <span className="font-bold text-indigo-300">
              Question {cbtActiveIndex + 1} of {activePaper.allQuestions.length}
            </span>
            <div className="text-[10px] text-slate-400 font-medium">
              Marks: <span className="text-emerald-400 font-bold">+1.0</span> · Neg: <span className="text-slate-400 font-bold">0.0</span>
            </div>
          </div>

          <div className="text-sm font-semibold text-slate-100 font-math leading-relaxed select-text py-1">
            {currentCbtQ.question}
          </div>

          {/* Options */}
          <div className="space-y-2 pt-2">
            {currentCbtQ.options.map((opt, idx) => {
              const isSelected = currentCbtAnswer === idx;
              return (
                <button
                  key={idx}
                  onClick={() => handleCbtSelectOption(idx)}
                  className={`w-full min-h-[46px] p-3 rounded-xl border text-xs text-left transition-all flex items-start gap-3 active:scale-[0.99] ${
                    isSelected
                      ? 'bg-indigo-600/30 border-indigo-500 text-white font-medium ring-1 ring-indigo-500'
                      : 'bg-slate-900/80 border-slate-800 text-slate-300 hover:border-slate-700'
                  }`}
                >
                  <span className={`w-5 h-5 rounded-full border flex items-center justify-center font-bold text-[11px] shrink-0 ${
                    isSelected ? 'bg-indigo-600 border-indigo-400 text-white' : 'border-slate-700 text-slate-400'
                  }`}>
                    {String.fromCharCode(65 + idx)}
                  </span>
                  <span className="font-math leading-snug">{opt}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Bottom CBT Action Bar */}
        <div className="sticky bottom-0 left-0 right-0 z-30 bg-slate-900 border-t border-slate-800 p-2.5 flex items-center justify-between gap-1.5 text-xs">
          <div className="flex items-center gap-1">
            <button
              onClick={cbtGoPrev}
              disabled={cbtActiveIndex === 0}
              className="p-2 rounded-xl bg-slate-950 border border-slate-800 text-slate-400 disabled:opacity-30 hover:text-slate-200"
              title="Previous Question"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <button
              onClick={handleCbtClear}
              className="px-2.5 py-2 rounded-xl bg-slate-950 border border-slate-800 text-slate-400 hover:text-slate-200 text-[11px] font-medium"
            >
              Clear
            </button>
            <button
              onClick={handleCbtMarkForReview}
              className="px-2.5 py-2 rounded-xl bg-purple-950/60 border border-purple-500/40 text-purple-300 text-[11px] font-medium whitespace-nowrap"
            >
              Review & Next
            </button>
          </div>

          <div className="flex items-center gap-1.5">
            <button
              onClick={handleCbtSaveAndNext}
              className="px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-[11px] shadow-sm active:scale-95 transition-all whitespace-nowrap"
            >
              Save & Next
            </button>
            <button
              onClick={handleCbtSubmit}
              className="px-3 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-bold text-[11px] shadow-sm active:scale-95 transition-all whitespace-nowrap"
            >
              Submit 180-Min Test
            </button>
          </div>
        </div>

        {/* Question Palette Drawer Modal */}
        {showPaletteDrawer && (
          <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex flex-col justify-end animate-fade-in">
            <div className="bg-slate-900 border-t border-slate-800 rounded-t-3xl max-h-[80vh] flex flex-col overflow-hidden p-4">
              <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                <h3 className="text-sm font-bold text-white">
                  {activePaper.shiftCode} Question Palette
                </h3>
                <button 
                  onClick={() => setShowPaletteDrawer(false)}
                  className="p-1 rounded-lg text-slate-400 hover:text-white"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Status Summary */}
              <div className="grid grid-cols-4 gap-2 py-3 text-[10px] text-center border-b border-slate-800">
                <div className="bg-emerald-950/50 border border-emerald-500/40 rounded-lg p-1.5 text-emerald-300 font-semibold">
                  <span className="block text-xs font-bold">{cbtStatusCounts.answered}</span>
                  Answered
                </div>
                <div className="bg-rose-950/50 border border-rose-500/40 rounded-lg p-1.5 text-rose-300 font-semibold">
                  <span className="block text-xs font-bold">{cbtStatusCounts.not_answered}</span>
                  Not Answered
                </div>
                <div className="bg-purple-950/50 border border-purple-500/40 rounded-lg p-1.5 text-purple-300 font-semibold">
                  <span className="block text-xs font-bold">{cbtStatusCounts.marked_for_review + cbtStatusCounts.answered_and_marked}</span>
                  Marked
                </div>
                <div className="bg-slate-800/50 border border-slate-700/40 rounded-lg p-1.5 text-slate-300 font-semibold">
                  <span className="block text-xs font-bold">{cbtStatusCounts.not_visited}</span>
                  Not Visited
                </div>
              </div>

              {/* Question Buttons */}
              <div className="py-4 overflow-y-auto max-h-[40vh] grid grid-cols-5 gap-2 no-scrollbar">
                {cbtSectionQuestions.map(({ q, idx }) => {
                  const status = cbtStatuses[q.id] || 'not_visited';
                  let btnColor = 'bg-slate-800 text-slate-400 border-slate-700';
                  if (status === 'answered') {
                    btnColor = 'bg-emerald-600 text-white border-emerald-400 font-bold';
                  } else if (status === 'not_answered') {
                    btnColor = 'bg-rose-600 text-white border-rose-400 font-bold';
                  } else if (status === 'marked_for_review') {
                    btnColor = 'bg-purple-600 text-white border-purple-400 font-bold';
                  } else if (status === 'answered_and_marked') {
                    btnColor = 'bg-purple-600 text-white border-purple-400 font-bold ring-2 ring-emerald-400';
                  }

                  const isCurrent = idx === cbtActiveIndex;

                  return (
                    <button
                      key={q.id}
                      onClick={() => jumpToCbtQuestion(idx)}
                      className={`h-10 rounded-xl border flex items-center justify-center text-xs font-mono transition-transform active:scale-90 ${btnColor} ${
                        isCurrent ? 'ring-2 ring-white scale-105' : ''
                      }`}
                    >
                      {idx + 1}
                    </button>
                  );
                })}
              </div>

              <button
                onClick={() => setShowPaletteDrawer(false)}
                className="w-full py-2.5 rounded-xl bg-slate-800 text-slate-200 font-semibold text-xs mt-2"
              >
                Close Palette
              </button>
            </div>
          </div>
        )}
      </div>
    );
  }

  // MAIN PYQ HUB (SELECTION & PRACTICE MODE / LAUNCH CBT)
  const availablePapersForYear = PYQ_PAPERS.filter(p => p.year === selectedYear);

  return (
    <div className="flex-1 flex flex-col p-4 pb-20 space-y-4 animate-fade-in">
      {/* Top Banner Header */}
      <div className="rounded-2xl bg-gradient-to-br from-indigo-950 via-slate-900 to-slate-950 border border-indigo-500/30 p-4">
        <div className="flex items-center gap-2 text-xs font-bold text-indigo-400 mb-1">
          <GraduationCap className="w-4 h-4" />
          <span>TG EAPCET PREVIOUS YEAR QUESTIONS (PYQs)</span>
        </div>
        <h1 className="text-xl font-bold text-white tracking-tight">
          2026 & 2025 Engineering (MPC) Papers
        </h1>
        <p className="text-xs text-slate-300 mt-1 leading-relaxed">
          Official shift-wise previous year question papers for Mathematics, Physics, and Chemistry. Practice question-by-question with Bogaraju Rajesh's shortcut tricks or take the full 180-minute CBT exam simulation.
        </p>

        {/* Year Selector Tabs */}
        <div className="mt-4 flex items-center gap-2 p-1 bg-slate-950 border border-slate-800 rounded-xl">
          <button
            onClick={() => {
              triggerHaptic(15);
              setSelectedYear(2026);
              const p26 = PYQ_PAPERS.find(p => p.year === 2026);
              if (p26) setSelectedPYQPaperId(p26.id);
            }}
            className={`flex-1 py-2 rounded-lg text-xs font-bold transition-all ${
              selectedYear === 2026
                ? 'bg-indigo-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            2026 TG EAPCET Papers
          </button>
          <button
            onClick={() => {
              triggerHaptic(15);
              setSelectedYear(2025);
              const p25 = PYQ_PAPERS.find(p => p.year === 2025);
              if (p25) setSelectedPYQPaperId(p25.id);
            }}
            className={`flex-1 py-2 rounded-lg text-xs font-bold transition-all ${
              selectedYear === 2025
                ? 'bg-indigo-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            2025 TG EAPCET Papers
          </button>
        </div>
      </div>

      {/* Shift Selection Pills */}
      <div className="space-y-1.5">
        <label className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
          Select Exam Shift:
        </label>
        <div className="grid grid-cols-2 gap-2">
          {availablePapersForYear.map((paper) => {
            const isSelected = activePaper.id === paper.id;
            return (
              <div
                key={paper.id}
                onClick={() => {
                  triggerHaptic(15);
                  setSelectedPYQPaperId(paper.id);
                }}
                className={`cursor-pointer p-3 rounded-2xl border transition-all text-left ${
                  isSelected
                    ? 'bg-indigo-950/60 border-indigo-500 shadow-md ring-1 ring-indigo-500/50'
                    : 'bg-slate-900 border-slate-800 hover:border-slate-700'
                }`}
              >
                <div className="flex items-center justify-between mb-1">
                  <span className={`text-[10px] font-bold px-1.5 py-0.2 rounded ${
                    isSelected ? 'bg-indigo-500 text-white' : 'bg-slate-800 text-slate-300'
                  }`}>
                    {paper.shiftCode}
                  </span>
                  <span className="text-[10px] text-slate-400 font-mono">180 Mins</span>
                </div>
                <h4 className="text-xs font-bold text-white truncate">
                  {paper.shift}
                </h4>
                <p className="text-[10px] text-slate-400 mt-0.5">
                  {paper.sessionTime}
                </p>
                <div className="mt-2 text-[10px] text-indigo-300 font-medium">
                  {paper.totalQuestions} Questions · 160M Total
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Mode Switcher: Practice Mode vs Full CBT 180-Min Exam */}
      <div className="flex items-center gap-2 p-1 bg-slate-900 border border-slate-800 rounded-xl text-xs font-bold">
        <button
          onClick={() => {
            triggerHaptic(15);
            setSelectedPYQMode('practice');
          }}
          className={`flex-1 py-2 rounded-lg flex items-center justify-center gap-1.5 transition-all ${
            selectedPYQMode === 'practice'
              ? 'bg-slate-800 text-white shadow-sm ring-1 ring-slate-700'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <BookOpen className="w-3.5 h-3.5 text-indigo-400" />
          <span>Practice Mode (Instant Solutions)</span>
        </button>
        <button
          onClick={() => {
            triggerHaptic(15);
            setSelectedPYQMode('cbt');
          }}
          className={`flex-1 py-2 rounded-lg flex items-center justify-center gap-1.5 transition-all ${
            selectedPYQMode === 'cbt'
              ? 'bg-indigo-600 text-white shadow-sm'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <Play className="w-3.5 h-3.5 text-emerald-400" />
          <span>Full CBT Mode (180 Mins)</span>
        </button>
      </div>

      {/* IF IN FULL CBT LAUNCH SCREEN */}
      {selectedPYQMode === 'cbt' && !cbtStarted && (
        <div className="rounded-2xl bg-slate-900 border border-slate-800 p-4 space-y-3">
          <div className="flex items-center gap-2 text-xs font-bold text-emerald-400">
            <Clock className="w-4 h-4" />
            <span>Ready for {activePaper.examTitle}</span>
          </div>
          <p className="text-xs text-slate-300 leading-relaxed">
            Take this real exam paper in the official 180-minute computer-based test environment. Features section navigation, authentic question palette, and detailed performance analysis upon submission.
          </p>

          <div className="grid grid-cols-3 gap-2 text-center text-xs py-2 border-y border-slate-800">
            <div>
              <span className="text-[10px] text-slate-400 block">Duration</span>
              <span className="font-bold text-white">180 Mins</span>
            </div>
            <div>
              <span className="text-[10px] text-slate-400 block">Total Marks</span>
              <span className="font-bold text-indigo-400">160 Marks</span>
            </div>
            <div>
              <span className="text-[10px] text-slate-400 block">Marking</span>
              <span className="font-bold text-emerald-400">+1 / 0 (No Neg)</span>
            </div>
          </div>

          <button
            onClick={handleStartCbtExam}
            className="w-full py-3.5 rounded-xl bg-gradient-to-r from-indigo-600 to-sky-600 hover:from-indigo-500 hover:to-sky-500 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-lg shadow-indigo-600/30 active:scale-95 transition-all"
          >
            <Play className="w-4 h-4 fill-white" />
            <span>Start 180-Minute CBT Test Now</span>
          </button>
        </div>
      )}

      {/* IF IN PRACTICE MODE */}
      {selectedPYQMode === 'practice' && (
        <div className="space-y-3">
          {/* Subject Separation Tabs */}
          <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar pb-1 text-xs">
            <button
              onClick={() => {
                triggerHaptic(10);
                setSubjectFilter('all');
                setPracticeIndex(0);
                setPracticeAnswer(null);
              }}
              className={`px-3 py-1.5 rounded-xl font-bold whitespace-nowrap transition-all ${
                subjectFilter === 'all'
                  ? 'bg-slate-200 text-slate-950'
                  : 'bg-slate-900 text-slate-400 border border-slate-800'
              }`}
            >
              All MPC Questions ({activePaper.allQuestions.length})
            </button>
            <button
              onClick={() => {
                triggerHaptic(10);
                setSubjectFilter('maths');
                setPracticeIndex(0);
                setPracticeAnswer(null);
              }}
              className={`px-3 py-1.5 rounded-xl font-bold whitespace-nowrap transition-all ${
                subjectFilter === 'maths'
                  ? 'bg-sky-500 text-slate-950'
                  : 'bg-slate-900 text-slate-400 border border-slate-800'
              }`}
            >
              Mathematics ({activePaper.mathsQuestions.length})
            </button>
            <button
              onClick={() => {
                triggerHaptic(10);
                setSubjectFilter('physics');
                setPracticeIndex(0);
                setPracticeAnswer(null);
              }}
              className={`px-3 py-1.5 rounded-xl font-bold whitespace-nowrap transition-all ${
                subjectFilter === 'physics'
                  ? 'bg-amber-500 text-slate-950'
                  : 'bg-slate-900 text-slate-400 border border-slate-800'
              }`}
            >
              Physics ({activePaper.physicsQuestions.length})
            </button>
            <button
              onClick={() => {
                triggerHaptic(10);
                setSubjectFilter('chemistry');
                setPracticeIndex(0);
                setPracticeAnswer(null);
              }}
              className={`px-3 py-1.5 rounded-xl font-bold whitespace-nowrap transition-all ${
                subjectFilter === 'chemistry'
                  ? 'bg-emerald-500 text-slate-950'
                  : 'bg-slate-900 text-slate-400 border border-slate-800'
              }`}
            >
              Chemistry ({activePaper.chemistryQuestions.length})
            </button>
          </div>

          {/* Interactive MCQ Card */}
          {currentPracticeQ && (
            <div className="rounded-2xl bg-slate-900 border border-slate-800 p-4 shadow-xl space-y-4">
              {/* Question Header */}
              <div className="flex items-center justify-between text-xs pb-2 border-b border-slate-800">
                <div className="flex items-center gap-2">
                  <span className={`px-2 py-0.5 rounded font-bold text-[10px] ${
                    SUBJECTS[currentPracticeQ.subjectId].accentBg
                  }`}>
                    {SUBJECTS[currentPracticeQ.subjectId].name}
                  </span>
                  <span className="text-[10px] font-bold text-amber-400 bg-amber-500/10 px-1.5 py-0.2 rounded border border-amber-500/30">
                    {activePaper.year} {activePaper.shiftCode}
                  </span>
                </div>

                <button
                  onClick={() => toggleBookmark(currentPracticeQ.id)}
                  className="p-1.5 rounded-lg bg-slate-950 border border-slate-800 text-slate-400 hover:text-amber-400 active:scale-95 transition-all"
                  title="Bookmark Question"
                >
                  {isBookmarked(currentPracticeQ.id) ? (
                    <BookmarkCheck className="w-4 h-4 text-amber-400 fill-amber-400" />
                  ) : (
                    <Bookmark className="w-4 h-4" />
                  )}
                </button>
              </div>

              {/* Chapter title */}
              <div className="text-[11px] font-medium text-slate-400">
                {currentPracticeQ.chapterTitle}
              </div>

              {/* Question text */}
              <div className="text-sm font-semibold text-slate-100 font-math leading-relaxed select-text">
                {currentPracticeQ.question}
              </div>

              {/* 4 Options */}
              <div className="space-y-2 pt-1">
                {currentPracticeQ.options.map((opt, idx) => {
                  const isSelected = practiceAnswer === idx;
                  const isCorrect = idx === currentPracticeQ.correctIndex;

                  let optStyle = 'bg-slate-950 border-slate-800 hover:border-slate-700 text-slate-200';
                  if (practiceAnswer !== null) {
                    if (isCorrect) {
                      optStyle = 'bg-emerald-950/70 border-emerald-500 text-emerald-100 font-semibold ring-1 ring-emerald-500/50';
                    } else if (isSelected) {
                      optStyle = 'bg-rose-950/70 border-rose-500 text-rose-100 font-semibold ring-1 ring-rose-500/50';
                    } else {
                      optStyle = 'bg-slate-950/50 border-slate-900 text-slate-500 opacity-60';
                    }
                  }

                  return (
                    <button
                      key={idx}
                      disabled={practiceAnswer !== null}
                      onClick={() => handlePracticeSelectOption(idx)}
                      className={`w-full min-h-[46px] p-3 rounded-xl border text-xs text-left transition-all flex items-start justify-between gap-3 active:scale-[0.99] ${optStyle}`}
                    >
                      <div className="flex items-start gap-2.5">
                        <span className="w-5 h-5 rounded-md bg-slate-800/80 text-slate-300 font-bold text-[11px] flex items-center justify-center shrink-0">
                          {String.fromCharCode(65 + idx)}
                        </span>
                        <span className="font-math leading-snug">{opt}</span>
                      </div>
                      {practiceAnswer !== null && isCorrect && (
                        <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                      )}
                      {practiceAnswer !== null && isSelected && !isCorrect && (
                        <XCircle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                      )}
                    </button>
                  );
                })}
              </div>

              {/* Shortcut & Explanation */}
              {showPracticeExplanation && (
                <div className="space-y-3 pt-3 border-t border-slate-800 animate-fade-in">
                  {currentPracticeQ.shortcutTrick && (
                    <div className="p-3 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-200 text-xs">
                      <div className="font-bold flex items-center gap-1.5 text-amber-300 mb-1">
                        <Sparkles className="w-4 h-4 text-amber-400" />
                        <span>Bogaraju Rajesh's 10-Second Shortcut Trick:</span>
                      </div>
                      <p className="font-math leading-relaxed text-slate-200 pl-5">
                        {currentPracticeQ.shortcutTrick}
                      </p>
                    </div>
                  )}

                  <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-300 leading-relaxed font-math whitespace-pre-line">
                    <span className="font-bold text-slate-200 block mb-1">Step-by-Step TG EAPCET Solution:</span>
                    {currentPracticeQ.explanation}
                  </div>
                </div>
              )}

              {/* Practice Navigation */}
              <div className="flex items-center justify-between pt-2 border-t border-slate-800 text-xs">
                <button
                  onClick={handlePracticePrev}
                  disabled={practiceIndex === 0}
                  className="flex items-center gap-1 px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-slate-300 disabled:opacity-40 hover:bg-slate-800 transition-all"
                >
                  <ChevronLeft className="w-4 h-4" />
                  <span>Previous</span>
                </button>

                <span className="text-slate-400 font-mono text-[11px] tabular-nums">
                  {practiceIndex + 1} / {practiceQuestions.length}
                </span>

                <button
                  onClick={handlePracticeNext}
                  className="flex items-center gap-1 px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-semibold transition-all shadow-md active:scale-95"
                >
                  <span>Next</span>
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
