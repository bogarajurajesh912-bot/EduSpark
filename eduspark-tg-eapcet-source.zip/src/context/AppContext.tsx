import React, { createContext, useContext, useState, useEffect } from 'react';
import { SubjectId, AcademicYear, TestResult, UserStats, TabType } from '../types';

interface AppContextType {
  activeTab: TabType;
  setActiveTab: (tab: TabType) => void;
  selectedSubject: SubjectId | 'all';
  setSelectedSubject: (s: SubjectId | 'all') => void;
  selectedYear: AcademicYear | 'all';
  setSelectedYear: (y: AcademicYear | 'all') => void;
  selectedPYQPaperId: string;
  setSelectedPYQPaperId: (id: string) => void;
  selectedPYQMode: 'practice' | 'cbt';
  setSelectedPYQMode: (mode: 'practice' | 'cbt') => void;
  openPYQPaper: (paperId: string, mode?: 'practice' | 'cbt') => void;
  deviceViewMode: 'redmi' | 'fullscreen';
  setDeviceViewMode: (mode: 'redmi' | 'fullscreen') => void;
  stats: UserStats;
  testHistory: TestResult[];
  saveTestResult: (result: TestResult) => void;
  toggleBookmark: (questionId: string) => void;
  isBookmarked: (questionId: string) => boolean;
  toggleSaveFormula: (formulaId: string) => void;
  isFormulaSaved: (formulaId: string) => boolean;
  triggerHaptic: (intensity?: number) => void;
  recordQuestionAttempt: (questionId: string, isCorrect: boolean) => void;
  estimateRank: (score: number) => { rankRange: string; percentile: number; category: string };
  clearHistory: () => void;
}

const DEFAULT_STATS: UserStats = {
  totalTests: 0,
  totalAnswered: 0,
  totalCorrect: 0,
  streakDays: 3,
  lastStudyDate: new Date().toISOString().split('T')[0],
  bookmarkedQuestionIds: ['q_ma_1', 'q_phy_1', 'q_chem_1'],
  mistakeQuestionIds: ['q_mb_2', 'q_phy_5'],
  completedChapterIds: ['matha1_functions', 'phy1_motion'],
  savedFormulaIds: ['f_ma_1', 'f_phy_1', 'f_chem_1']
};

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [activeTab, setActiveTab] = useState<TabType>('home');
  const [selectedSubject, setSelectedSubject] = useState<SubjectId | 'all'>('all');
  const [selectedYear, setSelectedYear] = useState<AcademicYear | 'all'>('all');
  const [selectedPYQPaperId, setSelectedPYQPaperId] = useState<string>('pyq_2026_shift1');
  const [selectedPYQMode, setSelectedPYQMode] = useState<'practice' | 'cbt'>('practice');
  
  // Default to Redmi view on large screens, but adapt cleanly
  const [deviceViewMode, setDeviceViewMode] = useState<'redmi' | 'fullscreen'>('redmi');

  const [stats, setStats] = useState<UserStats>(() => {
    try {
      const saved = localStorage.getItem('eduspark_stats');
      return saved ? JSON.parse(saved) : DEFAULT_STATS;
    } catch {
      return DEFAULT_STATS;
    }
  });

  const [testHistory, setTestHistory] = useState<TestResult[]>(() => {
    try {
      const saved = localStorage.getItem('eduspark_tests');
      return saved ? JSON.parse(saved) : [
        {
          id: 'sample_test_1',
          testTitle: 'TG EAPCET MPC Speed Mini-Mock',
          date: 'Yesterday',
          totalQuestions: 20,
          attempted: 18,
          correct: 15,
          wrong: 3,
          score: 15,
          timeSpentSeconds: 1140,
          subjectBreakdown: {
            maths_a: { total: 5, correct: 4 },
            maths_b: { total: 5, correct: 4 },
            physics: { total: 5, correct: 3 },
            chemistry: { total: 5, correct: 4 }
          },
          predictedRank: 3450,
          answers: {}
        }
      ];
    } catch {
      return [];
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem('eduspark_stats', JSON.stringify(stats));
    } catch (e) {
      console.warn('Could not save to localStorage', e);
    }
  }, [stats]);

  useEffect(() => {
    try {
      localStorage.setItem('eduspark_tests', JSON.stringify(testHistory));
    } catch (e) {
      console.warn('Could not save to localStorage', e);
    }
  }, [testHistory]);

  const triggerHaptic = (intensity: number = 15) => {
    if (typeof window !== 'undefined' && 'vibrate' in navigator) {
      try {
        navigator.vibrate(intensity);
      } catch {
        // Ignore if restricted
      }
    }
  };

  const toggleBookmark = (questionId: string) => {
    triggerHaptic(20);
    setStats(prev => {
      const exists = prev.bookmarkedQuestionIds.includes(questionId);
      const updated = exists
        ? prev.bookmarkedQuestionIds.filter(id => id !== questionId)
        : [...prev.bookmarkedQuestionIds, questionId];
      return { ...prev, bookmarkedQuestionIds: updated };
    });
  };

  const isBookmarked = (questionId: string) => {
    return stats.bookmarkedQuestionIds.includes(questionId);
  };

  const toggleSaveFormula = (formulaId: string) => {
    triggerHaptic(20);
    setStats(prev => {
      const exists = prev.savedFormulaIds.includes(formulaId);
      const updated = exists
        ? prev.savedFormulaIds.filter(id => id !== formulaId)
        : [...prev.savedFormulaIds, formulaId];
      return { ...prev, savedFormulaIds: updated };
    });
  };

  const isFormulaSaved = (formulaId: string) => {
    return stats.savedFormulaIds.includes(formulaId);
  };

  const recordQuestionAttempt = (questionId: string, isCorrect: boolean) => {
    setStats(prev => {
      const mistakes = isCorrect
        ? prev.mistakeQuestionIds.filter(id => id !== questionId)
        : prev.mistakeQuestionIds.includes(questionId)
        ? prev.mistakeQuestionIds
        : [...prev.mistakeQuestionIds, questionId];

      return {
        ...prev,
        totalAnswered: prev.totalAnswered + 1,
        totalCorrect: isCorrect ? prev.totalCorrect + 1 : prev.totalCorrect,
        mistakeQuestionIds: mistakes
      };
    });
  };

  const saveTestResult = (result: TestResult) => {
    setTestHistory(prev => [result, ...prev]);
    setStats(prev => ({
      ...prev,
      totalTests: prev.totalTests + 1,
      totalAnswered: prev.totalAnswered + result.attempted,
      totalCorrect: prev.totalCorrect + result.correct
    }));
  };

  const clearHistory = () => {
    setTestHistory([]);
    setStats({
      ...DEFAULT_STATS,
      totalTests: 0,
      totalAnswered: 0,
      totalCorrect: 0
    });
  };

  /**
   * TG EAPCET Rank Estimator based on 160-mark scale:
   * 145 - 160: Top 100 (JNTUH CSE / OU CSE guaranteed)
   * 130 - 144: Top 500 (CBIT CSE / Vasavi CSE)
   * 115 - 129: 501 - 2,500 (Top Tier 1 Colleges)
   * 95 - 114: 2,501 - 8,000 (VNR VJIET / CVR / MGIT)
   * 75 - 94: 8,001 - 20,000 (Reputed Engineering Colleges)
   * 50 - 74: 20,001 - 45,000
   * < 50: 45,000+
   */
  const estimateRank = (score: number) => {
    // scale to 160 if test was smaller
    if (score >= 140) {
      return { rankRange: 'Top 1 – 250', percentile: 99.8, category: 'Top Tier 1 (JNTUH / OU Campus)' };
    } else if (score >= 120) {
      return { rankRange: '251 – 1,200', percentile: 98.5, category: 'Elite Tier (CBIT, Vasavi, VNR CSE)' };
    } else if (score >= 100) {
      return { rankRange: '1,201 – 4,500', percentile: 95.0, category: 'Top Colleges (IT, ECE, Data Science)' };
    } else if (score >= 80) {
      return { rankRange: '4,501 – 12,000', percentile: 90.0, category: 'Reputed Engineering Colleges' };
    } else if (score >= 60) {
      return { rankRange: '12,001 – 28,000', percentile: 80.0, category: 'Standard Engineering Seats' };
    } else {
      return { rankRange: '28,000 – 65,000+', percentile: 65.0, category: 'Needs Focused Revision' };
    }
  };

  const openPYQPaper = (paperId: string, mode: 'practice' | 'cbt' = 'practice') => {
    triggerHaptic(20);
    setSelectedPYQPaperId(paperId);
    setSelectedPYQMode(mode);
    setActiveTab('pyqs');
  };

  return (
    <AppContext.Provider
      value={{
        activeTab,
        setActiveTab,
        selectedSubject,
        setSelectedSubject,
        selectedYear,
        setSelectedYear,
        selectedPYQPaperId,
        setSelectedPYQPaperId,
        selectedPYQMode,
        setSelectedPYQMode,
        openPYQPaper,
        deviceViewMode,
        setDeviceViewMode,
        stats,
        testHistory,
        saveTestResult,
        toggleBookmark,
        isBookmarked,
        toggleSaveFormula,
        isFormulaSaved,
        triggerHaptic,
        recordQuestionAttempt,
        estimateRank,
        clearHistory
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
