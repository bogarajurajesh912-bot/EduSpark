import JSZip from 'jszip';

export const downloadProjectZip = async () => {
  try {
    // 1. Try to download the pre-built valid zip file directly from public folder
    const response = await fetch('/eduspark-tg-eapcet-source.zip');
    if (response.ok) {
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = 'eduspark-tg-eapcet-source.zip';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      window.URL.revokeObjectURL(url);
      return true;
    }
  } catch (err) {
    console.warn('Direct zip fetch failed, falling back to dynamic zip packaging', err);
  }

  // 2. Dynamic in-browser packaging fallback using JSZip
  try {
    const zip = new JSZip();
    
    // Add metadata & readme
    zip.file('README.md', `# EduSpark - TG EAPCET (MPC) Android App
Created by: Bogaraju Rajesh
Target Device: Android (especially Redmi 15 5G)
Syllabus: Telangana TG EAPCET (Mathematics A & B, Physics, Chemistry - 1st & 2nd Year)

## Setup & Run Locally:
\`\`\`bash
npm install
npm run dev
\`\`\`
`);

    const content = await zip.generateAsync({ type: 'blob' });
    const url = window.URL.createObjectURL(content);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'eduspark-tg-eapcet-source.zip';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    window.URL.revokeObjectURL(url);
    return true;
  } catch (error) {
    console.error('Failed to generate ZIP archive', error);
    return false;
  }
};
