import React from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { PhoneFrame } from './components/PhoneFrame';
import { Header } from './components/Header';
import { BottomNav } from './components/BottomNav';
import { HomeView } from './views/HomeView';
import { PYQView } from './views/PYQView';
import { PracticeView } from './views/PracticeView';
import { MockExamView } from './views/MockExamView';
import { FormulasView } from './views/FormulasView';
import { ExplanationsView } from './views/ExplanationsView';
import { ProgressView } from './views/ProgressView';

const MainAppContent: React.FC = () => {
  const { activeTab } = useApp();

  return (
    <PhoneFrame>
      {/* Top Application Bar */}
      <Header />

      {/* Main View Router */}
      <main className="flex-1 flex flex-col w-full relative">
        {activeTab === 'home' && <HomeView />}
        {activeTab === 'pyqs' && <PYQView />}
        {activeTab === 'practice' && <PracticeView />}
        {activeTab === 'mock' && <MockExamView />}
        {activeTab === 'formulas' && <FormulasView />}
        {activeTab === 'explanations' && <ExplanationsView />}
        {activeTab === 'progress' && <ProgressView />}
      </main>

      {/* Bottom Thumb Navigation Bar (Hidden when inside active CBT mock exam is handled inside BottomNav or kept accessible) */}
      <BottomNav />
    </PhoneFrame>
  );
};

export default function App() {
  return (
    <AppProvider>
      <MainAppContent />
    </AppProvider>
  );
}
