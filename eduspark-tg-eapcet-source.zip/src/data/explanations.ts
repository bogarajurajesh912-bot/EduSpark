import { ChapterExplanation } from '../types';

export const CHAPTER_EXPLANATIONS: Record<string, ChapterExplanation> = {
  // --- MATHEMATICS A ---
  'matha1_matrices': {
    chapterId: 'matha1_matrices',
    chapterTitle: 'Matrices and Determinants (1st Year)',
    subjectId: 'maths_a',
    year: '1st',
    weightageRank: 'Very High (5–6 Marks)',
    keyConcepts: [
      {
        heading: 'Properties of Determinants',
        points: [
          'If any two rows or columns are identical or proportional, |A| = 0.',
          '|kA| = k^n |A| for an n×n square matrix.',
          '|AB| = |A| |B| and |A^T| = |A|.',
          '|A^(-1)| = 1 / |A| (provided |A| ≠ 0).'
        ]
      },
      {
        heading: 'Adjoint & Inverse Relationships',
        points: [
          'A · adj(A) = |A| · I.',
          '|adj(A)| = |A|^(n - 1). For 3×3: |adj(A)| = |A|².',
          '|adj(adj(A))| = |A|^((n - 1)²). For 3×3: |A|⁴.',
          'adj(kA) = k^(n - 1) adj(A).'
        ]
      },
      {
        heading: "System of Linear Equations (Cramer's Rule & Consistency)",
        points: [
          'Unique solution: Δ ≠ 0 (independent consistent system).',
          'Infinitely many solutions: Δ = 0 and Δ1 = Δ2 = Δ3 = 0 (dependent consistent system).',
          'No solution: Δ = 0 and at least one of Δ1, Δ2, Δ3 ≠ 0 (inconsistent system).'
        ]
      }
    ],
    quickFormulas: [
      '|adj(2A)| for 3×3 = 2^(3×2) · |A|² = 64 · |A|²',
      'Trace of matrix = sum of principal diagonal elements',
      'For orthogonal matrix: A · A^T = I and |A| = ±1'
    ],
    eapcetTrends: 'In TG EAPCET, questions consistently test the determinant of adj(kA) and consistency of 3-variable linear systems with an unknown parameter λ.',
    commonPitfalls: [
      'Forgetting that scalar factor k pulls out as k^n in determinant, but k^(n-1) in adjoint!',
      'Assuming Δ = 0 automatically means no solution; it could have infinitely many solutions.'
    ]
  },
  'matha2_demoivre': {
    chapterId: 'matha2_demoivre',
    chapterTitle: "De Moivre's Theorem & Roots of Unity (2nd Year)",
    subjectId: 'maths_a',
    year: '2nd',
    weightageRank: 'High (3–4 Marks)',
    keyConcepts: [
      {
        heading: "De Moivre's Statement",
        points: [
          '(cos θ + i sin θ)^n = cos(nθ) + i sin(nθ) for any integer n.',
          'For rational n = p/q, cos(nθ) + i sin(nθ) is one of the q distinct values of (cos θ + i sin θ)^n.'
        ]
      },
      {
        heading: 'Cube Roots of Unity (1, ω, ω²)',
        points: [
          'Roots of x³ = 1 are 1, ω = (-1 + i√3)/2, and ω² = (-1 - i√3)/2.',
          '1 + ω + ω² = 0, so 1 + ω = -ω², 1 + ω² = -ω, and ω + ω² = -1.',
          'ω³ = 1; higher powers can be reduced by taking the exponent modulo 3.'
        ]
      }
    ],
    quickFormulas: [
      '(1 - ω + ω²)^n = (-2ω)^n',
      '(x + y)(x + yω)(x + yω²) = x³ + y³',
      '1 + ω^r + ω^(2r) = 3 if r is a multiple of 3, otherwise 0.'
    ],
    eapcetTrends: 'Frequently asks to evaluate high-degree binomial sums containing 1, ω, ω² or cyclic polynomial factors.',
    commonPitfalls: [
      'Confusing (-ω)² with -ω²; (-ω)² = +ω².',
      'Forgetting that 1/(cos θ + i sin θ) is cos θ - i sin θ.'
    ]
  },

  // --- MATHEMATICS B ---
  'mathb1_straight_lines': {
    chapterId: 'mathb1_straight_lines',
    chapterTitle: 'The Straight Line (1st Year)',
    subjectId: 'maths_b',
    year: '1st',
    weightageRank: 'Very High (4–5 Marks)',
    keyConcepts: [
      {
        heading: 'Standard Forms of Straight Lines',
        points: [
          'Slope-intercept form: y = mx + c.',
          'Intercept form: x/a + y/b = 1. Area of triangle formed with axes = |ab|/2.',
          'Normal (Perpendicular) form: x cos α + y sin α = p (p ≥ 0).'
        ]
      },
      {
        heading: 'Distances and Concurrency',
        points: [
          'Perpendicular distance from (x1, y1) to ax + by + c = 0 is |ax1 + by1 + c| / √(a² + b²).',
          'Foot of perpendicular (h, k) from (x1, y1): (h - x1)/a = (k - y1)/b = -(ax1 + by1 + c)/(a² + b²).',
          'Image of point (x1, y1): (h - x1)/a = (k - y1)/b = -2(ax1 + by1 + c)/(a² + b²).'
        ]
      }
    ],
    quickFormulas: [
      'Distance between parallel lines: d = |c1 - c2| / √(a² + b²)',
      'Area of triangle with coordinate axes: Area = c² / (2|ab|)',
      'Angle between two lines: tan θ = |(m1 - m2) / (1 + m1 m2)|'
    ],
    eapcetTrends: 'Foot of perpendicular and image of a point across a given line are tested almost every year. Memorize the ratio trick to solve in under 40 seconds.',
    commonPitfalls: [
      'Applying the parallel line distance formula before making the coefficients of x and y identical in both lines.',
      'Missing the factor of -2 in the image formula.'
    ]
  },
  'mathb2_circles': {
    chapterId: 'mathb2_circles',
    chapterTitle: 'The Circle & System of Circles (2nd Year)',
    subjectId: 'maths_b',
    year: '2nd',
    weightageRank: 'Highest in Maths B (7–8 Marks)',
    keyConcepts: [
      {
        heading: 'General Equation of Circle',
        points: [
          'x² + y² + 2gx + 2fy + c = 0 has Center = (-g, -f) and Radius r = √(g² + f² - c).',
          'Tangent at (x1, y1) is S1 = xx1 + yy1 + g(x + x1) + f(y + y1) + c = 0.',
          'Length of tangent from external point P is √S11.'
        ]
      },
      {
        heading: 'System of Circles & Orthogonality',
        points: [
          'Radical axis of S = 0 and S\' = 0 is S - S\' = 0.',
          'Condition for two circles to cut orthogonally: 2(g g\' + f f\') = c + c\'.',
          'Radical center is the point of concurrency of the radical axes of three circles taken pairwise.'
        ]
      }
    ],
    quickFormulas: [
      'Length of common chord = 2√(r² - d²)',
      'Condition for y = mx + c to touch x² + y² = a² is c² = a²(1 + m²)',
      'Pole of line lx + my + n = 0 w.r.t x² + y² = a² is (-a²l/n, -a²m/n)'
    ],
    eapcetTrends: 'Orthogonal circle condition 2(gg\' + ff\') = c + c\' and finding the common tangent / radical axis are guaranteed marks in TG EAPCET.',
    commonPitfalls: [
      'Remembering that g and f are HALF of the coefficients of x and y in standard form.',
      'Using √S11 when the point is INSIDE the circle (S11 < 0 gives imaginary result).'
    ]
  },

  // --- PHYSICS ---
  'phy1_motion': {
    chapterId: 'phy1_motion',
    chapterTitle: 'Motion in a Straight Line & Projectile (1st Year)',
    subjectId: 'physics',
    year: '1st',
    weightageRank: 'Very High (4 Marks)',
    keyConcepts: [
      {
        heading: '1D Kinematics Relations',
        points: [
          'Distance traveled in nth second: S_n = u + (a/2)(2n - 1).',
          'Ratio of distances in consecutive equal time intervals from rest: 1 : 3 : 5 : 7 : ... (Galileo\'s Law of Odd Numbers).'
        ]
      },
      {
        heading: 'Projectile Motion',
        points: [
          'Horizontal motion is uniform: v_x = u cos θ.',
          'Vertical motion is uniformly accelerated: v_y = u sin θ - gt.',
          'Trajectory equation: y = x tan θ - (g x²) / (2 u² cos² θ) = x tan θ [1 - x/R].'
        ]
      }
    ],
    quickFormulas: [
      'Golden relation: R · tan θ = 4H',
      'If θ1 + θ2 = 90°, Ranges are equal (R1 = R2)',
      'Product of times of flight for complementary angles: T1 · T2 = 2R / g'
    ],
    eapcetTrends: 'Direct questions on R tan θ = 4H, complementary angle flight times, and ratio of kinetic energies at highest point vs projection.',
    commonPitfalls: [
      'Assuming velocity at the highest point of projectile is zero (it has non-zero horizontal velocity u cos θ!).',
      'Forgetting that g acts downward throughout the flight.'
    ]
  },
  'phy2_current_elec': {
    chapterId: 'phy2_current_elec',
    chapterTitle: 'Current Electricity (2nd Year)',
    subjectId: 'physics',
    year: '2nd',
    weightageRank: 'Very High (4 Marks)',
    keyConcepts: [
      {
        heading: "Drift Velocity & Ohm's Law",
        points: [
          'Current: I = n A e v_d.',
          'Drift velocity: v_d = (e E τ) / m.',
          'Resistivity: ρ = m / (n e² τ).'
        ]
      },
      {
        heading: "Kirchhoff's Laws & Measuring Instruments",
        points: [
          'Kirchhoff\'s Current Law (KCL): Based on conservation of charge.',
          'Kirchhoff\'s Voltage Law (KVL): Based on conservation of energy.',
          'Potentiometer is superior to voltmeter because it draws no current at balance point (infinite effective resistance).'
        ]
      }
    ],
    quickFormulas: [
      'Stretched wire (constant volume): R ∝ L² ∝ 1/A² ∝ 1/r⁴',
      'Potentiometer comparison of EMFs: E1 / E2 = L1 / L2',
      'Internal resistance: r = R (L1 / L2 - 1)'
    ],
    eapcetTrends: 'Potentiometer balancing length calculations and wire stretching percentage problems occur in almost every session.',
    commonPitfalls: [
      'If wire is drawn/stretched, volume is constant (R ∝ L²); if another wire of different length is connected, volume is NOT constant (R ∝ L).',
      'Confusing series vs parallel combination rules for cells (nE vs E).'
    ]
  },

  // --- CHEMISTRY ---
  'chem1_chemical_bonding': {
    chapterId: 'chem1_chemical_bonding',
    chapterTitle: 'Chemical Bonding & Molecular Structure (1st Year)',
    subjectId: 'chemistry',
    year: '1st',
    weightageRank: 'Highest in Chem 1 (4–5 Marks)',
    keyConcepts: [
      {
        heading: 'VSEPR Theory & Geometries',
        points: [
          'Repulsion order: Lone Pair-Lone Pair > Lone Pair-Bond Pair > Bond Pair-Bond Pair.',
          'Steric number = (Number of bonded atoms) + (Number of lone pairs on central atom).',
          'Steric 4: tetrahedral (0 lp), pyramidal (1 lp, e.g. NH3), bent (2 lp, e.g. H2O).'
        ]
      },
      {
        heading: 'Molecular Orbital Theory (MOT)',
        points: [
          'Bond Order = 0.5 × (Nb - Na).',
          'If Bond Order > 0, molecule exists; if BO = 0, molecule is unstable.',
          'Unpaired electrons = paramagnetic; all paired = diamagnetic.',
          'For ≤ 14 electrons: π2px = π2py comes before σ2pz.'
        ]
      }
    ],
    quickFormulas: [
      '14 electrons => BO = 3 (N2, CO, CN-)',
      '15 or 13 electrons => BO = 2.5 (O2+, NO)',
      '16 or 12 electrons => BO = 2.0 (O2 is paramagnetic with 2 unpaired e- in π*2p)'
    ],
    eapcetTrends: 'Questions asking for bond order order, paramagnetic species among O2, O2+, O2-, and hybridization of Xe compounds (XeF2, XeF4, XeO3).',
    commonPitfalls: [
      'Thinking O2 is diamagnetic because it has 16 (even) electrons; MOT proves it has 2 unpaired electrons in antibonding orbitals!',
      'Ignoring lone pairs when predicting bond angles.'
    ]
  },
  'chem2_electrochem_kinetics': {
    chapterId: 'chem2_electrochem_kinetics',
    chapterTitle: 'Electrochemistry & Chemical Kinetics (2nd Year)',
    subjectId: 'chemistry',
    year: '2nd',
    weightageRank: 'Very High (5 Marks)',
    keyConcepts: [
      {
        heading: 'Nernst Equation & Cell Potential',
        points: [
          'E_cell = E°_cell - (0.0591 / n) log Q at 298 K.',
          'At equilibrium: E_cell = 0, so E°_cell = (0.0591 / n) log K_c.',
          'ΔG° = -n F E°_cell. For spontaneous reaction, E°_cell > 0 and ΔG° < 0.'
        ]
      },
      {
        heading: 'First-Order Kinetics',
        points: [
          'Rate = k [A]¹; Unit of k is s⁻¹.',
          't_1/2 = 0.693 / k (independent of initial concentration).',
          'Time required for 99.9% completion is exactly 10 × t_1/2.'
        ]
      }
    ],
    quickFormulas: [
      't_99.9% = 10 × t_1/2',
      't_75% = 2 × t_1/2',
      'Arrhenius: log(k2/k1) = (Ea / 2.303 R) × [(T2 - T1) / (T1 T2)]'
    ],
    eapcetTrends: 'Comparison of t_99.9% to half-life, Nernst equation calculations with concentration cells, and unit of rate constant for nth order: (mol/L)^(1-n) s⁻¹.',
    commonPitfalls: [
      'Confusing order (experimental, can be fractional or zero) with molecularity (theoretical, integer only).',
      'Forgetting the negative sign in ΔG° = -n F E°_cell.'
    ]
  }
};
