import { SubjectId, SubjectInfo, Chapter } from '../types';

export const SUBJECTS: Record<SubjectId, SubjectInfo> = {
  maths_a: {
    id: 'maths_a',
    name: 'Mathematics A',
    fullName: 'Mathematics A (First & Second Year)',
    color: 'text-sky-400',
    accentBg: 'bg-sky-500/10 border-sky-500/30 text-sky-300',
    badgeColor: 'bg-sky-500',
    totalMarks: 40,
    iconName: 'Calculator'
  },
  maths_b: {
    id: 'maths_b',
    name: 'Mathematics B',
    fullName: 'Mathematics B (First & Second Year)',
    color: 'text-indigo-400',
    accentBg: 'bg-indigo-500/10 border-indigo-500/30 text-indigo-300',
    badgeColor: 'bg-indigo-500',
    totalMarks: 40,
    iconName: 'Compass'
  },
  physics: {
    id: 'physics',
    name: 'Physics',
    fullName: 'Physics (First & Second Year)',
    color: 'text-amber-400',
    accentBg: 'bg-amber-500/10 border-amber-500/30 text-amber-300',
    badgeColor: 'bg-amber-500',
    totalMarks: 40,
    iconName: 'Zap'
  },
  chemistry: {
    id: 'chemistry',
    name: 'Chemistry',
    fullName: 'Chemistry (First & Second Year)',
    color: 'text-emerald-400',
    accentBg: 'bg-emerald-500/10 border-emerald-500/30 text-emerald-300',
    badgeColor: 'bg-emerald-500',
    totalMarks: 40,
    iconName: 'Atom'
  }
};

export const CHAPTERS: Chapter[] = [
  // --- PHYSICS 1ST YEAR ---
  {
    id: 'phy1_units',
    subjectId: 'physics',
    year: '1st',
    title: 'Units and Measurements',
    weightage: 'Standard',
    avgMarks: 2,
    description: 'Dimensional analysis, errors in measurement, vernier and screw gauge, SI units.'
  },
  {
    id: 'phy1_motion',
    subjectId: 'physics',
    year: '1st',
    title: 'Motion in a Straight Line & Plane',
    weightage: 'High',
    avgMarks: 4,
    description: 'Kinematics graphs, projectile motion, relative velocity, uniform circular motion.'
  },
  {
    id: 'phy1_laws',
    subjectId: 'physics',
    year: '1st',
    title: 'Laws of Motion & Friction',
    weightage: 'High',
    avgMarks: 4,
    description: "Newton's laws, impulse, friction on inclined plane, banking of roads, pulley systems."
  },
  {
    id: 'phy1_work',
    subjectId: 'physics',
    year: '1st',
    title: 'Work, Energy and Power',
    weightage: 'High',
    avgMarks: 3,
    description: 'Work-energy theorem, conservative forces, elastic and inelastic collisions in 1D & 2D.'
  },
  {
    id: 'phy1_particles',
    subjectId: 'physics',
    year: '1st',
    title: 'System of Particles & Rotational Motion',
    weightage: 'High',
    avgMarks: 4,
    description: 'Center of mass, torque, angular momentum conservation, moment of inertia, rolling.'
  },
  {
    id: 'phy1_oscillations',
    subjectId: 'physics',
    year: '1st',
    title: 'Oscillations (SHM)',
    weightage: 'Medium',
    avgMarks: 3,
    description: 'Simple harmonic motion, spring mass systems, simple pendulum, resonance.'
  },
  {
    id: 'phy1_gravitation',
    subjectId: 'physics',
    year: '1st',
    title: 'Gravitation',
    weightage: 'Medium',
    avgMarks: 3,
    description: "Universal law, variation of g, orbital speed, escape velocity, Kepler's laws."
  },
  {
    id: 'phy1_properties_matter',
    subjectId: 'physics',
    year: '1st',
    title: 'Mechanical Properties of Solids & Fluids',
    weightage: 'Medium',
    avgMarks: 3,
    description: "Hooke's law, Young's modulus, Bernoulli theorem, viscosity, surface tension."
  },
  {
    id: 'phy1_thermodynamics',
    subjectId: 'physics',
    year: '1st',
    title: 'Thermal Properties & Thermodynamics',
    weightage: 'High',
    avgMarks: 4,
    description: 'First & second law of thermodynamics, Carnot cycle, heat transfer, kinetic theory of gases.'
  },

  // --- PHYSICS 2ND YEAR ---
  {
    id: 'phy2_waves',
    subjectId: 'physics',
    year: '2nd',
    title: 'Waves & Sound',
    weightage: 'High',
    avgMarks: 3,
    description: 'Transverse & longitudinal waves, organ pipes, standing waves, beats, Doppler effect.'
  },
  {
    id: 'phy2_ray_optics',
    subjectId: 'physics',
    year: '2nd',
    title: 'Ray Optics and Optical Instruments',
    weightage: 'High',
    avgMarks: 3,
    description: 'Refraction at spherical surfaces, lens maker formula, prism, microscope & telescope.'
  },
  {
    id: 'phy2_wave_optics',
    subjectId: 'physics',
    year: '2nd',
    title: 'Wave Optics',
    weightage: 'Medium',
    avgMarks: 2,
    description: "Huygens principle, Young's double slit interference, diffraction, polarization."
  },
  {
    id: 'phy2_electrostatics',
    subjectId: 'physics',
    year: '2nd',
    title: 'Electric Charges, Fields & Capacitance',
    weightage: 'High',
    avgMarks: 4,
    description: "Coulomb's law, Gauss's theorem applications, electric potential, capacitor combinations & dielectrics."
  },
  {
    id: 'phy2_current_elec',
    subjectId: 'physics',
    year: '2nd',
    title: 'Current Electricity',
    weightage: 'High',
    avgMarks: 4,
    description: "Ohm's law, drift velocity, Kirchhoff's laws, Wheatstone bridge, potentiometer."
  },
  {
    id: 'phy2_magnetism',
    subjectId: 'physics',
    year: '2nd',
    title: 'Moving Charges & Magnetism',
    weightage: 'High',
    avgMarks: 3,
    description: 'Biot-Savart law, Ampere circuital law, solenoid, magnetic force on moving charge, cyclotron.'
  },
  {
    id: 'phy2_emi_ac',
    subjectId: 'physics',
    year: '2nd',
    title: 'Electromagnetic Induction & Alternating Current',
    weightage: 'High',
    avgMarks: 4,
    description: "Faraday's laws, Lenz's law, self & mutual inductance, LCR series circuit, resonance, transformers."
  },
  {
    id: 'phy2_modern_physics',
    subjectId: 'physics',
    year: '2nd',
    title: 'Dual Nature, Atoms & Nuclei',
    weightage: 'High',
    avgMarks: 4,
    description: 'Photoelectric effect, de Broglie wavelength, Bohr model, radioactive decay, nuclear fission.'
  },
  {
    id: 'phy2_semiconductors',
    subjectId: 'physics',
    year: '2nd',
    title: 'Semiconductor Electronics & Communication',
    weightage: 'High',
    avgMarks: 3,
    description: 'p-n junction diodes, rectifiers, Zener diode, logic gates (AND, OR, NOT, NAND, NOR).'
  },

  // --- CHEMISTRY 1ST YEAR ---
  {
    id: 'chem1_atomic_struct',
    subjectId: 'chemistry',
    year: '1st',
    title: 'Atomic Structure',
    weightage: 'High',
    avgMarks: 4,
    description: 'Bohr model, de Broglie, Heisenberg uncertainty, quantum numbers, electronic configuration.'
  },
  {
    id: 'chem1_periodic_table',
    subjectId: 'chemistry',
    year: '1st',
    title: 'Classification of Elements & Periodicity',
    weightage: 'High',
    avgMarks: 3,
    description: 'Periodic trends in atomic radii, ionization enthalpy, electron gain enthalpy, electronegativity.'
  },
  {
    id: 'chem1_chemical_bonding',
    subjectId: 'chemistry',
    year: '1st',
    title: 'Chemical Bonding & Molecular Structure',
    weightage: 'High',
    avgMarks: 4,
    description: 'VSEPR theory, hybridization (sp, sp2, sp3, sp3d), MOT (bond order, magnetic behavior), dipole moment.'
  },
  {
    id: 'chem1_states_matter',
    subjectId: 'chemistry',
    year: '1st',
    title: 'States of Matter (Gases & Liquids)',
    weightage: 'Medium',
    avgMarks: 2,
    description: 'Ideal gas equation, Graham law of diffusion, Dalton law, kinetic gas equation, van der Waals.'
  },
  {
    id: 'chem1_stoichiometry',
    subjectId: 'chemistry',
    year: '1st',
    title: 'Stoichiometry & Redox Reactions',
    weightage: 'High',
    avgMarks: 3,
    description: 'Mole concept, empirical formula, balancing redox reactions, normality, molarity.'
  },
  {
    id: 'chem1_thermodynamics',
    subjectId: 'chemistry',
    year: '1st',
    title: 'Thermodynamics & Energetics',
    weightage: 'High',
    avgMarks: 3,
    description: 'First law, enthalpy, Hess law, entropy, Gibbs free energy spontaneity condition (ΔG = ΔH - TΔS).'
  },
  {
    id: 'chem1_equilibrium',
    subjectId: 'chemistry',
    year: '1st',
    title: 'Chemical and Ionic Equilibrium',
    weightage: 'High',
    avgMarks: 4,
    description: 'Kc & Kp relations, Le Chatelier principle, pH calculation, buffer solutions, solubility product (Ksp).'
  },
  {
    id: 'chem1_inorganic_block',
    subjectId: 'chemistry',
    year: '1st',
    title: 'Hydrogen, s-Block & p-Block (13 & 14)',
    weightage: 'Medium',
    avgMarks: 3,
    description: 'Water hardness, alkali and alkaline earth metals, borax, diborane, allotropes of carbon.'
  },
  {
    id: 'chem1_organic_basics',
    subjectId: 'chemistry',
    year: '1st',
    title: 'Organic Chemistry Basics & Hydrocarbons',
    weightage: 'High',
    avgMarks: 5,
    description: 'IUPAC nomenclature, isomerism, inductive & resonance effects, alkanes, alkenes, alkynes, aromaticity.'
  },

  // --- CHEMISTRY 2ND YEAR ---
  {
    id: 'chem2_solid_solutions',
    subjectId: 'chemistry',
    year: '2nd',
    title: 'Solid State and Solutions',
    weightage: 'High',
    avgMarks: 4,
    description: 'Bragg law, packing efficiency, crystal defects, Raoult law, colligative properties, van t Hoff factor.'
  },
  {
    id: 'chem2_electrochem_kinetics',
    subjectId: 'chemistry',
    year: '2nd',
    title: 'Electrochemistry & Chemical Kinetics',
    weightage: 'High',
    avgMarks: 5,
    description: 'Nernst equation, Kohlrausch law, Faraday laws, order & molecularity, Arrhenius equation, half-life.'
  },
  {
    id: 'chem2_surface_metallurgy',
    subjectId: 'chemistry',
    year: '2nd',
    title: 'Surface Chemistry & Metallurgy',
    weightage: 'Medium',
    avgMarks: 2,
    description: 'Adsorption isotherms, colloids, Tyndall effect, extraction of Fe, Cu, Al, Ellingham diagrams.'
  },
  {
    id: 'chem2_p_block',
    subjectId: 'chemistry',
    year: '2nd',
    title: 'p-Block Elements (Groups 15, 16, 17, 18)',
    weightage: 'High',
    avgMarks: 4,
    description: 'Nitrogen oxides, oxoacids of phosphorus & sulfur, interhalogen compounds, noble gas fluorides.'
  },
  {
    id: 'chem2_d_f_coordination',
    subjectId: 'chemistry',
    year: '2nd',
    title: 'd & f Block & Coordination Compounds',
    weightage: 'High',
    avgMarks: 4,
    description: 'Transition metal properties, Werner theory, IUPAC naming, CFT (crystal field theory), isomerism.'
  },
  {
    id: 'chem2_organic_halides_alcohols',
    subjectId: 'chemistry',
    year: '2nd',
    title: 'Haloalkanes, Alcohols, Phenols & Ethers',
    weightage: 'High',
    avgMarks: 4,
    description: 'SN1 vs SN2 mechanism, Lucas test, Reimer-Tiemann reaction, Kolbe reaction, Williamson synthesis.'
  },
  {
    id: 'chem2_carbonyls_amines',
    subjectId: 'chemistry',
    year: '2nd',
    title: 'Aldehydes, Ketones, Carboxylic Acids & Amines',
    weightage: 'High',
    avgMarks: 5,
    description: 'Aldol condensation, Cannizzaro, Clemmensen, Tollens & Fehling tests, Hoffmann bromamide, diazotization.'
  },
  {
    id: 'chem2_biomolecules',
    subjectId: 'chemistry',
    year: '2nd',
    title: 'Biomolecules, Polymers & Everyday Chemistry',
    weightage: 'Medium',
    avgMarks: 3,
    description: 'Carbohydrates (glucose structure), amino acids, peptide bonds, addition vs condensation polymers, drugs.'
  },

  // --- MATHEMATICS A 1ST YEAR ---
  {
    id: 'matha1_functions',
    subjectId: 'maths_a',
    year: '1st',
    title: 'Functions & Relations',
    weightage: 'High',
    avgMarks: 4,
    description: 'Domain and range, one-one & onto functions, composite functions, inverse of a function.'
  },
  {
    id: 'matha1_induction',
    subjectId: 'maths_a',
    year: '1st',
    title: 'Mathematical Induction',
    weightage: 'Standard',
    avgMarks: 2,
    description: 'Principle of mathematical induction, divisibility proofs, series summation.'
  },
  {
    id: 'matha1_matrices',
    subjectId: 'maths_a',
    year: '1st',
    title: 'Matrices and Determinants',
    weightage: 'High',
    avgMarks: 6,
    description: "Matrix multiplication, adjoint & inverse, Cramer's rule, matrix inversion method, rank."
  },
  {
    id: 'matha1_vectors_addition',
    subjectId: 'maths_a',
    year: '1st',
    title: 'Addition of Vectors',
    weightage: 'Medium',
    avgMarks: 3,
    description: 'Collinear & coplanar vectors, linear combination, position vector, section formula.'
  },
  {
    id: 'matha1_vectors_product',
    subjectId: 'maths_a',
    year: '1st',
    title: 'Product of Vectors',
    weightage: 'High',
    avgMarks: 5,
    description: 'Scalar (dot) product, vector (cross) product, scalar triple product, vector triple product.'
  },
  {
    id: 'matha1_trig_transformations',
    subjectId: 'maths_a',
    year: '1st',
    title: 'Trigonometric Ratios & Transformations',
    weightage: 'High',
    avgMarks: 5,
    description: 'Compound angles, multiple & submultiple angles, transformation formulas (sum to product).'
  },
  {
    id: 'matha1_trig_equations',
    subjectId: 'maths_a',
    year: '1st',
    title: 'Trigonometric Equations & Inverse Trig',
    weightage: 'Medium',
    avgMarks: 3,
    description: 'General solutions of sin, cos, tan, domain & range of inverse functions, identities.'
  },
  {
    id: 'matha1_triangles',
    subjectId: 'maths_a',
    year: '1st',
    title: 'Properties of Triangles',
    weightage: 'High',
    avgMarks: 4,
    description: 'Sine rule, cosine rule, projection formula, half-angle formulas, incircle and excircles (r, r1, r2, r3).'
  },

  // --- MATHEMATICS A 2ND YEAR ---
  {
    id: 'matha2_complex_numbers',
    subjectId: 'maths_a',
    year: '2nd',
    title: 'Complex Numbers',
    weightage: 'Medium',
    avgMarks: 3,
    description: 'Modulus and argument, polar form, triangle inequality, locus of complex numbers.'
  },
  {
    id: 'matha2_demoivre',
    subjectId: 'maths_a',
    year: '2nd',
    title: "De Moivre's Theorem",
    weightage: 'High',
    avgMarks: 4,
    description: 'Integral and rational indices, cube roots of unity (1, ω, ω²), nth roots of unity.'
  },
  {
    id: 'matha2_quadratic',
    subjectId: 'maths_a',
    year: '2nd',
    title: 'Quadratic Expressions & Theory of Equations',
    weightage: 'High',
    avgMarks: 5,
    description: 'Sign of quadratic expression, maximum/minimum value, relation between roots and coefficients.'
  },
  {
    id: 'matha2_permutations',
    subjectId: 'maths_a',
    year: '2nd',
    title: 'Permutations and Combinations',
    weightage: 'High',
    avgMarks: 4,
    description: 'Fundamental counting principle, linear & circular permutations, combinations, selection theorems.'
  },
  {
    id: 'matha2_binomial',
    subjectId: 'maths_a',
    year: '2nd',
    title: 'Binomial Theorem & Partial Fractions',
    weightage: 'High',
    avgMarks: 4,
    description: 'General term, middle term, binomial coefficients identities, rational fraction resolution.'
  },
  {
    id: 'matha2_probability',
    subjectId: 'maths_a',
    year: '2nd',
    title: 'Measures of Dispersion & Probability',
    weightage: 'High',
    avgMarks: 6,
    description: 'Mean deviation, variance, standard deviation, conditional probability, Bayes theorem.'
  },
  {
    id: 'matha2_random_variables',
    subjectId: 'maths_a',
    year: '2nd',
    title: 'Random Variables & Distributions',
    weightage: 'High',
    avgMarks: 4,
    description: 'Probability distribution, mean, variance, binomial distribution, Poisson distribution.'
  },

  // --- MATHEMATICS B 1ST YEAR ---
  {
    id: 'mathb1_locus_trans',
    subjectId: 'maths_b',
    year: '1st',
    title: 'Locus & Transformation of Axes',
    weightage: 'Standard',
    avgMarks: 2,
    description: 'Equation of locus, translation and rotation of coordinate axes.'
  },
  {
    id: 'mathb1_straight_lines',
    subjectId: 'maths_b',
    year: '1st',
    title: 'The Straight Line',
    weightage: 'High',
    avgMarks: 5,
    description: 'Various forms of lines, point of intersection, angle between lines, distance of point from a line.'
  },
  {
    id: 'mathb1_pair_lines',
    subjectId: 'maths_b',
    year: '1st',
    title: 'Pair of Straight Lines',
    weightage: 'High',
    avgMarks: 5,
    description: 'Homogeneous equation of second degree, angle between pair of lines, pair of bisectors, condition for pair.'
  },
  {
    id: 'mathb1_3d_geometry',
    subjectId: 'maths_b',
    year: '1st',
    title: 'Three Dimensional Geometry & Planes',
    weightage: 'High',
    avgMarks: 4,
    description: 'Direction cosines and direction ratios, projection, angle between two lines, equation of plane.'
  },
  {
    id: 'mathb1_limits_continuity',
    subjectId: 'maths_b',
    year: '1st',
    title: 'Limits and Continuity',
    weightage: 'High',
    avgMarks: 4,
    description: "Standard limits, indeterminate forms (L'Hopital rule), continuity of functions."
  },
  {
    id: 'mathb1_differentiation',
    subjectId: 'maths_b',
    year: '1st',
    title: 'Differentiation',
    weightage: 'High',
    avgMarks: 5,
    description: 'Derivatives of standard functions, chain rule, parametric and implicit differentiation, logarithmic.'
  },
  {
    id: 'mathb1_apps_derivatives',
    subjectId: 'maths_b',
    year: '1st',
    title: 'Applications of Derivatives',
    weightage: 'High',
    avgMarks: 5,
    description: 'Rate of change, tangents and normals, Rolle theorem, Lagrange mean value theorem, maxima and minima.'
  },

  // --- MATHEMATICS B 2ND YEAR ---
  {
    id: 'mathb2_circles',
    subjectId: 'maths_b',
    year: '2nd',
    title: 'The Circle & System of Circles',
    weightage: 'High',
    avgMarks: 8,
    description: 'Standard equation, tangent & normal, chord of contact, radical axis, common chord, orthogonal circles.'
  },
  {
    id: 'mathb2_parabola',
    subjectId: 'maths_b',
    year: '2nd',
    title: 'Parabola',
    weightage: 'High',
    avgMarks: 3,
    description: 'Standard equation y² = 4ax, focal chord, parametric equations, tangent and normal.'
  },
  {
    id: 'mathb2_ellipse_hyperbola',
    subjectId: 'maths_b',
    year: '2nd',
    title: 'Ellipse & Hyperbola',
    weightage: 'High',
    avgMarks: 5,
    description: 'Eccentricity, foci, directrices, latus rectum, auxiliary circle, asymptotes of hyperbola.'
  },
  {
    id: 'mathb2_integration',
    subjectId: 'maths_b',
    year: '2nd',
    title: 'Indefinite Integration',
    weightage: 'High',
    avgMarks: 6,
    description: 'Integration by substitution, partial fractions, integration by parts, standard reduction formulas.'
  },
  {
    id: 'mathb2_definite_integrals',
    subjectId: 'maths_b',
    year: '2nd',
    title: 'Definite Integrals & Areas',
    weightage: 'High',
    avgMarks: 5,
    description: 'Fundamental theorem of calculus, properties of definite integrals, area bounded by curves.'
  },
  {
    id: 'mathb2_diff_equations',
    subjectId: 'maths_b',
    year: '2nd',
    title: 'Differential Equations',
    weightage: 'High',
    avgMarks: 5,
    description: 'Order and degree, formation, variable separable, homogeneous equations, linear differential equations.'
  }
];
