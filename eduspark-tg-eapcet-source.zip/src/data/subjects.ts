import { SubjectId, SubjectInfo } from '../types';

export const SUBJECTS: Record<SubjectId, SubjectInfo> = {
  maths_a: {
    id: 'maths_a',
    name: 'Mathematics A',
    fullName: 'Mathematics A (First & Second Year)',
    color: 'text-sky-400',
    accentBg: 'bg-sky-500/10 border-sky-500/30 text-sky-300',
    badgeColor: 'bg-sky-500',
    totalMarks: 40,
    iconName: 'Calculator'
  },
  maths_b: {
    id: 'maths_b',
    name: 'Mathematics B',
    fullName: 'Mathematics B (First & Second Year)',
    color: 'text-indigo-400',
    accentBg: 'bg-indigo-500/10 border-indigo-500/30 text-indigo-300',
    badgeColor: 'bg-indigo-500',
    totalMarks: 40,
    iconName: 'Compass'
  },
  physics: {
    id: 'physics',
    name: 'Physics',
    fullName: 'Physics (First & Second Year)',
    color: 'text-amber-400',
    accentBg: 'bg-amber-500/10 border-amber-500/30 text-amber-300',
    badgeColor: 'bg-amber-500',
    totalMarks: 40,
    iconName: 'Zap'
  },
  chemistry: {
    id: 'chemistry',
    name: 'Chemistry',
    fullName: 'Chemistry (First & Second Year)',
    color: 'text-emerald-400',
    accentBg: 'bg-emerald-500/10 border-emerald-500/30 text-emerald-300',
    badgeColor: 'bg-emerald-500',
    totalMarks: 40,
    iconName: 'Atom'
  }
};
