import { Formula } from '../types';

export const FORMULAS: Formula[] = [
  // --- MATHEMATICS A FORMULAS ---
  {
    id: 'f_ma_1',
    subjectId: 'maths_a',
    year: '1st',
    chapterId: 'matha1_matrices',
    chapterTitle: 'Matrices and Determinants',
    title: 'Adjoint and Inverse Properties',
    formula: 'A · adj(A) = adj(A) · A = |A| · I_n\n|adj(A)| = |A|^(n - 1)\n|adj(adj(A))| = |A|^((n - 1)²)\nadj(kA) = k^(n - 1) adj(A)',
    variables: 'A is an n×n square matrix, |A| is determinant, k is a scalar.',
    applicationNote: 'Extremely frequent in TG EAPCET. Remember power of k is (n-1), so for 3×3 matrix, factor is k².',
    importantForEapcet: true
  },
  {
    id: 'f_ma_2',
    subjectId: 'maths_a',
    year: '1st',
    chapterId: 'matha1_vectors_product',
    chapterTitle: 'Product of Vectors',
    title: 'Scalar and Vector Triple Products',
    formula: '[a b c] = a · (b × c) = (a × b) · c\na × (b × c) = (a · c)b - (a · b)c   ("BAC - CAB" Rule)\nVolume of tetrahedron = (1/6) |[a b c]|',
    variables: 'a, b, c are three-dimensional vectors.',
    applicationNote: 'Coplanar vectors have [a b c] = 0. Remember the BAC-CAB vector triple product expansion.',
    importantForEapcet: true
  },
  {
    id: 'f_ma_3',
    subjectId: 'maths_a',
    year: '1st',
    chapterId: 'matha1_trig_transformations',
    chapterTitle: 'Trigonometric Transformations',
    title: 'Product to Sum & Special Triple Angle',
    formula: 'cos θ · cos(60° - θ) · cos(60° + θ) = (1/4) cos 3θ\nsin θ · sin(60° - θ) · sin(60° + θ) = (1/4) sin 3θ\ntan θ · tan(60° - θ) · tan(60° + θ) = tan 3θ',
    variables: 'θ is an angle in degrees or radians.',
    applicationNote: 'Solve products like cos 20° cos 40° cos 80° in 5 seconds flat without expanding.',
    importantForEapcet: true
  },
  {
    id: 'f_ma_4',
    subjectId: 'maths_a',
    year: '1st',
    chapterId: 'matha1_triangles',
    chapterTitle: 'Properties of Triangles',
    title: 'Exradii and Inradius Relations',
    formula: 'r = Δ / s = 4R sin(A/2) sin(B/2) sin(C/2)\nr1 = Δ / (s - a) = 4R sin(A/2) cos(B/2) cos(C/2)\n1/r1 + 1/r2 + 1/r3 = 1/r\nr1 + r2 + r3 - r = 4R',
    variables: 'Δ = area, s = semi-perimeter, R = circumradius, r = inradius, r1, r2, r3 = exradii.',
    applicationNote: 'Directly tested every single year in TG EAPCET Maths A.',
    importantForEapcet: true
  },
  {
    id: 'f_ma_5',
    subjectId: 'maths_a',
    year: '2nd',
    chapterId: 'matha2_demoivre',
    chapterTitle: "De Moivre's Theorem",
    title: 'Cube Roots of Unity Properties',
    formula: '1 + ω + ω² = 0\nω³ = 1, ω^(3k) = 1, ω^(3k+1) = ω, ω^(3k+2) = ω²\nω = (-1 + i√3)/2,  ω² = (-1 - i√3)/2\na³ + b³ = (a + b)(a + bω)(a + bω²)',
    variables: 'ω is the non-real complex cube root of unity.',
    applicationNote: 'Look for expressions like (1 - ω + ω²) and substitute 1 + ω² = -ω to simplify.',
    importantForEapcet: true
  },
  {
    id: 'f_ma_6',
    subjectId: 'maths_a',
    year: '2nd',
    chapterId: 'matha2_quadratic',
    chapterTitle: 'Quadratic Expressions',
    title: 'Difference of Roots and Extremum',
    formula: '|α - β| = √(b² - 4ac) / |a| = √D / |a|\nIf a > 0, min value = (4ac - b²)/(4a) at x = -b/(2a)\nIf a < 0, max value = (4ac - b²)/(4a) at x = -b/(2a)',
    variables: 'ax² + bx + c = 0, D = discriminant.',
    applicationNote: 'Very quick for finding vertex and sign conditions for real/imaginary roots.',
    importantForEapcet: true
  },
  {
    id: 'f_ma_7',
    subjectId: 'maths_a',
    year: '2nd',
    chapterId: 'matha2_probability',
    chapterTitle: 'Measures of Dispersion & Probability',
    title: 'Variance and Binomial Distribution',
    formula: 'Var(X) = σ² = E(X²) - [E(X)]²\nVar(aX + b) = a² Var(X)\nBinomial: Mean = np,  Variance = npq (where q = 1 - p)\nSince 0 < q < 1, Variance < Mean always.',
    variables: 'n = number of independent trials, p = success probability, q = failure probability.',
    applicationNote: 'EAPCET standard question: Given Mean and Variance, find n: q = Var/Mean, p = 1 - q, n = Mean/p.',
    importantForEapcet: true
  },

  // --- MATHEMATICS B FORMULAS ---
  {
    id: 'f_mb_1',
    subjectId: 'maths_b',
    year: '1st',
    chapterId: 'mathb1_straight_lines',
    chapterTitle: 'The Straight Line',
    title: 'Perpendicular Distance & Parallel Line Gap',
    formula: 'Distance from (x1, y1) to ax + by + c = 0:\nd = |ax1 + by1 + c| / √(a² + b²)\nDistance between parallel lines ax + by + c1 = 0 and ax + by + c2 = 0:\nd = |c1 - c2| / √(a² + b²)',
    variables: 'x1, y1 = point coordinates, a, b = line coefficients, c = constant.',
    applicationNote: 'Ensure coefficients a and b are identical in both lines before using the formula!',
    importantForEapcet: true
  },
  {
    id: 'f_mb_2',
    subjectId: 'maths_b',
    year: '1st',
    chapterId: 'mathb1_pair_lines',
    chapterTitle: 'Pair of Straight Lines',
    title: 'Angle & Bisectors for Homogeneous Equation',
    formula: 'For ax² + 2hxy + by² = 0:\nAngle: cos θ = |a + b| / √((a - b)² + 4h²)\ntan θ = 2√(h² - ab) / |a + b|\nPerpendicular lines: a + b = 0 (Coeff of x² + Coeff of y² = 0)\nCoincident lines: h² - ab = 0\nEquation of angle bisectors: (x² - y²) / (a - b) = xy / h',
    variables: 'a, h, b are coefficients of homogeneous quadratic equation.',
    applicationNote: 'If a + b = 0, lines are at 90° immediately with zero calculation.',
    importantForEapcet: true
  },
  {
    id: 'f_mb_3',
    subjectId: 'maths_b',
    year: '1st',
    chapterId: 'mathb1_limits_continuity',
    chapterTitle: 'Limits and Differentiation',
    title: "Standard Limits & L'Hôpital Form",
    formula: "lim (x→0) (sin x)/x = 1,  lim (x→0) (tan x)/x = 1\nlim (x→0) (1 - cos x)/x² = 1/2\nlim (x→0) (e^x - 1)/x = 1,  lim (x→0) (a^x - 1)/x = ln a\nlim (x→0) (1 + x)^(1/x) = e",
    variables: 'x approaches 0.',
    applicationNote: 'Convert 1 - cos kx into (k²x²)/2 in limits to save 2 minutes of calculation.',
    importantForEapcet: true
  },
  {
    id: 'f_mb_4',
    subjectId: 'maths_b',
    year: '2nd',
    chapterId: 'mathb2_circles',
    chapterTitle: 'The Circle & System of Circles',
    title: 'Radical Axis and Orthogonal Circles',
    formula: 'Radical Axis of S = 0 and S\' = 0:\nS - S\' = 0   => 2(g - g\')x + 2(f - f\')y + (c - c\') = 0\nCondition for orthogonality of two circles:\n2(g g\' + f f\') = c + c\'\nLength of common chord = 2√(r² - d²)',
    variables: 'g, f, c and g\', f\', c\' are circle parameters; r = radius, d = perpendicular distance from center to chord.',
    applicationNote: 'Radical axis is always perpendicular to line joining the centers.',
    importantForEapcet: true
  },
  {
    id: 'f_mb_5',
    subjectId: 'maths_b',
    year: '2nd',
    chapterId: 'mathb2_ellipse_hyperbola',
    chapterTitle: 'Conic Sections - Ellipse & Hyperbola',
    title: 'Standard Conic Parameters & Eccentricity',
    formula: 'Ellipse (x²/a² + y²/b² = 1, a > b):\ne = √(1 - b²/a²),  Foci = (±ae, 0),  Directrices = x = ±a/e\nHyperbola (x²/a² - y²/b² = 1):\ne = √(1 + b²/a²),  Foci = (±ae, 0),  Asymptotes = y = ±(b/a)x\nRectangular hyperbola: e = √2',
    variables: 'a = semi-major axis, b = semi-minor/conjugate axis, e = eccentricity.',
    applicationNote: 'For rectangular hyperbola x² - y² = a² or xy = c², eccentricity is always √2.',
    importantForEapcet: true
  },
  {
    id: 'f_mb_6',
    subjectId: 'maths_b',
    year: '2nd',
    chapterId: 'mathb2_definite_integrals',
    chapterTitle: 'Definite Integrals',
    title: "King's Rule and Standard Symmetries",
    formula: "∫[a to b] f(x) dx = ∫[a to b] f(a + b - x) dx\n∫[0 to a] f(x) dx = ∫[0 to a] f(a - x) dx\n∫[a to b] f(x) / [f(x) + f(a + b - x)] dx = (b - a) / 2\n∫[0 to π/2] ln(sin x) dx = - (π/2) ln 2",
    variables: 'a, b are integral bounds.',
    applicationNote: 'Any integral of form f(x)/(f(x)+f(a+b-x)) evaluates to half the interval length (b-a)/2.',
    importantForEapcet: true
  },

  // --- PHYSICS FORMULAS ---
  {
    id: 'f_phy_1',
    subjectId: 'physics',
    year: '1st',
    chapterId: 'phy1_motion',
    chapterTitle: 'Motion in a Plane',
    title: 'Projectile Motion Key Relations',
    formula: 'Time of flight: T = (2u sin θ) / g\nMaximum height: H = (u² sin² θ) / (2g)\nHorizontal range: R = (u² sin 2θ) / g\nGolden relation: R · tan θ = 4H\nMax range: R_max = u² / g (at θ = 45°)',
    variables: 'u = initial speed, θ = launch angle, g = acceleration due to gravity.',
    applicationNote: 'Use R tan θ = 4H whenever problem relates Range and Maximum Height.',
    importantForEapcet: true
  },
  {
    id: 'f_phy_2',
    subjectId: 'physics',
    year: '1st',
    chapterId: 'phy1_particles',
    chapterTitle: 'Rotational Motion',
    title: 'Rolling Motion Acceleration & Kinetic Energy',
    formula: 'Total KE: K = (1/2) M v² (1 + k²/R²)\nAcceleration down an incline (angle θ):\na = (g sin θ) / (1 + k²/R²)\nVelocity at bottom: v = √[(2gh) / (1 + k²/R²)]\nk²/R² values: Ring = 1, Disc = 1/2, Solid Sphere = 2/5, Hollow Sphere = 2/3',
    variables: 'M = mass, R = radius, k = radius of gyration, h = vertical height of incline.',
    applicationNote: 'Smaller k²/R² means higher acceleration. Solid sphere always wins the race down an incline!',
    importantForEapcet: true
  },
  {
    id: 'f_phy_3',
    subjectId: 'physics',
    year: '1st',
    chapterId: 'phy1_thermodynamics',
    chapterTitle: 'Thermodynamics',
    title: 'Carnot Engine & Work in Processes',
    formula: 'Efficiency: η = 1 - T2/T1 = W / Q1\nIsothermal work: W = n R T ln(V2/V1)\nAdiabatic work: W = (P1 V1 - P2 V2) / (γ - 1) = n R (T1 - T2) / (γ - 1)\nAdiabatic relation: P V^γ = const,  T V^(γ-1) = const',
    variables: 'T1 = Source temp (K), T2 = Sink temp (K), γ = Cp/Cv ratio.',
    applicationNote: 'Always convert Celsius temperatures to Kelvin (K = °C + 273) in Carnot efficiency calculations.',
    importantForEapcet: true
  },
  {
    id: 'f_phy_4',
    subjectId: 'physics',
    year: '2nd',
    chapterId: 'phy2_current_elec',
    chapterTitle: 'Current Electricity',
    title: 'Stretching of Wire & Drift Velocity',
    formula: 'When wire stretched by n times length: R\' = n² R\nWhen length increases by x% (x small < 5%): ΔR/R ≈ 2(ΔL/L)\nDrift velocity: v_d = (e E τ) / m = I / (n e A)\nTemperature dependence: R_T = R_0 (1 + α ΔT)',
    variables: 'R = original resistance, n = stretch factor, v_d = drift velocity, τ = relaxation time.',
    applicationNote: 'If wire is stretched to double length (n=2), resistance becomes 4R. If stretched by 10%, R increases by 21%.',
    importantForEapcet: true
  },
  {
    id: 'f_phy_5',
    subjectId: 'physics',
    year: '2nd',
    chapterId: 'phy2_electrostatics',
    chapterTitle: 'Capacitance & Dielectrics',
    title: 'Dielectric Slabs & Energy Density',
    formula: 'Parallel plate capacitor: C = ε0 A / d\nWith dielectric slab (thickness t, constant K):\nC\' = ε0 A / [d - t + t/K]\nEnergy stored: U = (1/2) C V² = Q² / (2C)\nEnergy density: u = (1/2) ε0 E²',
    variables: 'A = plate area, d = plate separation, t = slab thickness, K = dielectric constant.',
    applicationNote: 'If slab completely fills gap (t = d), C becomes K × C.',
    importantForEapcet: true
  },
  {
    id: 'f_phy_6',
    subjectId: 'physics',
    year: '2nd',
    chapterId: 'phy2_modern_physics',
    chapterTitle: 'Dual Nature and Atoms',
    title: 'Photoelectric Effect & de Broglie Wavelength',
    formula: 'Einstein equation: hν = Φ + K_max = Φ + e V_0\nde Broglie wavelength of electron: λ = 12.27 / √V Å = 1.227 / √V nm\nBohr radius: r_n = 0.529 (n² / Z) Å\nEnergy of nth orbit: E_n = -13.6 (Z² / n²) eV',
    variables: 'V = accelerating voltage in volts, n = principal quantum number, Z = atomic number.',
    applicationNote: 'For 100V electron: λ = 12.27/√100 = 1.227 Å = 0.123 nm.',
    importantForEapcet: true
  },

  // --- CHEMISTRY FORMULAS ---
  {
    id: 'f_chem_1',
    subjectId: 'chemistry',
    year: '1st',
    chapterId: 'chem1_chemical_bonding',
    chapterTitle: 'Chemical Bonding (MOT)',
    title: 'Bond Order and Magnetic Nature Shortcut',
    formula: 'Bond Order = 0.5 × (N_b - N_a)\nQuick 14-electron rule:\n14 e- (e.g. N2) => BO = 3.0\n13 or 15 e- (e.g. O2+) => BO = 2.5\n12 or 16 e- (e.g. O2) => BO = 2.0 (O2 is paramagnetic!)\n11 or 17 e- => BO = 1.5\n10 or 18 e- => BO = 1.0',
    variables: 'N_b = electrons in bonding orbitals, N_a = electrons in antibonding orbitals.',
    applicationNote: 'Odd number of total electrons = always paramagnetic. Even number = check O2 and B2 (both paramagnetic with 2 unpaired e-).',
    importantForEapcet: true
  },
  {
    id: 'f_chem_2',
    subjectId: 'chemistry',
    year: '1st',
    chapterId: 'chem1_equilibrium',
    chapterTitle: 'Chemical and Ionic Equilibrium',
    title: 'Solubility Product and Buffer Solutions',
    formula: 'Salt AB: K_sp = S²  =>  S = √K_sp\nSalt A2B or AB2: K_sp = 4 S³  =>  S = (K_sp / 4)^(1/3)\nSalt AB3 or A3B: K_sp = 27 S⁴  =>  S = (K_sp / 27)^(1/4)\nAcidic buffer: pH = pKa + log([Salt] / [Acid])\nBasic buffer: pOH = pKb + log([Salt] / [Base])',
    variables: 'S = molar solubility in mol/L, K_sp = solubility product constant.',
    applicationNote: 'Extremely popular in TG EAPCET. Note Ag2CrO4 is A2B type, so use 4S³.',
    importantForEapcet: true
  },
  {
    id: 'f_chem_3',
    subjectId: 'chemistry',
    year: '2nd',
    chapterId: 'chem2_electrochem_kinetics',
    chapterTitle: 'Chemical Kinetics',
    title: 'First-Order Reaction Integrated Rate Law',
    formula: 'k = (2.303 / t) log(a / (a - x)) = (2.303 / t) log(C0 / Ct)\nt_1/2 = 0.693 / k\nt_99.9% = 10 × t_1/2\nt_99% = 2 × t_90% ≈ 6.6 × t_1/2\nt_75% = 2 × t_1/2',
    variables: 'k = rate constant, t_1/2 = half-life, C0 = initial concentration, Ct = concentration at time t.',
    applicationNote: 'Remember: t_75% is 2 half-lives, t_87.5% is 3 half-lives, t_99.9% is 10 half-lives.',
    importantForEapcet: true
  },
  {
    id: 'f_chem_4',
    subjectId: 'chemistry',
    year: '2nd',
    chapterId: 'chem2_solid_solutions',
    chapterTitle: 'Solutions & Colligative Properties',
    title: "van 't Hoff Factor & Colligative Equations",
    formula: 'Dissociation: i = 1 + (n - 1)α\nAssociation: i = 1 + (1/n - 1)α\nRelative lowering of vapor pressure: (P° - P) / P° = i · x_solute\nElevation in boiling point: ΔTb = i · Kb · m\nDepression in freezing point: ΔTf = i · Kf · m\nOsmotic pressure: π = i · C · R · T',
    variables: 'i = van \'t Hoff factor, n = number of ions produced, α = degree of dissociation, m = molality.',
    applicationNote: 'Never forget to multiply by i for electrolyte solutions like BaCl2, NaCl, Al2(SO4)3.',
    importantForEapcet: true
  },
  {
    id: 'f_chem_5',
    subjectId: 'chemistry',
    year: '2nd',
    chapterId: 'chem2_d_f_coordination',
    chapterTitle: 'Coordination Compounds',
    title: 'Spin-Only Magnetic Moment',
    formula: 'μ_s = √[n (n + 2)] Bohr Magnetons (BM)\nIf n = 1: μ = √3 = 1.73 BM\nIf n = 2: μ = √8 = 2.83 BM\nIf n = 3: μ = √15 = 3.87 BM\nIf n = 4: μ = √24 = 4.90 BM\nIf n = 5: μ = √35 = 5.92 BM',
    variables: 'n = number of unpaired electrons in the central metal ion.',
    applicationNote: 'Determine whether ligand is strong field (CN-, CO, en -> pairing) or weak field (H2O, F-, Cl- -> no pairing).',
    importantForEapcet: true
  }
];
