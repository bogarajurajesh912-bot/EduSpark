import React from 'react';
import { useApp } from '../context/AppContext';
import { Home, BookOpen, Clock, FileText, BarChart3, GraduationCap } from 'lucide-react';

export const BottomNav: React.FC = () => {
  const { activeTab, setActiveTab, triggerHaptic } = useApp();

  interface NavItem {
    id: typeof activeTab;
    label: string;
    icon: React.ComponentType<{ className?: string }>;
    badge?: string;
  }

  const navItems: NavItem[] = [
    { id: 'home', label: 'Home', icon: Home },
    { id: 'pyqs', label: 'PYQs', icon: GraduationCap, badge: 'New' },
    { id: 'practice', label: 'Practice', icon: BookOpen },
    { id: 'mock', label: 'CBT Mock', icon: Clock },
    { id: 'formulas', label: 'Formulas', icon: FileText },
    { id: 'progress', label: 'Progress', icon: BarChart3 }
  ];

  const handleTabClick = (tabId: typeof activeTab) => {
    triggerHaptic(15);
    setActiveTab(tabId);
  };

  return (
    <nav className="sticky bottom-0 left-0 right-0 z-30 bg-slate-950/95 backdrop-blur-lg border-t border-slate-800/80 px-2 py-1.5 shadow-2xl">
      <div className="grid grid-cols-6 items-center max-w-md mx-auto">
        {navItems.map((item) => {
          const isActive = activeTab === item.id;
          const Icon = item.icon;

          return (
            <button
              key={item.id}
              onClick={() => handleTabClick(item.id)}
              className={`min-h-[48px] flex flex-col items-center justify-center relative rounded-xl transition-all duration-150 active:scale-90 ${
                isActive
                  ? 'text-indigo-400 font-semibold'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {/* Optional tiny notification badge */}
              {item.badge && !isActive && (
                <span className="absolute top-1 right-2 w-1.5 h-1.5 rounded-full bg-emerald-400 ring-2 ring-slate-950" />
              )}

              <div
                className={`p-1 rounded-lg transition-colors ${
                  isActive ? 'bg-indigo-500/15' : 'bg-transparent'
                }`}
              >
                <Icon className={`w-5 h-5 transition-transform ${isActive ? 'scale-110' : 'scale-100'}`} />
              </div>
              <span className="text-[10px] tracking-tight leading-none mt-0.5 whitespace-nowrap">
                {item.label}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
};
