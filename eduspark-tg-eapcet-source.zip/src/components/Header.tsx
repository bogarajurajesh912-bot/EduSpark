import React from 'react';
import { useApp } from '../context/AppContext';
import { Sparkles, Flame, BookmarkCheck } from 'lucide-react';

export const Header: React.FC = () => {
  const { stats, setActiveTab, activeTab } = useApp();

  return (
    <header className="sticky top-0 z-30 w-full bg-slate-950/90 backdrop-blur-md border-b border-slate-800/80 px-4 py-3 flex items-center justify-between gap-4">
      {/* Brand Zone */}
      <div 
        onClick={() => setActiveTab('home')}
        className="flex items-center gap-2 cursor-pointer select-none group"
      >
        <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-indigo-600 to-sky-500 flex items-center justify-center shadow-lg shadow-indigo-500/20 group-hover:scale-105 transition-transform">
          <Sparkles className="w-4 h-4 text-white" />
        </div>
        <div>
          <div className="flex items-center gap-1.5">
            <span className="font-bold text-base tracking-tight text-white">EduSpark</span>
            <span className="text-[10px] font-semibold bg-indigo-500/20 text-indigo-300 px-1.5 py-0.2 rounded border border-indigo-500/30">TG EAPCET</span>
          </div>
          <p className="text-[10px] text-slate-400 font-medium truncate max-w-[170px]">
            By Bogaraju Rajesh
          </p>
        </div>
      </div>

      {/* Action Zone */}
      <div className="flex items-center gap-2">
        {/* Streak Counter */}
        <div 
          onClick={() => setActiveTab('progress')}
          className="flex items-center gap-1 bg-amber-500/10 border border-amber-500/20 text-amber-300 px-2.5 py-1 rounded-lg text-xs font-semibold cursor-pointer active:scale-95 transition-transform"
          title={`${stats.streakDays} Day Study Streak`}
        >
          <Flame className="w-3.5 h-3.5 text-amber-400 fill-amber-400" />
          <span>{stats.streakDays}d</span>
        </div>

        {/* Download Project Source ZIP Button */}
        <button
          onClick={async () => {
            const { downloadProjectZip } = await import('../utils/downloadZip');
            downloadProjectZip();
          }}
          className="p-1.5 rounded-lg bg-slate-900 border border-slate-800 text-slate-300 hover:text-white hover:border-slate-700 active:scale-95 transition-all flex items-center gap-1 text-[11px] font-semibold"
          title="Download Complete Project Source Code (.zip)"
        >
          <svg className="w-3.5 h-3.5 text-indigo-400" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>
            <polyline points="7 10 12 15 17 10"/>
            <line x1="12" y1="15" x2="12" y2="3"/>
          </svg>
          <span className="hidden sm:inline">ZIP</span>
        </button>

        {/* Quick Mock Test CTA Button */}
        <button
          onClick={() => setActiveTab('mock')}
          className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all shadow-sm ${
            activeTab === 'mock'
              ? 'bg-indigo-600 text-white shadow-indigo-600/30 ring-1 ring-indigo-400'
              : 'bg-indigo-600/20 border border-indigo-500/30 text-indigo-300 hover:bg-indigo-600/30'
          }`}
        >
          CBT Mock
        </button>
      </div>
    </header>
  );
};
