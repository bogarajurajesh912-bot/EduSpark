import React from 'react';
import { useApp } from '../context/AppContext';
import { Smartphone, Monitor, Wifi, Battery, Zap } from 'lucide-react';

interface PhoneFrameProps {
  children: React.ReactNode;
}

export const PhoneFrame: React.FC<PhoneFrameProps> = ({ children }) => {
  const { deviceViewMode, setDeviceViewMode } = useApp();

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col items-center justify-start">
      {/* Device Mode Switcher Floating Bar (Desktop / Large screen helper) */}
      <aside aria-label="Device view switcher" className="w-full max-w-6xl mx-auto px-4 py-2 flex items-center justify-between text-xs text-slate-400 border-b border-slate-900 bg-slate-950/80 backdrop-blur-md sticky top-0 z-50">
        <div className="flex items-center gap-2">
          <span className="font-semibold text-slate-200">EduSpark</span>
          <span className="text-slate-600">·</span>
          <span className="text-indigo-400 font-medium">TG EAPCET MPC</span>
          <span className="hidden sm:inline text-slate-600">·</span>
          <span className="hidden sm:inline text-slate-400">Created by Bogaraju Rajesh</span>
        </div>

        <div className="flex items-center gap-2">
          {/* Download ZIP button */}
          <button
            onClick={async () => {
              const { downloadProjectZip } = await import('../utils/downloadZip');
              downloadProjectZip();
            }}
            className="flex items-center gap-1.5 px-3 py-1 rounded-lg bg-emerald-600/20 border border-emerald-500/40 text-emerald-300 hover:bg-emerald-600/30 text-xs font-bold transition-all active:scale-95"
            title="Download Complete EduSpark Android App Source Code (.zip)"
          >
            <svg className="w-3.5 h-3.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>
              <polyline points="7 10 12 15 17 10"/>
              <line x1="12" y1="15" x2="12" y2="3"/>
            </svg>
            <span>Download ZIP</span>
          </button>

          <div className="flex items-center bg-slate-900 border border-slate-800 rounded-lg p-0.5">
            <button
              onClick={() => setDeviceViewMode('redmi')}
              className={`flex items-center gap-1 px-2.5 py-1 rounded-md font-medium transition-all ${
                deviceViewMode === 'redmi'
                  ? 'bg-indigo-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
              title="Redmi 15 5G Smartphone View (FHD+ 20:9)"
            >
              <Smartphone className="w-3.5 h-3.5" />
              <span>Redmi 15 5G</span>
            </button>
            <button
              onClick={() => setDeviceViewMode('fullscreen')}
              className={`flex items-center gap-1 px-2.5 py-1 rounded-md font-medium transition-all ${
                deviceViewMode === 'fullscreen'
                  ? 'bg-indigo-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
              title="Responsive Wide View"
            >
              <Monitor className="w-3.5 h-3.5" />
              <span>Full View</span>
            </button>
          </div>
        </div>
      </aside>

      {/* Main Wrapper */}
      {deviceViewMode === 'redmi' ? (
        <div className="w-full flex-1 flex flex-col items-center justify-center p-0 sm:py-6 sm:px-4">
          {/* Redmi 15 5G Phone Bezel Shell */}
          <div className="relative w-full sm:max-w-[420px] h-[100dvh] sm:h-[860px] sm:max-h-[92vh] bg-slate-950 sm:bg-slate-900/90 sm:border-[8px] sm:border-slate-800 sm:rounded-[44px] shadow-2xl sm:shadow-indigo-950/40 flex flex-col overflow-hidden sm:ring-1 sm:ring-slate-700/50">
            {/* Phone Camera Hole Punch & Status Bar for Redmi 15 5G */}
            <div className="h-7 w-full bg-slate-950/90 px-6 flex items-center justify-between text-[11px] text-slate-400 select-none z-40 shrink-0 border-b border-slate-900/50">
              <span className="font-semibold tracking-tight text-slate-300">10:24</span>
              
              {/* Centered Camera Hole Punch */}
              <div className="w-3.5 h-3.5 rounded-full bg-slate-900 ring-2 ring-slate-800/80 shadow-inner" />

              <div className="flex items-center gap-1.5">
                <span className="text-[10px] font-bold text-indigo-400">5G</span>
                <Wifi className="w-3 h-3 text-slate-300" />
                <Battery className="w-3.5 h-3.5 text-slate-300" />
              </div>
            </div>

            {/* Scrollable Screen Content */}
            <div className="flex-1 w-full overflow-y-auto overflow-x-hidden flex flex-col bg-slate-950 relative no-scrollbar">
              {children}
            </div>

            {/* Android Gesture Bar */}
            <div className="h-4 w-full bg-slate-950 flex items-center justify-center shrink-0 z-40 border-t border-slate-900/40">
              <div className="w-32 h-1 bg-slate-600 rounded-full opacity-60" />
            </div>
          </div>
        </div>
      ) : (
        <div className="w-full max-w-5xl mx-auto flex-1 flex flex-col">
          {children}
        </div>
      )}
    </div>
  );
};
