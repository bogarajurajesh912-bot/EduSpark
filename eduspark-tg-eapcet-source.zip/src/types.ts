export type SubjectId = 'physics' | 'chemistry' | 'maths_a' | 'maths_b';
export type AcademicYear = '1st' | '2nd';

export interface SubjectInfo {
  id: SubjectId;
  name: string;
  fullName: string;
  color: string;
  accentBg: string;
  badgeColor: string;
  totalMarks: number;
  iconName: string;
}

export interface Chapter {
  id: string;
  subjectId: SubjectId;
  year: AcademicYear;
  title: string;
  weightage: 'High' | 'Medium' | 'Standard';
  avgMarks: number;
  description: string;
}

export interface Question {
  id: string;
  subjectId: SubjectId;
  year: AcademicYear;
  chapterId: string;
  chapterTitle: string;
  question: string;
  options: [string, string, string, string];
  correctIndex: number;
  explanation: string;
  shortcutTrick?: string;
  isPYQ?: boolean;
  pyqYear?: number;
  pyqShift?: string;
  difficulty: 'Easy' | 'Moderate' | 'Challenging';
  formulaRef?: string;
}

export interface Formula {
  id: string;
  subjectId: SubjectId;
  year: AcademicYear;
  chapterId: string;
  chapterTitle: string;
  title: string;
  formula: string;
  variables: string;
  applicationNote: string;
  importantForEapcet: boolean;
}

export interface ChapterExplanation {
  chapterId: string;
  chapterTitle: string;
  subjectId: SubjectId;
  year: AcademicYear;
  weightageRank: string;
  keyConcepts: {
    heading: string;
    points: string[];
  }[];
  quickFormulas: string[];
  eapcetTrends: string;
  commonPitfalls: string[];
}

export type TabType = 'home' | 'pyqs' | 'practice' | 'mock' | 'formulas' | 'explanations' | 'progress';

export interface PYQPaper {
  id: string;
  year: 2026 | 2025;
  shift: string;
  shiftCode: string;
  sessionTime: string;
  examDate: string;
  examTitle: string;
  stream: 'Engineering (MPC)';
  totalQuestions: number;
  totalMarks: number;
  durationMinutes: number;
  mathsQuestions: Question[];
  physicsQuestions: Question[];
  chemistryQuestions: Question[];
  allQuestions: Question[];
}

export interface TestAnswer {
  questionId: string;
  selectedOption: number | null; // 0, 1, 2, 3 or null
  status: 'not_visited' | 'not_answered' | 'answered' | 'marked_for_review' | 'answered_and_marked';
  timeSpentSeconds: number;
}

export interface TestResult {
  id: string;
  testTitle: string;
  date: string;
  totalQuestions: number;
  attempted: number;
  correct: number;
  wrong: number;
  score: number;
  timeSpentSeconds: number;
  subjectBreakdown: Record<SubjectId, { total: number; correct: number }>;
  predictedRank?: number;
  answers: Record<string, number | null>;
}

export interface UserStats {
  totalTests: number;
  totalAnswered: number;
  totalCorrect: number;
  streakDays: number;
  lastStudyDate: string;
  bookmarkedQuestionIds: string[];
  mistakeQuestionIds: string[];
  completedChapterIds: string[];
  savedFormulaIds: string[];
}
